namespace Class_builder_Derek_E7
{
    public partial class Form1 : Form
    {
        int grade = 12;
        int line = 0;

        public Form1()
        {
            InitializeComponent();
            textBoxName.Focus();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close
                ();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (listBoxClassList.SelectedIndex == -1) MessageBox.Show("select a class first!");
            if (listBoxCSchedule.Items.Count > 6) MessageBox.Show("You have seven selected classes. You may not excede seven classes.", "ALERT !!!");
            if (listBoxClassList.SelectedIndex != -1)
            {
                if (listBoxCSchedule.Items.Count <= 6)
                {
                    listBoxCSchedule.Items.Add(listBoxClassList.Text);
                    listBoxClassList.Items.RemoveAt(listBoxClassList.SelectedIndex);
                }
            }
           
            


        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBoxCSchedule.SelectedIndex == -1) MessageBox.Show("select a class first!");
            if (listBoxCSchedule.SelectedIndex != -1)
            {
                int aech = listBoxCSchedule.SelectedIndex;
                listBoxClassList.Items.Add(listBoxCSchedule.Text);
                listBoxCSchedule.Items.RemoveAt(aech);
            }
            

        }

        private void printCurrentscheduleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printPreviewDialogSCHEDULE.Document = printDocumentSCHEDULE;
            printPreviewDialogSCHEDULE.ShowDialog();
        }

        private void printDocumentSCHEDULE_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {



            Font printFont = new Font("Arial", 12);
            Font headingFont = new Font("Arial", 24, FontStyle.Bold);
            float verticalPrintPositionFloat = e.MarginBounds.Top;
            float horizontalPrintPositionFloat = e.MarginBounds.Left;
            float lineHeightFloat = printFont.GetHeight();

            // Print heading.
            e.Graphics.DrawString("Current class list: ",
            headingFont,
            Brushes.SaddleBrown, horizontalPrintPositionFloat,
            verticalPrintPositionFloat);

            verticalPrintPositionFloat += 2 * lineHeightFloat;

            e.Graphics.DrawString("Name: " + textBoxName.Text, printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);
            verticalPrintPositionFloat += 2 * lineHeightFloat;
            e.Graphics.DrawString("Student number: " + textBoxNumber.Text, printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);
            verticalPrintPositionFloat += 2 * lineHeightFloat;
            e.Graphics.DrawString("Grade: " + grade.ToString(), printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);
            verticalPrintPositionFloat += 2 * lineHeightFloat;
            verticalPrintPositionFloat += 2 * lineHeightFloat;
            foreach (String student in listBoxCSchedule.Items)
            {
                e.Graphics.DrawString(student, printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);
                verticalPrintPositionFloat += 2 * lineHeightFloat;


            }
        }
        
            private void printPreviewDialogList_Load(object sender, EventArgs e)
        {
            //ignore
        }

        private void printDocumentList_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            //two fonts
            Font printFont = new Font("Arial", 12);
            Font headingFont = new Font("Arial", 18, FontStyle.Underline);

            float verticalPrintPositionFloat = e.MarginBounds.Top;
            float horizontalPrintPositionFloat = e.MarginBounds.Left;
            float lineHeightFloat = printFont.GetHeight();
            // Print heading.
            e.Graphics.DrawString("Class List: ",
                                    headingFont,
                                    Brushes.Black,
                                    horizontalPrintPositionFloat,
                                    verticalPrintPositionFloat);

            verticalPrintPositionFloat += 2 * lineHeightFloat;
            while (line < listBoxClassList.Items.Count)
            {
                String classes = listBoxClassList.Items[line].ToString();
                e.Graphics.DrawString("Line: " + (line + 1) + "\t" + classes,
                    printFont,
                    Brushes.IndianRed,
                    horizontalPrintPositionFloat,
                    verticalPrintPositionFloat);

                verticalPrintPositionFloat += 2 * lineHeightFloat;
                if (verticalPrintPositionFloat >= e.PageBounds.Height - 100)
                {
                    e.HasMorePages = true;
                    verticalPrintPositionFloat = e.MarginBounds.Top;
                    return;
                }
                else
                {
                    e.HasMorePages = false;
                }
                line++;
                //Font printFont = new Font("Arial", 12);
                //Font headingFont = new Font("Arial", 24, FontStyle.Bold);
                //float verticalPrintPositionFloat = e.MarginBounds.Top;
                //float horizontalPrintPositionFloat = e.MarginBounds.Left;
                //float lineHeightFloat = printFont.GetHeight();

                //// Print heading.
                //e.Graphics.DrawString("IHS class list: ",
                //headingFont,
                //Brushes.SaddleBrown, horizontalPrintPositionFloat,
                //verticalPrintPositionFloat);

                //verticalPrintPositionFloat += 2 * lineHeightFloat;

                //foreach (String student in listBoxClassList.Items)
                //{
                //    e.Graphics.DrawString(student, printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);

                //    verticalPrintPositionFloat += 2 * lineHeightFloat;


                //}
            }
        }
        private void printallClassesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printPreviewDialogList.Document = printDocumentList;
            printPreviewDialogList.ShowDialog();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            // i renamed the radiobuttons dont worrry,.,,,,....

            grade = 9;

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            grade = 10;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            grade = 11;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            grade = 12;
        }
    }
}
