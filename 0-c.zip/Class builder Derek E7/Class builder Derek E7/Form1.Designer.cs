﻿namespace Class_builder_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            printCurrentscheduleToolStripMenuItem = new ToolStripMenuItem();
            printallClassesToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem1 = new ToolStripSeparator();
            exitToolStripMenuItem = new ToolStripMenuItem();
            label1 = new Label();
            textBoxName = new TextBox();
            textBoxNumber = new TextBox();
            label2 = new Label();
            label3 = new Label();
            groupBox1 = new GroupBox();
            radioButton12 = new RadioButton();
            radioButton11 = new RadioButton();
            radioButton10 = new RadioButton();
            radioButton9 = new RadioButton();
            listBoxClassList = new ListBox();
            listBoxCSchedule = new ListBox();
            label4 = new Label();
            buttonAdd = new Button();
            button2 = new Button();
            printDocumentSCHEDULE = new System.Drawing.Printing.PrintDocument();
            printPreviewDialogSCHEDULE = new PrintPreviewDialog();
            printDocumentList = new System.Drawing.Printing.PrintDocument();
            printPreviewDialogList = new PrintPreviewDialog();
            menuStrip1.SuspendLayout();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { printCurrentscheduleToolStripMenuItem, printallClassesToolStripMenuItem, toolStripMenuItem1, exitToolStripMenuItem });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(247, 20);
            fileToolStripMenuItem.Text = "&Fileeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee";
            // 
            // printCurrentscheduleToolStripMenuItem
            // 
            printCurrentscheduleToolStripMenuItem.Name = "printCurrentscheduleToolStripMenuItem";
            printCurrentscheduleToolStripMenuItem.Size = new Size(190, 22);
            printCurrentscheduleToolStripMenuItem.Text = "Print current &schedule";
            printCurrentscheduleToolStripMenuItem.Click += printCurrentscheduleToolStripMenuItem_Click;
            // 
            // printallClassesToolStripMenuItem
            // 
            printallClassesToolStripMenuItem.Name = "printallClassesToolStripMenuItem";
            printallClassesToolStripMenuItem.Size = new Size(190, 22);
            printallClassesToolStripMenuItem.Text = "Print &all classes";
            printallClassesToolStripMenuItem.Click += printallClassesToolStripMenuItem_Click;
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(187, 6);
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(190, 22);
            exitToolStripMenuItem.Text = "E&xit";
            exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(30, 60);
            label1.Name = "label1";
            label1.Size = new Size(81, 15);
            label1.TabIndex = 1;
            label1.Text = "Student name";
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(160, 57);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(132, 23);
            textBoxName.TabIndex = 2;
            // 
            // textBoxNumber
            // 
            textBoxNumber.Location = new Point(160, 86);
            textBoxNumber.Name = "textBoxNumber";
            textBoxNumber.Size = new Size(132, 23);
            textBoxNumber.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(30, 89);
            label2.Name = "label2";
            label2.Size = new Size(93, 15);
            label2.TabIndex = 3;
            label2.Text = "Student number";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(30, 192);
            label3.Name = "label3";
            label3.Size = new Size(52, 15);
            label3.TabIndex = 5;
            label3.Text = "Class list";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(radioButton12);
            groupBox1.Controls.Add(radioButton11);
            groupBox1.Controls.Add(radioButton10);
            groupBox1.Controls.Add(radioButton9);
            groupBox1.Location = new Point(381, 57);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(126, 134);
            groupBox1.TabIndex = 6;
            groupBox1.TabStop = false;
            groupBox1.Text = "Grade";
            // 
            // radioButton12
            // 
            radioButton12.AutoSize = true;
            radioButton12.Checked = true;
            radioButton12.Location = new Point(6, 97);
            radioButton12.Name = "radioButton12";
            radioButton12.Size = new Size(48, 19);
            radioButton12.TabIndex = 3;
            radioButton12.TabStop = true;
            radioButton12.Text = "12th";
            radioButton12.UseVisualStyleBackColor = true;
            radioButton12.CheckedChanged += radioButton4_CheckedChanged;
            // 
            // radioButton11
            // 
            radioButton11.AutoSize = true;
            radioButton11.Location = new Point(6, 72);
            radioButton11.Name = "radioButton11";
            radioButton11.Size = new Size(48, 19);
            radioButton11.TabIndex = 2;
            radioButton11.Text = "11th";
            radioButton11.UseVisualStyleBackColor = true;
            radioButton11.CheckedChanged += radioButton3_CheckedChanged;
            // 
            // radioButton10
            // 
            radioButton10.AutoSize = true;
            radioButton10.Location = new Point(6, 47);
            radioButton10.Name = "radioButton10";
            radioButton10.Size = new Size(48, 19);
            radioButton10.TabIndex = 1;
            radioButton10.Text = "10th";
            radioButton10.UseVisualStyleBackColor = true;
            radioButton10.CheckedChanged += radioButton2_CheckedChanged;
            // 
            // radioButton9
            // 
            radioButton9.AutoSize = true;
            radioButton9.Location = new Point(6, 22);
            radioButton9.Name = "radioButton9";
            radioButton9.Size = new Size(42, 19);
            radioButton9.TabIndex = 0;
            radioButton9.Text = "9th";
            radioButton9.UseVisualStyleBackColor = true;
            radioButton9.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // listBoxClassList
            // 
            listBoxClassList.FormattingEnabled = true;
            listBoxClassList.ItemHeight = 15;
            listBoxClassList.Items.AddRange(new object[] { "MATH - Algebra I", "MATH - Geometry", "MATH - Algebra II", "MATH - Algebra II Trigonometry", "MATH - (Math & 141) Pre-Calculus 1", "MATH - AP Statistics", "MATH - IB Math: Applications & Interpretation SL (1)", "MATH - IB Math: Applications & Interpretation SL (2)", "MATH - IB Mathematics: Analysis & Approaches SL 1", "MATH - IB Mathematics: Analysis & Approaches SL 2", "MATH - IB Mathematics: Analysis & Approaches HL 2", "MATH - Finance", "ENGLISH - ENGLISH 9 ENG100", "ENGLISH - NSD PRE IB ENGLISH 9 ENG165", "ENGLISH - ENGLISH 10 ENG200", "ENGLISH - NSD PRE IB ENGLISH 10 ENG235", "ENGLISH - ENGLISH 11 ENG300", "ENGLISH - AP ENGLISH LANGUAGE & COMPOSITION ENG475", "ENGLISH - IB ENGLISH 11 [IB LANGUAGE A: LANGUAGE AND LITERATURE HL] IBE305", "ENGLISH - ENGLISH 12 ENG400", "ENGLISH - AP ENGLISH LITERATURE & COMPOSITION ENG480", "ENGLISH - IB ENGLISH 12 [IB LANGUAGE A: LANGUAGE AND LITERATURE HL]", "SCIENCES - ASTRONOMY SCA100", "SCIENCES - BIOLOGY SCB100", "SCIENCES - IB BIOLOGY I HL IBS160", "SCIENCES - CHEMISTRY SCC100", "SCIENCES - IB CHEMISTRY SL IBS125", "SCIENCES - IB DESIGN TECHNOLOGY SL IBS310", "SCIENCES - IB DESIGN TECHNOLOGY HL IBS320", "SCIENCES - AP ENVIRONMENTAL SCIENCE SCE200", "SCIENCES - MARINE BIOLOGY SCM100", "SCIENCES - OCEANOGRAPHY SCO100", "SCIENCES - PHYSICS SCP100", "SCIENCES - IB PHYSICS I HL IBS110", "SCIENCES - IB PHYSICS II HL IBS130", "SCIENCES - IB SPORTS, EXERCISE & HEALTH SCIENCE SL", "SOCIAL SCIENCES - CIVICS SSC445", "SOCIAL SCIENCES - CONTEMPORARY WORLD PROBLEMS SSG445", "SOCIAL SCIENCES - IB HISTORY OF THE AMERICAS 11 HL IBH300", "SOCIAL SCIENCES - IB HISTORY OF THE AMERICAS 12 HL IBH400", "SOCIAL SCIENCES - AP HUMAN GEOGRAPHY SSG440", "SOCIAL SCIENCES - SOCIAL SCIENCES - IB THEORY OF KNOWLEDGE IBH310", "SOCIAL SCIENCES - AP US GOVERNMENT & POLITICS SSG422", "SOCIAL SCIENCES - UNITED STATES HISTORY SSU300", "SOCIAL SCIENCES - AP UNITED STATES HISTORY APH200", "SOCIAL SCIENCES - AP WORLD HISTORY SSW205", "SOCIAL SCIENCES - NSD PRE-IB WORLD HISTORY I SSW260", "SOCIAL SCIENCES - NSD PRE-IB WORLD HISTORY II SSW265", "WL - FRENCH 100 WLF100", "WL - GERMAN 100 WLG100", "WL - JAPANESE 100 WLJ100", "WL - MANDARIN CHINESE 100 WLC100", "WL - SPANISH 100 WLS100", "WL - AMERICAN SIGN LANGUAGE 100 WLX100", "WL - FRENCH 200 WLF200", "WL - GERMAN 200 WLG200", "WL - JAPANESE 200 WLJ200", "WL - MANDARIN CHINESE 200 WLC200", "WL - SPANISH 200 WLS200", "WL - AMERICAN SIGN LANGUAGE 200 WLX200", "WL - IB FRENCH 300 IBF300", "WL - IB GERMAN 300 IBG300", "WL - IB JAPANESE 300 IBJ300", "WL - IB MANDARIN CHINESE 300 IBC301", "WL - IB SPANISH 300 IBS300", "WL - AMERICAN SIGN LANGUAGE 300 WLX300", "WL - IB FRENCH 400 IBF400", "WL - IB GERMAN 400 IBG400", "WL - IB JAPANESE 400 IBJ400", "WL - IB MANDARIN CHINESE 400 IBC400", "WL - IB SPANISH 400 IBS400", "WL - AMERICAN SIGN LANGUAGE 400 WLX425", "WL - IB FRENCH 500 IBF500", "WL - IB GERMAN 500 IBG500", "WL - IB JAPANESE 500 IBJ500", "WL - IB MANDARIN CHINESE 500 IBC500", "WL - IB SPANISH 500 IBS500", "HF - AEROBICS PAE200", "HF - HEALTH HEA410", "HF - TEAM SPORTS PTS100", "HF - LIFE FITNESS PLF200", "HF - RACKET SPORTS PRS200", "HF - WALKING FITNESS PWA200", "HF - ADVANCED WEIGHT TRAINING PWT250", "HF - YOGA/PILATES PYP100", "PA - CONCERT BAND MUB110", "PA - SYMPHONIC BAND MUB100", "PA - CHOIR MUV150", "PA - ADVANCED CHOIR MUV360", "PA - WOMEN'S CHOIR MUV355", "PA - DIGITAL MUSIC PRODUCTION MUS120", "PA - JAZZ ENSEMBLE MUJ100", "PA - WIND ENSEMBLE MUB300", "PA - GUITAR MUG110", "PA - BEGINNING MARIACHI MUB115", "PA - IB MUSIC SL IBM205", "PA - ORCHESTRA MUO100", "PA - CHAMBER ORCHESTRA MUO150", "PA - CONCERT ORCHESTRA MUO125", "PA - PIANO LAB MU200", "PA - PLAY PERFORMANCE DRA350", "PA - MUSICAL PERFORMANCE DRA360", "PA - TECHICAL THEATRE DRA300", "PA - ADVANCED TECHICAL THEATRE DRA305", "PA - THEATRE ARTS I DRA115", "PA - THEATRE ARTS II DRA215", "VA - CARTOONING ACA100", "VA - CERAMICS ACE100", "VA - COMPUTER GRAPHICS ACG111", "VA - DRAWING / DESIGN ADD100", "VA - GRAPHIC DESIGN AGD115", "VA - IB FILM SL IBF200", "VA - METAL DESIGN AMD100", "VA - PHOTOGRAPHY APH100", "VA - ADVANCED PHOTOGRAPHY", "VA - STAINED GLASS ASG100", "VA - ADVANCED TELEVISION PRODUCTION TET230", "VA - VIDEO PRODUCTION TEV131", "VA - ADVANCED VIDEO PRODUCTION TEV230", "VA - IB VISUAL ARTS SL and HL IBV100 (SL) IBV300 (HL)", "VA - VISUAL COMMUNICATIONS DESIGN AVC100", "CTE - ASB/LEADERSHIP YYN206", "CTE - IB BUSINESS & MANAGEMENT SL IBB200", "CTE - CAREERS IN EDUCATION VTA345", "CTE - COMPUTER SCIENCE WITH C#.NET VCP515", "CTE - IB COMPUTER SCIENCE WITH JAVA SL IBC300", "CTE - IB DESIGN TECHNOLOGY SL IBS310", "CTE - IB DESIGN TECHNOLOGY HL IBS320", "CTE - FINANCE BFI315", "CTE - FOOD AND NUTRITION HFF161", "CTE - INDEPENDENT LIVING HFL100", "CTE - INTERIOR DESIGN HFI120", "CTE - INTRODUCTION TO ENGINEERING DESIGN TEC105", "CTE - INTRODUCTION TO INTERPRETING & TRANSLATION WLT200", "CTE - INTRO TO MARKETING BMD110", "CTE - INTRODUCTION TO ROBOTICS TER200", "CTE - LIBRARY RESEARCH ASSISTANT", "CTE - LIFESPAN PSYCHOLOGY HFP240", "CTE - MARKETING â\u0080\u0080 ADVANCED/DECA BMD150", "CTE - MICROSOFT APPLICATIONS BMA100", "CTE - MICROSOFT OFFICE CERTIFICATION BMO100", "CTE - PEER COACHING (ADVOCATE FOR SPECIAL EDUCATION PROGRAM)", "CTE - IB PSYCHOLOGY SL IBP100 & IBP155", "CTE - RETAIL OPERATIONS/ STUDENT STORE BRO105", "CTE - SPORTS AND ENTERTAINMENT MARKETING BSP100", "CTE - SPORTS MEDICINE / ATHLETIC TRAINING VMA210", "CTE - WEB DESIGN BWE110" });
            listBoxClassList.Location = new Point(30, 217);
            listBoxClassList.Name = "listBoxClassList";
            listBoxClassList.Size = new Size(232, 199);
            listBoxClassList.TabIndex = 7;
            // 
            // listBoxCSchedule
            // 
            listBoxCSchedule.FormattingEnabled = true;
            listBoxCSchedule.ItemHeight = 15;
            listBoxCSchedule.Location = new Point(275, 217);
            listBoxCSchedule.Name = "listBoxCSchedule";
            listBoxCSchedule.Size = new Size(232, 199);
            listBoxCSchedule.TabIndex = 8;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(275, 192);
            label4.Name = "label4";
            label4.Size = new Size(97, 15);
            label4.TabIndex = 9;
            label4.Text = "Current schedule";
            // 
            // buttonAdd
            // 
            buttonAdd.Location = new Point(30, 150);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(75, 23);
            buttonAdd.TabIndex = 10;
            buttonAdd.Text = "add >";
            buttonAdd.UseVisualStyleBackColor = true;
            buttonAdd.Click += buttonAdd_Click;
            // 
            // button2
            // 
            button2.Location = new Point(217, 150);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 11;
            button2.Text = "< remove";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // printDocumentSCHEDULE
            // 
            printDocumentSCHEDULE.PrintPage += printDocumentSCHEDULE_PrintPage;
            // 
            // printPreviewDialogSCHEDULE
            // 
            printPreviewDialogSCHEDULE.AutoScrollMargin = new Size(0, 0);
            printPreviewDialogSCHEDULE.AutoScrollMinSize = new Size(0, 0);
            printPreviewDialogSCHEDULE.ClientSize = new Size(400, 300);
            printPreviewDialogSCHEDULE.Enabled = true;
            printPreviewDialogSCHEDULE.Icon = (Icon)resources.GetObject("printPreviewDialogSCHEDULE.Icon");
            printPreviewDialogSCHEDULE.Name = "printPreviewDialog1";
            printPreviewDialogSCHEDULE.Visible = false;
            // 
            // printDocumentList
            // 
            printDocumentList.PrintPage += printDocumentList_PrintPage;
            // 
            // printPreviewDialogList
            // 
            printPreviewDialogList.AutoScrollMargin = new Size(0, 0);
            printPreviewDialogList.AutoScrollMinSize = new Size(0, 0);
            printPreviewDialogList.ClientSize = new Size(400, 300);
            printPreviewDialogList.Enabled = true;
            printPreviewDialogList.Icon = (Icon)resources.GetObject("printPreviewDialogList.Icon");
            printPreviewDialogList.Name = "printPreviewDialogList";
            printPreviewDialogList.Visible = false;
            printPreviewDialogList.Load += printPreviewDialogList_Load;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(buttonAdd);
            Controls.Add(label4);
            Controls.Add(listBoxCSchedule);
            Controls.Add(listBoxClassList);
            Controls.Add(groupBox1);
            Controls.Add(label3);
            Controls.Add(textBoxNumber);
            Controls.Add(label2);
            Controls.Add(textBoxName);
            Controls.Add(label1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Class builder";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private Label label1;
        private TextBox textBoxName;
        private TextBox textBoxNumber;
        private Label label2;
        private Label label3;
        private GroupBox groupBox1;
        private RadioButton radioButton11;
        private RadioButton radioButton10;
        private RadioButton radioButton9;
        private RadioButton radioButton12;
        private ListBox listBoxClassList;
        private ListBox listBoxCSchedule;
        private Label label4;
        private Button buttonAdd;
        private Button button2;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem printCurrentscheduleToolStripMenuItem;
        private ToolStripMenuItem printallClassesToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem1;
        private ToolStripMenuItem exitToolStripMenuItem;
        private System.Drawing.Printing.PrintDocument printDocumentSCHEDULE;
        private PrintPreviewDialog printPreviewDialogSCHEDULE;
        private System.Drawing.Printing.PrintDocument printDocumentList;
        private PrintPreviewDialog printPreviewDialogList;
    }
}
