using Microsoft.Win32;
using System.Reflection.Emit;
using System.Windows.Forms;

namespace Commissions_Proj_Derek_E7
{
    public partial class Form1 : Form
    {
        const double QUOTA = 1000;
        const double COMMISSIONRATE = .15;
        const double BASEPAY = 250;

        double totalsales = 0;
        double totalcommissions = 0;
        double totalpay = 0;




        public Form1()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private double calcualationonsos(double sal)
        {
            if (sal >= QUOTA)
            {
                double r = sal * COMMISSIONRATE;
                return r;
            }
            else
            {
                double r = 0;
                return r;
            }


        }
        private void payToolStripMenuItem_Click(object sender, EventArgs e)
        {
            double sales = double.Parse(textBoxSales.Text);
            double commissions = calcualationonsos(sales);

            double pay = BASEPAY + commissions;
            textBoxPay.Text = pay.ToString("N2");
            textBoxCommission.Text = commissions.ToString("N2");

            totalsales += sales;
            totalcommissions += commissions;
            totalpay += pay;

        }

        private void summaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string totalsal, totalcomn, totalpa;
            totalsal = totalsales.ToString("C");
            totalcomn = totalcommissions.ToString("C");
            totalpa = totalpay.ToString("C");

            MessageBox.Show("Total sales: " + totalsal + "\n" + "Total commissions: " + totalcomn + "\n" + "Total pay: " + totalpa);

        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Commissions Project - Derek E per 7");
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBoxName.Clear();
            textBoxSales.Clear();
            textBoxCommission.Clear();
            textBoxPay.Clear();
            textBoxName.Focus();
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowDialog();
            Font currentFont = fontDialog1.Font;
            labelCommission.Font = currentFont;
            labelName.Font = currentFont;
            labelSales.Font = currentFont;
            labelPay.Font = currentFont;
            textBoxName.Font = currentFont;
            textBoxSales.Font = currentFont;
            textBoxPay.Font = currentFont;
            textBoxCommission.Font = currentFont;
        }

        private void colourToolStripMenuItem_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            Color currentColor = colorDialog1.Color;
            labelName.ForeColor = currentColor;
            labelPay.ForeColor = currentColor;
            labelSales.ForeColor = currentColor;
            labelCommission.ForeColor = currentColor;
        }
    }
}
