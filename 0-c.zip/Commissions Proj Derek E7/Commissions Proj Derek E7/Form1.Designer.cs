﻿namespace Commissions_Proj_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            payToolStripMenuItem = new ToolStripMenuItem();
            summaryToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem1 = new ToolStripSeparator();
            exitToolStripMenuItem = new ToolStripMenuItem();
            editToolStripMenuItem = new ToolStripMenuItem();
            clearToolStripMenuItem = new ToolStripMenuItem();
            fontToolStripMenuItem = new ToolStripMenuItem();
            colourToolStripMenuItem = new ToolStripMenuItem();
            helpToolStripMenuItem = new ToolStripMenuItem();
            aboutToolStripMenuItem = new ToolStripMenuItem();
            labelName = new Label();
            textBoxName = new TextBox();
            textBoxSales = new TextBox();
            labelSales = new Label();
            textBoxCommission = new TextBox();
            labelCommission = new Label();
            textBoxPay = new TextBox();
            labelPay = new Label();
            colorDialog1 = new ColorDialog();
            fontDialog1 = new FontDialog();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem, editToolStripMenuItem, helpToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(380, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { payToolStripMenuItem, summaryToolStripMenuItem, toolStripMenuItem1, exitToolStripMenuItem });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(37, 20);
            fileToolStripMenuItem.Text = "&File";
            // 
            // payToolStripMenuItem
            // 
            payToolStripMenuItem.Name = "payToolStripMenuItem";
            payToolStripMenuItem.Size = new Size(125, 22);
            payToolStripMenuItem.Text = "Pay";
            payToolStripMenuItem.Click += payToolStripMenuItem_Click;
            // 
            // summaryToolStripMenuItem
            // 
            summaryToolStripMenuItem.Name = "summaryToolStripMenuItem";
            summaryToolStripMenuItem.Size = new Size(125, 22);
            summaryToolStripMenuItem.Text = "Summary";
            summaryToolStripMenuItem.Click += summaryToolStripMenuItem_Click;
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(122, 6);
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(125, 22);
            exitToolStripMenuItem.Text = "E&xit";
            exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;
            // 
            // editToolStripMenuItem
            // 
            editToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { clearToolStripMenuItem, fontToolStripMenuItem, colourToolStripMenuItem });
            editToolStripMenuItem.Name = "editToolStripMenuItem";
            editToolStripMenuItem.Size = new Size(39, 20);
            editToolStripMenuItem.Text = "&Edit";
            // 
            // clearToolStripMenuItem
            // 
            clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            clearToolStripMenuItem.Size = new Size(119, 22);
            clearToolStripMenuItem.Text = "Clear";
            clearToolStripMenuItem.Click += clearToolStripMenuItem_Click;
            // 
            // fontToolStripMenuItem
            // 
            fontToolStripMenuItem.Name = "fontToolStripMenuItem";
            fontToolStripMenuItem.Size = new Size(119, 22);
            fontToolStripMenuItem.Text = "Font...";
            fontToolStripMenuItem.Click += fontToolStripMenuItem_Click;
            // 
            // colourToolStripMenuItem
            // 
            colourToolStripMenuItem.Name = "colourToolStripMenuItem";
            colourToolStripMenuItem.Size = new Size(119, 22);
            colourToolStripMenuItem.Text = "Colour...";
            colourToolStripMenuItem.Click += colourToolStripMenuItem_Click;
            // 
            // helpToolStripMenuItem
            // 
            helpToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { aboutToolStripMenuItem });
            helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            helpToolStripMenuItem.Size = new Size(44, 20);
            helpToolStripMenuItem.Text = "&Help";
            // 
            // aboutToolStripMenuItem
            // 
            aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            aboutToolStripMenuItem.Size = new Size(107, 22);
            aboutToolStripMenuItem.Text = "About";
            aboutToolStripMenuItem.Click += aboutToolStripMenuItem_Click;
            // 
            // labelName
            // 
            labelName.AutoSize = true;
            labelName.Font = new Font("Segoe UI", 10F);
            labelName.Location = new Point(36, 50);
            labelName.Name = "labelName";
            labelName.Size = new Size(48, 19);
            labelName.TabIndex = 1;
            labelName.Text = "Name:";
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(126, 49);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(100, 23);
            textBoxName.TabIndex = 2;
            // 
            // textBoxSales
            // 
            textBoxSales.Location = new Point(126, 78);
            textBoxSales.Name = "textBoxSales";
            textBoxSales.Size = new Size(100, 23);
            textBoxSales.TabIndex = 4;
            // 
            // labelSales
            // 
            labelSales.AutoSize = true;
            labelSales.Font = new Font("Segoe UI", 10F);
            labelSales.Location = new Point(36, 79);
            labelSales.Name = "labelSales";
            labelSales.Size = new Size(42, 19);
            labelSales.TabIndex = 3;
            labelSales.Text = "Sales:";
            // 
            // textBoxCommission
            // 
            textBoxCommission.Location = new Point(126, 107);
            textBoxCommission.Name = "textBoxCommission";
            textBoxCommission.ReadOnly = true;
            textBoxCommission.Size = new Size(100, 23);
            textBoxCommission.TabIndex = 6;
            // 
            // labelCommission
            // 
            labelCommission.AutoSize = true;
            labelCommission.Font = new Font("Segoe UI", 10F);
            labelCommission.Location = new Point(36, 108);
            labelCommission.Name = "labelCommission";
            labelCommission.Size = new Size(87, 19);
            labelCommission.TabIndex = 5;
            labelCommission.Text = "Commission:";
            // 
            // textBoxPay
            // 
            textBoxPay.Location = new Point(126, 136);
            textBoxPay.Name = "textBoxPay";
            textBoxPay.ReadOnly = true;
            textBoxPay.Size = new Size(100, 23);
            textBoxPay.TabIndex = 8;
            // 
            // labelPay
            // 
            labelPay.AutoSize = true;
            labelPay.Font = new Font("Segoe UI", 10F);
            labelPay.Location = new Point(36, 137);
            labelPay.Name = "labelPay";
            labelPay.Size = new Size(34, 19);
            labelPay.TabIndex = 7;
            labelPay.Text = "Pay:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(380, 222);
            Controls.Add(textBoxPay);
            Controls.Add(labelPay);
            Controls.Add(textBoxCommission);
            Controls.Add(labelCommission);
            Controls.Add(textBoxSales);
            Controls.Add(labelSales);
            Controls.Add(textBoxName);
            Controls.Add(labelName);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Commissions Calculator";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem payToolStripMenuItem;
        private ToolStripMenuItem summaryToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem1;
        private ToolStripMenuItem exitToolStripMenuItem;
        private ToolStripMenuItem editToolStripMenuItem;
        private ToolStripMenuItem clearToolStripMenuItem;
        private ToolStripMenuItem fontToolStripMenuItem;
        private ToolStripMenuItem colourToolStripMenuItem;
        private ToolStripMenuItem helpToolStripMenuItem;
        private ToolStripMenuItem aboutToolStripMenuItem;
        private Label labelName;
        private TextBox textBoxName;
        private TextBox textBoxSales;
        private Label labelSales;
        private TextBox textBoxCommission;
        private Label labelCommission;
        private TextBox textBoxPay;
        private Label labelPay;
        private ColorDialog colorDialog1;
        private FontDialog fontDialog1;
    }
}
