﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Customer_Account_API
{
    public class Telephone
    {
        public int AreaCode { get; set; }
        public int Number { get; set; }
        public int Extention { get; set; }
        public TYpe PhoneType { get; set; }
        public Telephone() { }
        public Telephone(int a, int n, int e, TYpe t)
        {
            AreaCode = a;
            Number = n;
            Extention = e;
            PhoneType = t;

        }
    }
}
