﻿using System.Net.Http.Headers;

namespace Customer_Account_API
{
    public class Class1
    {
        public static void PrintCustomer(I_Customer customer)
        {
            System.Console.WriteLine(customer.FirstName + " " + customer.LastName);
        }
        public static void Demo()
        {
            I_Customer customer = new I_Customer();
            customer.FirstName

            Telephone telephone = new Telephone(425, 1234567, 1, TYpe.Home);
            switch (telephone.PhoneType)
            {
                case TYpe.Work:
                    Console.WriteLine("Work")
                        ; break;
                case TYpe.Mobile:
                    Console.WriteLine("Mobile")
                        ; break;
                case TYpe.Home:
                    Console.WriteLine("Home")
                        ; break;
                default:
                    throw new Exception("unknown");
            }
        }
    }
}
