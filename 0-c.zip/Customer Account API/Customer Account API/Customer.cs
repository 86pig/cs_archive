﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Customer_Account_API
{
    public interface I_Customer
    {
        long Id { get; set; }
        string FirstName { get; set; }
        string LastName { get; set; }

        Address Address { get; set; }
        Telephone Telephone { get; set; }

        public decimal GetBalance();
        public decimal GetStatement();
        public void MakePayment(decimal payment);
    }
}
