﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Customer_Account_API
{
    public class CustomerRR : I_Customer
    {
        long I_Customer.Id { get; set; }

        string I_Customer.FirstName { get; set; }

        string I_Customer.LastName { get; set; }

        Address I_Customer.Address { get; set; }

        Telephone I_Customer.Telephone { get; set; }

        public decimal GetBalance()
        {
            throw new NotImplementedException();
        }
        public decimal GetStatement()
        {
            throw new NotImplementedException();
        }

        public void MakePayment(decimal payment)
        {
            throw new NotImplementedException();
        }
    }
}
