﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Customer_Account_API
{
    public enum TYpe
    {
        Home,
        Work,
        Mobile
    }
}
