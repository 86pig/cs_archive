﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Customer_Account_API
{
    public class Billing
    {
        public long AccountID { get; set; }
        public long CustomerID { get; set; }
        public decimal LastStatement { get; set; }
        public decimal LastPayment { get; set; }
        public decimal NewCharges { get; set; }
        public decimal AmountOwed
        {
            get
            {
                return LastStatement - LastPayment + NewCharges;
            }
        }
    }
}
