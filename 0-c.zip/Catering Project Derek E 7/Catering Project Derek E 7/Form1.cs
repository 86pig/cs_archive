namespace Catering_Project_Derek_E_7
{
    public partial class Form1 : Form
    {
        const double RIB = 25.95;
        const double CHICKEN = 18.95;
        const double PASTA = 12.95;

        const double BAR = 25.00;
        const double WINE = 9.00;
        int totalEvents = 0;
        double totalSales = 0;


        public Form1()
        {
            InitializeComponent();
        }

        private void buttonexit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxNumberofGuests.Text))
            {
                MessageBox.Show("enter a numba!");
                textBoxNumberofEvents.Focus();
                return;
            }

            try
            {
                double ratepp = 0;
                int nog = int.Parse(textBoxNumberofGuests.Text);

                if (radioButtonPrimeRib.Checked) ratepp += RIB;
                else if (radioButtonChicken.Checked) ratepp += CHICKEN;
                else if (radioButtonpasta.Checked) ratepp += PASTA;

                if (checkBoxBAR.Checked) ratepp += BAR;
                if (checkBoxWineWithdinner.Checked) ratepp += WINE;

                double eventCost = ratepp * nog;

                textBoxEventCost.Text = eventCost.ToString("C");
                totalEvents++;
                buttonUpdateSummary.Enabled = true;
                totalSales += eventCost;

            }


            catch
            {
                MessageBox.Show("Enter a number...");
                textBoxNumberofGuests.Clear();
                textBoxNumberofGuests.Focus();




            }



        }

        private void buttonClearAll_Click(object sender, EventArgs e)
        {
            DialogResult yesno = MessageBox.Show("Are you sure you want to clear all data?", "Alert!", MessageBoxButtons.YesNo);
            if (yesno == DialogResult.Yes)
            {
                textBoxNumberofGuests.Clear();
                textBoxNumberofEvents.Clear();
                textBoxTotalSales.Clear();
                textBoxEventCost.Clear();
                radioButtonChicken.Checked = false;
                radioButtonpasta.Checked = false;
                radioButtonPrimeRib.Checked = false;
                checkBoxBAR.Checked = false;
                checkBoxWineWithdinner.Checked = false;
                buttonUpdateSummary.Enabled = false;
                totalEvents = 0;
                totalSales = 0;



            }
        }

        private void buttonUpdateSummary_Click(object sender, EventArgs e)
        {
            textBoxNumberofEvents.Text = totalEvents.ToString();
            
            textBoxTotalSales.Text = totalSales.ToString("C");



        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxNumberofGuests.Clear();
            textBoxEventCost.Clear();
            radioButtonChicken.Checked = false;
            radioButtonpasta.Checked = false;
            radioButtonPrimeRib.Checked = false;
            checkBoxBAR.Checked = false;
            checkBoxWineWithdinner.Checked = false;
        }
    }
}
