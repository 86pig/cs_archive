﻿namespace Catering_Project_Derek_E_7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            buttonUpdateSummary = new Button();
            buttonClear = new Button();
            buttonCalculate = new Button();
            checkBoxWineWithdinner = new CheckBox();
            checkBoxBAR = new CheckBox();
            radioButtonpasta = new RadioButton();
            radioButtonChicken = new RadioButton();
            radioButtonPrimeRib = new RadioButton();
            textBoxEventCost = new TextBox();
            textBoxNumberofGuests = new TextBox();
            label2 = new Label();
            label1 = new Label();
            groupBox2 = new GroupBox();
            buttonClearAll = new Button();
            textBoxTotalSales = new TextBox();
            textBoxNumberofEvents = new TextBox();
            label4 = new Label();
            label3 = new Label();
            buttonexit = new Button();
            label5 = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(buttonUpdateSummary);
            groupBox1.Controls.Add(buttonClear);
            groupBox1.Controls.Add(buttonCalculate);
            groupBox1.Controls.Add(checkBoxWineWithdinner);
            groupBox1.Controls.Add(checkBoxBAR);
            groupBox1.Controls.Add(radioButtonpasta);
            groupBox1.Controls.Add(radioButtonChicken);
            groupBox1.Controls.Add(radioButtonPrimeRib);
            groupBox1.Controls.Add(textBoxEventCost);
            groupBox1.Controls.Add(textBoxNumberofGuests);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(22, 36);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(232, 372);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Event Calculator";
            // 
            // buttonUpdateSummary
            // 
            buttonUpdateSummary.Enabled = false;
            buttonUpdateSummary.Location = new Point(6, 330);
            buttonUpdateSummary.Name = "buttonUpdateSummary";
            buttonUpdateSummary.Size = new Size(220, 26);
            buttonUpdateSummary.TabIndex = 11;
            buttonUpdateSummary.Text = "Show Summary";
            buttonUpdateSummary.UseVisualStyleBackColor = true;
            buttonUpdateSummary.Click += buttonUpdateSummary_Click;
            // 
            // buttonClear
            // 
            buttonClear.Location = new Point(6, 298);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(220, 26);
            buttonClear.TabIndex = 10;
            buttonClear.Text = "Clear";
            buttonClear.UseVisualStyleBackColor = true;
            buttonClear.Click += buttonClear_Click;
            // 
            // buttonCalculate
            // 
            buttonCalculate.Location = new Point(6, 266);
            buttonCalculate.Name = "buttonCalculate";
            buttonCalculate.Size = new Size(220, 26);
            buttonCalculate.TabIndex = 9;
            buttonCalculate.Text = "Calculate";
            buttonCalculate.UseVisualStyleBackColor = true;
            buttonCalculate.Click += buttonCalculate_Click;
            // 
            // checkBoxWineWithdinner
            // 
            checkBoxWineWithdinner.AutoSize = true;
            checkBoxWineWithdinner.Location = new Point(6, 189);
            checkBoxWineWithdinner.Name = "checkBoxWineWithdinner";
            checkBoxWineWithdinner.Size = new Size(117, 19);
            checkBoxWineWithdinner.TabIndex = 8;
            checkBoxWineWithdinner.Text = "Wine with Dinner";
            checkBoxWineWithdinner.UseVisualStyleBackColor = true;
            // 
            // checkBoxBAR
            // 
            checkBoxBAR.AutoSize = true;
            checkBoxBAR.Location = new Point(6, 164);
            checkBoxBAR.Name = "checkBoxBAR";
            checkBoxBAR.Size = new Size(75, 19);
            checkBoxBAR.TabIndex = 2;
            checkBoxBAR.Text = "Open bar";
            checkBoxBAR.UseVisualStyleBackColor = true;
            // 
            // radioButtonpasta
            // 
            radioButtonpasta.AutoSize = true;
            radioButtonpasta.Location = new Point(6, 129);
            radioButtonpasta.Name = "radioButtonpasta";
            radioButtonpasta.Size = new Size(53, 19);
            radioButtonpasta.TabIndex = 7;
            radioButtonpasta.TabStop = true;
            radioButtonpasta.Text = "Pasta";
            radioButtonpasta.UseVisualStyleBackColor = true;
            // 
            // radioButtonChicken
            // 
            radioButtonChicken.AutoSize = true;
            radioButtonChicken.Location = new Point(6, 103);
            radioButtonChicken.Name = "radioButtonChicken";
            radioButtonChicken.Size = new Size(68, 19);
            radioButtonChicken.TabIndex = 6;
            radioButtonChicken.TabStop = true;
            radioButtonChicken.Text = "Chicken";
            radioButtonChicken.UseVisualStyleBackColor = true;
            // 
            // radioButtonPrimeRib
            // 
            radioButtonPrimeRib.AutoSize = true;
            radioButtonPrimeRib.Location = new Point(6, 78);
            radioButtonPrimeRib.Name = "radioButtonPrimeRib";
            radioButtonPrimeRib.Size = new Size(76, 19);
            radioButtonPrimeRib.TabIndex = 2;
            radioButtonPrimeRib.TabStop = true;
            radioButtonPrimeRib.Text = "Prime Rib";
            radioButtonPrimeRib.UseVisualStyleBackColor = true;
            // 
            // textBoxEventCost
            // 
            textBoxEventCost.Location = new Point(142, 216);
            textBoxEventCost.Name = "textBoxEventCost";
            textBoxEventCost.ReadOnly = true;
            textBoxEventCost.Size = new Size(84, 23);
            textBoxEventCost.TabIndex = 5;
            // 
            // textBoxNumberofGuests
            // 
            textBoxNumberofGuests.Location = new Point(148, 36);
            textBoxNumberofGuests.Name = "textBoxNumberofGuests";
            textBoxNumberofGuests.Size = new Size(84, 23);
            textBoxNumberofGuests.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F);
            label2.Location = new Point(6, 217);
            label2.Name = "label2";
            label2.Size = new Size(75, 19);
            label2.TabIndex = 1;
            label2.Text = "Event Cost";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F);
            label1.Location = new Point(6, 37);
            label1.Name = "label1";
            label1.Size = new Size(121, 19);
            label1.TabIndex = 0;
            label1.Text = "Number of Guests";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(buttonClearAll);
            groupBox2.Controls.Add(textBoxTotalSales);
            groupBox2.Controls.Add(textBoxNumberofEvents);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(label3);
            groupBox2.Location = new Point(326, 36);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(246, 156);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Summary Info";
            // 
            // buttonClearAll
            // 
            buttonClearAll.Location = new Point(6, 122);
            buttonClearAll.Name = "buttonClearAll";
            buttonClearAll.Size = new Size(234, 26);
            buttonClearAll.TabIndex = 10;
            buttonClearAll.Text = "Clear All";
            buttonClearAll.UseVisualStyleBackColor = true;
            buttonClearAll.Click += buttonClearAll_Click;
            // 
            // textBoxTotalSales
            // 
            textBoxTotalSales.Location = new Point(156, 72);
            textBoxTotalSales.Name = "textBoxTotalSales";
            textBoxTotalSales.ReadOnly = true;
            textBoxTotalSales.Size = new Size(84, 23);
            textBoxTotalSales.TabIndex = 5;
            // 
            // textBoxNumberofEvents
            // 
            textBoxNumberofEvents.Location = new Point(156, 36);
            textBoxNumberofEvents.Name = "textBoxNumberofEvents";
            textBoxNumberofEvents.ReadOnly = true;
            textBoxNumberofEvents.Size = new Size(84, 23);
            textBoxNumberofEvents.TabIndex = 6;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10F);
            label4.Location = new Point(6, 73);
            label4.Name = "label4";
            label4.Size = new Size(72, 19);
            label4.TabIndex = 3;
            label4.Text = "Total Sales";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10F);
            label3.Location = new Point(6, 37);
            label3.Name = "label3";
            label3.Size = new Size(119, 19);
            label3.TabIndex = 2;
            label3.Text = "Number of Events";
            // 
            // buttonexit
            // 
            buttonexit.Location = new Point(332, 302);
            buttonexit.Name = "buttonexit";
            buttonexit.Size = new Size(234, 26);
            buttonexit.TabIndex = 11;
            buttonexit.Text = "E&xit";
            buttonexit.UseVisualStyleBackColor = true;
            buttonexit.Click += buttonexit_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10F);
            label5.Location = new Point(386, 373);
            label5.Name = "label5";
            label5.Size = new Size(56, 19);
            label5.TabIndex = 12;
            label5.Text = "Derek E";
            // 
            // Form1
            // 
            AcceptButton = buttonCalculate;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = buttonexit;
            ClientSize = new Size(800, 450);
            Controls.Add(label5);
            Controls.Add(buttonexit);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Catering Project";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox textBoxEventCost;
        private TextBox textBoxNumberofGuests;
        private Label label2;
        private Label label1;
        private GroupBox groupBox2;
        private TextBox textBoxNumberofEvents;
        private Label label4;
        private Label label3;
        private CheckBox checkBoxWineWithdinner;
        private CheckBox checkBoxBAR;
        private RadioButton radioButtonpasta;
        private RadioButton radioButtonChicken;
        private RadioButton radioButtonPrimeRib;
        private TextBox textBoxTotalSales;
        private Button buttonUpdateSummary;
        private Button buttonClear;
        private Button buttonCalculate;
        private Button buttonClearAll;
        private Button buttonexit;
        private Label label5;
    }
}
