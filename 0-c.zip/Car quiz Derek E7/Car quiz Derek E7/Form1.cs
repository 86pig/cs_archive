using System.CodeDom;

namespace Car_quiz_Derek_E7
{
    public partial class Form1 : Form
    {
        //assign constants
        const double COMPACT = 35.00;
        const double MID = 42.00;
        const double FULL = 48.00;
        const double SUV = 55.00;

        const double CARRACK = 12.00;
        const double EZ = 5.00;
        const double INSURANCE = 23.00;

        const double SALESTAX = 0.082;
        const double LOCALTAX = 0.01;
        const double STADIUMTAX = 0.02;

        int numofcarsrented = 0;
        double totalsales = 0;



        public Form1()
        {
            InitializeComponent();
            textBoxNumberofDays.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            //assign close button
            this.Close();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            //do the try catch, assing variables
            try
            {
                double subtotal, asubtotal, rentalprice = 0.00, rrentalprice, accesssories;
                double aaccessories = 0.00;
                int days;

                //create conditionals for radiobnuttons and checkboxes.
                if (radioButtonCompact.Checked) rrentalprice = COMPACT;
                else if (radioButtonMidsized.Checked) rrentalprice = MID;
                else if (radioButtonFullsizex.Checked) rrentalprice = FULL;
                else rrentalprice = SUV;

                if (checkBoxCARRACK.Checked) aaccessories += CARRACK;
                if (checkBoxezPAss.Checked) aaccessories += EZ;
                if (checkBoxINSURUanacne.Checked) aaccessories += INSURANCE;

                days = int.Parse(textBoxNumberofDays.Text);
                // test if days can be 0
                //do calculations 

                rentalprice = rrentalprice * days;
                accesssories = aaccessories * days;

                subtotal = rentalprice + accesssories;

                double salestax = 0, localtax = 0, stadiumtax = 0, totalamount;

                salestax = subtotal * SALESTAX;
                localtax = subtotal * LOCALTAX;
                stadiumtax = subtotal * STADIUMTAX;

                totalamount = subtotal + salestax + localtax + stadiumtax;

                //display calced info back to ui

                textBoxRentalPrice.Text = rentalprice.ToString("C");
                textBoxAccessories.Text = accesssories.ToString("C");
                textBoxSubtotal.Text = subtotal.ToString("C");
                textBoxSalestax.Text = salestax.ToString("C");
                textBoxLocaltax.Text = localtax.ToString("C");
                textBoxBaseballStadium.Text = stadiumtax.ToString("C");
                textBoxTotalDue.Text = totalamount.ToString("C");

                numofcarsrented++;
                totalsales += totalamount;
            }

            catch
            {
                //catch the invalid valuse
                MessageBox.Show("Invalid day value. Try again. ");
                textBoxNumberofDays.Clear();
                textBoxNumberofDays.Focus();
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            //reset all textboxes and checkboxes and readiobuttons
            radioButtonCompact.Checked = true;
            checkBoxCARRACK.Checked = false;
            checkBoxezPAss.Checked = false;
            checkBoxINSURUanacne.Checked = false;

            textBoxNumberofDays.Clear();
            textBoxRentalPrice.Clear();
            textBoxAccessories.Clear();
            textBoxSubtotal.Clear();
            textBoxSalestax.Clear();
            textBoxLocaltax.Clear();
            textBoxBaseballStadium.Clear();
            textBoxTotalDue.Clear();
            textBoxNumberofDays.Focus();


        }

        private void buttonSummary_Click(object sender, EventArgs e)
        {
            //get messagebox and get strings from the total added dailty valyes,
            string numba = numofcarsrented.ToString();
            string tatdasalz = totalsales.ToString("C");

            MessageBox.Show("Number of cars rented: " + numba + "\n" + "Total sales for the day: " + tatdasalz);

        }

        private void buttonClearSummary_Click(object sender, EventArgs e)
        {
            //set the messagebox to clear with yes no options to reset daily values
            DialogResult yesno = MessageBox.Show("Are you sure you want to clear summary information and reset the daily sales info?", "Alert!", MessageBoxButtons.YesNo);

            if (yesno == DialogResult.Yes)
            {
                numofcarsrented = 0;
                totalsales = 0;
                textBoxNumberofDays.Clear();
                textBoxNumberofDays.Focus();
            }

            else textBoxNumberofDays.Focus();


        }
    }
}
