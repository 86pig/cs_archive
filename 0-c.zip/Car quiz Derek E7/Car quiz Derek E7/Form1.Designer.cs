﻿namespace Car_quiz_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            radioButtonSUV = new RadioButton();
            radioButtonFullsizex = new RadioButton();
            radioButtonMidsized = new RadioButton();
            radioButtonCompact = new RadioButton();
            groupBox2 = new GroupBox();
            checkBoxINSURUanacne = new CheckBox();
            checkBoxezPAss = new CheckBox();
            checkBoxCARRACK = new CheckBox();
            groupBox3 = new GroupBox();
            buttonClearSummary = new Button();
            textBoxTotalDue = new TextBox();
            buttonSummary = new Button();
            label8 = new Label();
            textBoxBaseballStadium = new TextBox();
            label7 = new Label();
            textBoxLocaltax = new TextBox();
            label6 = new Label();
            textBoxSalestax = new TextBox();
            label5 = new Label();
            textBoxSubtotal = new TextBox();
            label4 = new Label();
            textBoxAccessories = new TextBox();
            label3 = new Label();
            textBoxRentalPrice = new TextBox();
            label2 = new Label();
            textBoxNumberofDays = new TextBox();
            label1 = new Label();
            buttonClear = new Button();
            buttonCalculate = new Button();
            buttonExit = new Button();
            label9 = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(radioButtonSUV);
            groupBox1.Controls.Add(radioButtonFullsizex);
            groupBox1.Controls.Add(radioButtonMidsized);
            groupBox1.Controls.Add(radioButtonCompact);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(248, 128);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Cars";
            // 
            // radioButtonSUV
            // 
            radioButtonSUV.AutoSize = true;
            radioButtonSUV.Location = new Point(6, 97);
            radioButtonSUV.Name = "radioButtonSUV";
            radioButtonSUV.Size = new Size(79, 19);
            radioButtonSUV.TabIndex = 3;
            radioButtonSUV.TabStop = true;
            radioButtonSUV.Text = "SUV $55/d";
            radioButtonSUV.UseVisualStyleBackColor = true;
            // 
            // radioButtonFullsizex
            // 
            radioButtonFullsizex.AutoSize = true;
            radioButtonFullsizex.Location = new Point(6, 72);
            radioButtonFullsizex.Name = "radioButtonFullsizex";
            radioButtonFullsizex.Size = new Size(103, 19);
            radioButtonFullsizex.TabIndex = 2;
            radioButtonFullsizex.TabStop = true;
            radioButtonFullsizex.Text = "Fullsized $48/d";
            radioButtonFullsizex.UseVisualStyleBackColor = true;
            // 
            // radioButtonMidsized
            // 
            radioButtonMidsized.AutoSize = true;
            radioButtonMidsized.Location = new Point(6, 47);
            radioButtonMidsized.Name = "radioButtonMidsized";
            radioButtonMidsized.Size = new Size(105, 19);
            radioButtonMidsized.TabIndex = 1;
            radioButtonMidsized.TabStop = true;
            radioButtonMidsized.Text = "Midsized $42/d";
            radioButtonMidsized.UseVisualStyleBackColor = true;
            // 
            // radioButtonCompact
            // 
            radioButtonCompact.AutoSize = true;
            radioButtonCompact.Location = new Point(6, 22);
            radioButtonCompact.Name = "radioButtonCompact";
            radioButtonCompact.Size = new Size(107, 19);
            radioButtonCompact.TabIndex = 0;
            radioButtonCompact.TabStop = true;
            radioButtonCompact.Text = "Compact $35/d";
            radioButtonCompact.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(checkBoxINSURUanacne);
            groupBox2.Controls.Add(checkBoxezPAss);
            groupBox2.Controls.Add(checkBoxCARRACK);
            groupBox2.Location = new Point(12, 146);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(248, 120);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Accessories";
            // 
            // checkBoxINSURUanacne
            // 
            checkBoxINSURUanacne.AutoSize = true;
            checkBoxINSURUanacne.Location = new Point(6, 72);
            checkBoxINSURUanacne.Name = "checkBoxINSURUanacne";
            checkBoxINSURUanacne.Size = new Size(118, 19);
            checkBoxINSURUanacne.TabIndex = 6;
            checkBoxINSURUanacne.Text = "Insurance +$23/d";
            checkBoxINSURUanacne.UseVisualStyleBackColor = true;
            // 
            // checkBoxezPAss
            // 
            checkBoxezPAss.AutoSize = true;
            checkBoxezPAss.Location = new Point(6, 47);
            checkBoxezPAss.Name = "checkBoxezPAss";
            checkBoxezPAss.Size = new Size(100, 19);
            checkBoxezPAss.TabIndex = 5;
            checkBoxezPAss.Text = "EZ pass +$5/d";
            checkBoxezPAss.UseVisualStyleBackColor = true;
            // 
            // checkBoxCARRACK
            // 
            checkBoxCARRACK.AutoSize = true;
            checkBoxCARRACK.Location = new Point(6, 22);
            checkBoxCARRACK.Name = "checkBoxCARRACK";
            checkBoxCARRACK.Size = new Size(110, 19);
            checkBoxCARRACK.TabIndex = 4;
            checkBoxCARRACK.Text = "Car rack +$12/d";
            checkBoxCARRACK.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(buttonClearSummary);
            groupBox3.Controls.Add(textBoxTotalDue);
            groupBox3.Controls.Add(buttonSummary);
            groupBox3.Controls.Add(label8);
            groupBox3.Controls.Add(textBoxBaseballStadium);
            groupBox3.Controls.Add(label7);
            groupBox3.Controls.Add(textBoxLocaltax);
            groupBox3.Controls.Add(label6);
            groupBox3.Controls.Add(textBoxSalestax);
            groupBox3.Controls.Add(label5);
            groupBox3.Controls.Add(textBoxSubtotal);
            groupBox3.Controls.Add(label4);
            groupBox3.Controls.Add(textBoxAccessories);
            groupBox3.Controls.Add(label3);
            groupBox3.Controls.Add(textBoxRentalPrice);
            groupBox3.Controls.Add(label2);
            groupBox3.Controls.Add(textBoxNumberofDays);
            groupBox3.Controls.Add(label1);
            groupBox3.Location = new Point(284, 12);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(276, 318);
            groupBox3.TabIndex = 2;
            groupBox3.TabStop = false;
            groupBox3.Text = "Rental Costs";
            // 
            // buttonClearSummary
            // 
            buttonClearSummary.Location = new Point(155, 267);
            buttonClearSummary.Name = "buttonClearSummary";
            buttonClearSummary.Size = new Size(115, 45);
            buttonClearSummary.TabIndex = 20;
            buttonClearSummary.Text = "Clear summary";
            buttonClearSummary.UseVisualStyleBackColor = true;
            buttonClearSummary.Click += buttonClearSummary_Click;
            // 
            // textBoxTotalDue
            // 
            textBoxTotalDue.Location = new Point(94, 224);
            textBoxTotalDue.Name = "textBoxTotalDue";
            textBoxTotalDue.ReadOnly = true;
            textBoxTotalDue.Size = new Size(100, 23);
            textBoxTotalDue.TabIndex = 15;
            // 
            // buttonSummary
            // 
            buttonSummary.Location = new Point(6, 267);
            buttonSummary.Name = "buttonSummary";
            buttonSummary.Size = new Size(115, 45);
            buttonSummary.TabIndex = 19;
            buttonSummary.Text = "Summary";
            buttonSummary.UseVisualStyleBackColor = true;
            buttonSummary.Click += buttonSummary_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 10F);
            label8.Location = new Point(6, 225);
            label8.Name = "label8";
            label8.Size = new Size(65, 19);
            label8.TabIndex = 14;
            label8.Text = "Total due";
            // 
            // textBoxBaseballStadium
            // 
            textBoxBaseballStadium.Location = new Point(170, 195);
            textBoxBaseballStadium.Name = "textBoxBaseballStadium";
            textBoxBaseballStadium.ReadOnly = true;
            textBoxBaseballStadium.Size = new Size(100, 23);
            textBoxBaseballStadium.TabIndex = 13;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 10F);
            label7.Location = new Point(6, 196);
            label7.Name = "label7";
            label7.Size = new Size(156, 19);
            label7.TabIndex = 12;
            label7.Text = "2% Baseball stadium tax";
            // 
            // textBoxLocaltax
            // 
            textBoxLocaltax.Location = new Point(94, 166);
            textBoxLocaltax.Name = "textBoxLocaltax";
            textBoxLocaltax.ReadOnly = true;
            textBoxLocaltax.Size = new Size(100, 23);
            textBoxLocaltax.TabIndex = 11;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 10F);
            label6.Location = new Point(6, 167);
            label6.Name = "label6";
            label6.Size = new Size(81, 19);
            label6.TabIndex = 10;
            label6.Text = "1% local tax";
            // 
            // textBoxSalestax
            // 
            textBoxSalestax.Location = new Point(144, 134);
            textBoxSalestax.Name = "textBoxSalestax";
            textBoxSalestax.ReadOnly = true;
            textBoxSalestax.Size = new Size(100, 23);
            textBoxSalestax.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10F);
            label5.Location = new Point(6, 138);
            label5.Name = "label5";
            label5.Size = new Size(94, 19);
            label5.TabIndex = 8;
            label5.Text = "8.2% sales tax";
            // 
            // textBoxSubtotal
            // 
            textBoxSubtotal.Location = new Point(94, 108);
            textBoxSubtotal.Name = "textBoxSubtotal";
            textBoxSubtotal.ReadOnly = true;
            textBoxSubtotal.Size = new Size(100, 23);
            textBoxSubtotal.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10F);
            label4.Location = new Point(6, 109);
            label4.Name = "label4";
            label4.Size = new Size(60, 19);
            label4.TabIndex = 6;
            label4.Text = "Subtotal";
            // 
            // textBoxAccessories
            // 
            textBoxAccessories.Location = new Point(94, 79);
            textBoxAccessories.Name = "textBoxAccessories";
            textBoxAccessories.ReadOnly = true;
            textBoxAccessories.Size = new Size(100, 23);
            textBoxAccessories.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10F);
            label3.Location = new Point(6, 80);
            label3.Name = "label3";
            label3.Size = new Size(78, 19);
            label3.TabIndex = 4;
            label3.Text = "Accessories";
            // 
            // textBoxRentalPrice
            // 
            textBoxRentalPrice.Location = new Point(94, 50);
            textBoxRentalPrice.Name = "textBoxRentalPrice";
            textBoxRentalPrice.ReadOnly = true;
            textBoxRentalPrice.Size = new Size(100, 23);
            textBoxRentalPrice.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F);
            label2.Location = new Point(6, 51);
            label2.Name = "label2";
            label2.Size = new Size(80, 19);
            label2.TabIndex = 2;
            label2.Text = "Rental price";
            // 
            // textBoxNumberofDays
            // 
            textBoxNumberofDays.Location = new Point(94, 21);
            textBoxNumberofDays.Name = "textBoxNumberofDays";
            textBoxNumberofDays.Size = new Size(100, 23);
            textBoxNumberofDays.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F);
            label1.Location = new Point(6, 22);
            label1.Name = "label1";
            label1.Size = new Size(65, 19);
            label1.TabIndex = 0;
            label1.Text = "# of days";
            // 
            // buttonClear
            // 
            buttonClear.Location = new Point(145, 285);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(115, 45);
            buttonClear.TabIndex = 17;
            buttonClear.Text = "Clear";
            buttonClear.UseVisualStyleBackColor = true;
            buttonClear.Click += buttonClear_Click;
            // 
            // buttonCalculate
            // 
            buttonCalculate.Location = new Point(12, 285);
            buttonCalculate.Name = "buttonCalculate";
            buttonCalculate.Size = new Size(115, 45);
            buttonCalculate.TabIndex = 16;
            buttonCalculate.Text = "Calculate";
            buttonCalculate.UseVisualStyleBackColor = true;
            buttonCalculate.Click += buttonCalculate_Click;
            // 
            // buttonExit
            // 
            buttonExit.Location = new Point(587, 355);
            buttonExit.Name = "buttonExit";
            buttonExit.Size = new Size(115, 45);
            buttonExit.TabIndex = 18;
            buttonExit.Text = "E&xit";
            buttonExit.UseVisualStyleBackColor = true;
            buttonExit.Click += buttonExit_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(255, 347);
            label9.Name = "label9";
            label9.Size = new Size(52, 15);
            label9.TabIndex = 19;
            label9.Text = "Derek E7";
            // 
            // Form1
            // 
            AcceptButton = buttonCalculate;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = buttonExit;
            ClientSize = new Size(800, 450);
            Controls.Add(label9);
            Controls.Add(buttonClear);
            Controls.Add(buttonCalculate);
            Controls.Add(buttonExit);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Quiz 3+4";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private RadioButton radioButtonSUV;
        private RadioButton radioButtonFullsizex;
        private RadioButton radioButtonMidsized;
        private RadioButton radioButtonCompact;
        private GroupBox groupBox2;
        private CheckBox checkBoxINSURUanacne;
        private CheckBox checkBoxezPAss;
        private CheckBox checkBoxCARRACK;
        private GroupBox groupBox3;
        private Button buttonClear;
        private Button buttonCalculate;
        private TextBox textBoxTotalDue;
        private Label label8;
        private TextBox textBoxBaseballStadium;
        private Label label7;
        private TextBox textBoxLocaltax;
        private Label label6;
        private TextBox textBoxSalestax;
        private Label label5;
        private TextBox textBoxSubtotal;
        private Label label4;
        private TextBox textBoxAccessories;
        private Label label3;
        private TextBox textBoxRentalPrice;
        private Label label2;
        private TextBox textBoxNumberofDays;
        private Label label1;
        private Button buttonExit;
        private Button buttonSummary;
        private Button buttonClearSummary;
        private Label label9;
    }
}
