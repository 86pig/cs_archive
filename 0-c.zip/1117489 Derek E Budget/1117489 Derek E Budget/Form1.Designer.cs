﻿namespace _1117489_Derek_E_Budget
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            textBoxNetPay = new TextBox();
            textBoxDeductions = new TextBox();
            textBoxGrossPay = new TextBox();
            textBoxSales = new TextBox();
            textBoxName = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            groupBox2 = new GroupBox();
            textBoxMisc = new TextBox();
            textBoxEntertainment = new TextBox();
            textBoxFoodandClothing = new TextBox();
            textBoxHousing = new TextBox();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            labelName = new Label();
            buttonCalculate = new Button();
            buttonClear = new Button();
            buttonExit = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBoxNetPay);
            groupBox1.Controls.Add(textBoxDeductions);
            groupBox1.Controls.Add(textBoxGrossPay);
            groupBox1.Controls.Add(textBoxSales);
            groupBox1.Controls.Add(textBoxName);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Location = new Point(48, 41);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(228, 200);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Take home pay";
            // 
            // textBoxNetPay
            // 
            textBoxNetPay.Location = new Point(80, 147);
            textBoxNetPay.Name = "textBoxNetPay";
            textBoxNetPay.ReadOnly = true;
            textBoxNetPay.ShortcutsEnabled = false;
            textBoxNetPay.Size = new Size(142, 23);
            textBoxNetPay.TabIndex = 3;
            // 
            // textBoxDeductions
            // 
            textBoxDeductions.AcceptsReturn = true;
            textBoxDeductions.Location = new Point(80, 117);
            textBoxDeductions.Name = "textBoxDeductions";
            textBoxDeductions.ReadOnly = true;
            textBoxDeductions.ShortcutsEnabled = false;
            textBoxDeductions.Size = new Size(142, 23);
            textBoxDeductions.TabIndex = 8;
            // 
            // textBoxGrossPay
            // 
            textBoxGrossPay.AcceptsReturn = true;
            textBoxGrossPay.Location = new Point(80, 87);
            textBoxGrossPay.Name = "textBoxGrossPay";
            textBoxGrossPay.ReadOnly = true;
            textBoxGrossPay.ShortcutsEnabled = false;
            textBoxGrossPay.Size = new Size(142, 23);
            textBoxGrossPay.TabIndex = 3;
            // 
            // textBoxSales
            // 
            textBoxSales.AcceptsTab = true;
            textBoxSales.Location = new Point(80, 57);
            textBoxSales.Name = "textBoxSales";
            textBoxSales.Size = new Size(142, 23);
            textBoxSales.TabIndex = 7;
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(80, 27);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(142, 23);
            textBoxName.TabIndex = 2;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(6, 150);
            label6.Name = "label6";
            label6.Size = new Size(48, 15);
            label6.TabIndex = 6;
            label6.Text = "Net Pay";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(6, 120);
            label5.Name = "label5";
            label5.Size = new Size(67, 15);
            label5.TabIndex = 5;
            label5.Text = "Deductions";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 90);
            label4.Name = "label4";
            label4.Size = new Size(58, 15);
            label4.TabIndex = 4;
            label4.Text = "Gross Pay";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 60);
            label3.Name = "label3";
            label3.Size = new Size(33, 15);
            label3.TabIndex = 3;
            label3.Text = "Sales";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 30);
            label2.Name = "label2";
            label2.Size = new Size(39, 15);
            label2.TabIndex = 2;
            label2.Text = "Name";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(textBoxMisc);
            groupBox2.Controls.Add(textBoxEntertainment);
            groupBox2.Controls.Add(textBoxFoodandClothing);
            groupBox2.Controls.Add(textBoxHousing);
            groupBox2.Controls.Add(label10);
            groupBox2.Controls.Add(label9);
            groupBox2.Controls.Add(label8);
            groupBox2.Controls.Add(label7);
            groupBox2.Location = new Point(312, 41);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(278, 200);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Budget";
            // 
            // textBoxMisc
            // 
            textBoxMisc.AcceptsReturn = true;
            textBoxMisc.Location = new Point(130, 117);
            textBoxMisc.Name = "textBoxMisc";
            textBoxMisc.ReadOnly = true;
            textBoxMisc.ShortcutsEnabled = false;
            textBoxMisc.Size = new Size(142, 23);
            textBoxMisc.TabIndex = 3;
            // 
            // textBoxEntertainment
            // 
            textBoxEntertainment.AcceptsReturn = true;
            textBoxEntertainment.Location = new Point(130, 87);
            textBoxEntertainment.Name = "textBoxEntertainment";
            textBoxEntertainment.ReadOnly = true;
            textBoxEntertainment.ShortcutsEnabled = false;
            textBoxEntertainment.Size = new Size(142, 23);
            textBoxEntertainment.TabIndex = 3;
            // 
            // textBoxFoodandClothing
            // 
            textBoxFoodandClothing.AcceptsReturn = true;
            textBoxFoodandClothing.Location = new Point(130, 57);
            textBoxFoodandClothing.Name = "textBoxFoodandClothing";
            textBoxFoodandClothing.ReadOnly = true;
            textBoxFoodandClothing.ShortcutsEnabled = false;
            textBoxFoodandClothing.Size = new Size(142, 23);
            textBoxFoodandClothing.TabIndex = 3;
            // 
            // textBoxHousing
            // 
            textBoxHousing.AcceptsReturn = true;
            textBoxHousing.Location = new Point(130, 27);
            textBoxHousing.Name = "textBoxHousing";
            textBoxHousing.ReadOnly = true;
            textBoxHousing.ShortcutsEnabled = false;
            textBoxHousing.Size = new Size(142, 23);
            textBoxHousing.TabIndex = 3;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(6, 120);
            label10.Name = "label10";
            label10.Size = new Size(35, 15);
            label10.TabIndex = 6;
            label10.Text = "Misc.";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(6, 90);
            label9.Name = "label9";
            label9.Size = new Size(82, 15);
            label9.TabIndex = 5;
            label9.Text = "Entertainment";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(6, 60);
            label8.Name = "label8";
            label8.Size = new Size(106, 15);
            label8.TabIndex = 4;
            label8.Text = "Food and Clothing";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(6, 30);
            label7.Name = "label7";
            label7.Size = new Size(52, 15);
            label7.TabIndex = 3;
            label7.Text = "Housing";
            // 
            // labelName
            // 
            labelName.AutoSize = true;
            labelName.Location = new Point(544, 288);
            labelName.Name = "labelName";
            labelName.Size = new Size(46, 15);
            labelName.TabIndex = 0;
            labelName.Text = "Derek E";
            // 
            // buttonCalculate
            // 
            buttonCalculate.Location = new Point(48, 260);
            buttonCalculate.Name = "buttonCalculate";
            buttonCalculate.Size = new Size(128, 43);
            buttonCalculate.TabIndex = 7;
            buttonCalculate.Text = "C&alculate";
            buttonCalculate.UseVisualStyleBackColor = true;
            buttonCalculate.Click += buttonCalculate_Click;
            // 
            // buttonClear
            // 
            buttonClear.Location = new Point(197, 260);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(128, 43);
            buttonClear.TabIndex = 8;
            buttonClear.Text = "&Clear";
            buttonClear.UseVisualStyleBackColor = true;
            buttonClear.Click += buttonClear_Click;
            // 
            // buttonExit
            // 
            buttonExit.Location = new Point(400, 260);
            buttonExit.Name = "buttonExit";
            buttonExit.Size = new Size(128, 43);
            buttonExit.TabIndex = 9;
            buttonExit.Text = "E&xit";
            buttonExit.UseVisualStyleBackColor = true;
            buttonExit.Click += buttonExit_Click;
            // 
            // Form1
            // 
            AcceptButton = buttonCalculate;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = buttonExit;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonExit);
            Controls.Add(buttonClear);
            Controls.Add(buttonCalculate);
            Controls.Add(labelName);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Budget Project";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox textBoxSales;
        private TextBox textBoxName;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private GroupBox groupBox2;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label labelName;
        private TextBox textBoxNetPay;
        private TextBox textBoxDeductions;
        private TextBox textBoxGrossPay;
        private TextBox textBoxMisc;
        private TextBox textBoxEntertainment;
        private TextBox textBoxFoodandClothing;
        private TextBox textBoxHousing;
        private Button buttonCalculate;
        private Button buttonClear;
        private Button buttonExit;
    }
}
