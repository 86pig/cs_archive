namespace _1117489_Derek_E_Budget
{
    public partial class Form1 : Form
    {
        const int BASEPAY = 900;
        const double COMMISSION = 0.06;
        const double DEDUCTIONS = 0.18;
        const double HOUSING = 0.3;
        const double FOODANDCLOTHING = 0.15;
        const double ENTERTAINMENT = 0.5;
        const double MISC = 0.05;

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            double commission, deductions, grosspay, netpay, housing, entertainment, foodandclothing, misc;
            int sales;

            try
            {
                sales = int.Parse(textBoxSales.Text);
                commission = sales * COMMISSION;
                grosspay = BASEPAY + commission;
                deductions = grosspay * DEDUCTIONS;
                netpay = grosspay - deductions;
                housing = netpay * HOUSING;
                foodandclothing = netpay * FOODANDCLOTHING;
                entertainment = netpay * ENTERTAINMENT;
                misc = netpay * MISC;

                textBoxGrossPay.Text = grosspay.ToString("C");
                textBoxDeductions.Text = deductions.ToString("C");
                textBoxNetPay.Text = netpay.ToString("C");
                textBoxHousing.Text = housing.ToString("C");
                textBoxFoodandClothing.Text = foodandclothing.ToString("C");
                textBoxMisc.Text = misc.ToString("C");
                textBoxEntertainment.Text = entertainment.ToString("C");
                labelName.Focus();


            }
            catch
            {
                MessageBox.Show("Enter a nubmerrrrrrrrrrrrrrrrrrrrrrrrrr!!!");
                textBoxGrossPay.Clear();
                textBoxDeductions.Clear();
                textBoxNetPay.Clear();
                textBoxHousing.Clear();
                textBoxFoodandClothing.Clear();
                textBoxMisc.Clear();
                textBoxName.Clear();
                textBoxEntertainment.Clear();
                textBoxSales.Clear();
                textBoxName.Focus();

            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxGrossPay.Clear();
            textBoxDeductions.Clear();
            textBoxNetPay.Clear();
            textBoxHousing.Clear();
            textBoxFoodandClothing.Clear();
            textBoxMisc.Clear();
            textBoxName.Clear();
            textBoxEntertainment.Clear();
            textBoxSales.Clear();
            textBoxName.Focus();
        }
    }
}
