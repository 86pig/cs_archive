using Microsoft.VisualBasic;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Drawing;
using System.Drawing.Imaging;
using System.Net.Sockets;
using System.Reflection.Metadata;


namespace Black_Box_Derek_E7
{
    public partial class Form1 : Form
    {
        List<Contacts> contacts = new List<Contacts>();
        //    List<string[]> list = new List<string[]>();


        const string DATAFILE = "contacts.csv";
        public Form1()
        {
            //adress[] adresses = new address[3]
            //  adress[0] = new Address("111 main st, ", nuill, "bellvue", "wa,", "980003");

            InitializeComponent();
            //FileInfo fi = new FileInfo(DATAFILE);
            //if (fi.Exists)
            //{
            //    contacts = OpenFromFile(DATAFILE);
            //    //information = ReadFromFile(DATAFILE);
            //    foreach (Contacts info in contacts)
            //    {
            //        listBoxcontax.Items.Add(info.Name);
            //    }

            //}
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(textBoxName.Text) &&
                    !string.IsNullOrEmpty(maskedTextBoxNumber.Text) &&
                    !string.IsNullOrEmpty(textBoxEmail.Text))
                {
                    string name = textBoxName.Text;
                    string cellphone = maskedTextBoxNumber.Text;
                    string email = textBoxEmail.Text;

                    Contacts contact = new Contacts(name, cellphone, email);

                    contacts.Add(contact);
                    listBoxcontax.Items.Add(contact.Name);

                    SavetoFile(contacts);
                }
                else
                {
                    MessageBox.Show("fill in all fields");
                }

            }
            catch
            {
                MessageBox.Show("invalid input");
            }



            //int i = listBoxcontax.SelectedIndex;
            //Contacts info;
            //string name = textBoxName.Text;
            //string number = maskedTextBoxNumber.Text;
            //string email = textBoxEmail.Text;
            //if (textBoxName.Text == string.Empty) MessageBox.Show("Enter all fields of info.");
            //if (maskedTextBoxNumber.Text == string.Empty) MessageBox.Show("Enter all fields of info.");
            //if (textBoxEmail.Text == string.Empty) MessageBox.Show("Enter all fields of info.");
            //else
            //{
            //    try
            //    {
            //        info = new Contacts(name, number, email);
            //        information.Add(info);
            //        listBoxcontax.Items.Add(textBoxName.Text);
            //    }
            //    catch
            //    {
            //        MessageBox.Show("Invalid input try again.");
            //        return;
            //    }

            //    SavetoFile(DATAFILE);

            //string formattedString = string.Format("Name: {0}, Number: {1}, Email: {2}", name, number, email);
            ////textBoxName.Text = formattedString;



            ////List<string[]> list = new List<string[]>();
            //string input = "contacts.csv";
            //StreamReader sr = new StreamReader(input);
            //string line = sr.ReadLine();
            //while (line != null)
            //{
            //    string[] arr = line.Split(",");
            //    list.Add(arr);
            //    line = sr.ReadLine();
            //}
            ////SavetoFile(formattedString);
            //sr.Close();


        }

        private static List<Contacts> OpenFromFile(string filename)
        {

            List<Contacts> list = new List<Contacts>();
            StreamReader streamReader = new StreamReader(filename);
            string line = streamReader.ReadLine();

            while (line != null)
            {
                string[] record = line.Split(',');
                Contacts contact = new Contacts(record[0], record[1], record[2]);
                list.Add(contact);

                line = streamReader.ReadLine();

            }
            streamReader.Close();
            return list;
        }

        private static void SavetoFile(List<Contacts> contacts)
        {
            // List<Contacts> list = new List<Contacts>();
            StreamWriter sw = new StreamWriter(DATAFILE);
            foreach (Contacts contact in contacts)
            {
                string output = contact.Name + "," + contact.Phone + "," + contact.Email;
                sw.WriteLine(output);

            }

            sw.Flush();
            sw.Close();
        }

        private void buttonRemove_Click(object sender, EventArgs e)
        {
            if (listBoxcontax.SelectedIndex != -1)
            {
                int i = listBoxcontax.SelectedIndex;
                listBoxcontax.Items.RemoveAt(i);
                contacts.RemoveAt(i);

                listBoxcontax.SelectedIndex = -1;
                textBoxName.Focus();
            }
            else
            {
                MessageBox.Show("Please select a contact.");
            }
            //int i = listBoxcontax.SelectedIndex;
            //if (listBoxcontax.SelectedIndex == -1) MessageBox.Show("Select a contact to remove!");
            //else
            //{
            //    listBoxcontax.Items.RemoveAt(listBoxcontax.SelectedIndex);
            //    information.RemoveAt(i);
            //    SavetoFile(DATAFILE);

            //    listBoxcontax.SelectedIndex = -1;
            //    textBoxName.Focus();
            //}
        }

        private void listBoxcontax_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxcontax.SelectedIndex == -1) return;
            else
            {
                int i = listBoxcontax.SelectedIndex;
                textBoxName.Text = contacts[i].Name;
                maskedTextBoxNumber.Text = contacts[i].Phone;
                textBoxEmail.Text = contacts[i].Email;
                textBoxName.Focus();
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            FileInfo fileInfo = new FileInfo(DATAFILE);

            if (fileInfo.Exists)
            {
                contacts = OpenFromFile(DATAFILE);

                foreach (Contacts contact in contacts)
                {
                    listBoxcontax.Items.Add(contact.Name);
                }
            }

            //string input = "contacts.csv";
            //StreamWriter sw = new StreamWriter(input);
            //foreach (string[] arr in list)
            //{
            //    string output = string.Join(",", arr);
            //    sw.WriteLine(output);
            //}
            //sw.Flush();
            //sw.Close();

            //FileInfo fi = new FileInfo(DATAFILE);
            //if (fi.Exists)
            //{
            //    //information = ReadFromFile(DATAFILE);
            //    foreach (Contacts info in contacts)
            //    {
            //        listBoxcontax.Items.Add(info.Name);
            //    }

            //}

        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxName.Clear();
            maskedTextBoxNumber.Clear();
            textBoxEmail.Clear();
            listBoxcontax.SelectedIndex = -1;
            textBoxName.Clear();
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
    
        }

        private void Form1_FormClosing_1(object sender, FormClosingEventArgs e)
        {
            //MessageBox.Show("form closing");
            SavetoFile(contacts);
        }
    }
}
