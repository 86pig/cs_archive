﻿namespace Black_Box_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBoxName = new TextBox();
            label2 = new Label();
            textBoxEmail = new TextBox();
            maskedTextBoxNumber = new MaskedTextBox();
            buttonAdd = new Button();
            buttonRemove = new Button();
            label3 = new Label();
            label4 = new Label();
            listBoxcontax = new ListBox();
            buttonClear = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 18F);
            label1.Location = new Point(28, 25);
            label1.Name = "label1";
            label1.Size = new Size(84, 29);
            label1.TabIndex = 0;
            label1.Text = "Name:";
            // 
            // textBoxName
            // 
            textBoxName.Font = new Font("Microsoft Sans Serif", 18F);
            textBoxName.Location = new Point(164, 22);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(186, 35);
            textBoxName.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 18F);
            label2.Location = new Point(28, 72);
            label2.Name = "label2";
            label2.Size = new Size(89, 29);
            label2.TabIndex = 2;
            label2.Text = "Phone:";
            // 
            // textBoxEmail
            // 
            textBoxEmail.Font = new Font("Microsoft Sans Serif", 18F);
            textBoxEmail.Location = new Point(164, 116);
            textBoxEmail.Name = "textBoxEmail";
            textBoxEmail.Size = new Size(186, 35);
            textBoxEmail.TabIndex = 5;
            // 
            // maskedTextBoxNumber
            // 
            maskedTextBoxNumber.Font = new Font("Microsoft Sans Serif", 18F);
            maskedTextBoxNumber.Location = new Point(164, 69);
            maskedTextBoxNumber.Mask = "(999) 000-0000";
            maskedTextBoxNumber.Name = "maskedTextBoxNumber";
            maskedTextBoxNumber.Size = new Size(186, 35);
            maskedTextBoxNumber.TabIndex = 6;
            // 
            // buttonAdd
            // 
            buttonAdd.Font = new Font("Microsoft Sans Serif", 18F);
            buttonAdd.Location = new Point(28, 178);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(148, 74);
            buttonAdd.TabIndex = 7;
            buttonAdd.Text = "Add";
            buttonAdd.UseVisualStyleBackColor = true;
            buttonAdd.Click += buttonAdd_Click;
            // 
            // buttonRemove
            // 
            buttonRemove.Font = new Font("Microsoft Sans Serif", 18F);
            buttonRemove.Location = new Point(202, 178);
            buttonRemove.Name = "buttonRemove";
            buttonRemove.Size = new Size(148, 74);
            buttonRemove.TabIndex = 8;
            buttonRemove.Text = "Remove";
            buttonRemove.UseVisualStyleBackColor = true;
            buttonRemove.Click += buttonRemove_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 18F);
            label3.Location = new Point(28, 119);
            label3.Name = "label3";
            label3.Size = new Size(80, 29);
            label3.TabIndex = 4;
            label3.Text = "Email:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 18F);
            label4.Location = new Point(406, 16);
            label4.Name = "label4";
            label4.Size = new Size(130, 29);
            label4.TabIndex = 9;
            label4.Text = "Contact list";
            // 
            // listBoxcontax
            // 
            listBoxcontax.Font = new Font("Microsoft Sans Serif", 18F);
            listBoxcontax.FormattingEnabled = true;
            listBoxcontax.ItemHeight = 29;
            listBoxcontax.Location = new Point(416, 108);
            listBoxcontax.Name = "listBoxcontax";
            listBoxcontax.Size = new Size(331, 120);
            listBoxcontax.TabIndex = 10;
            listBoxcontax.SelectedIndexChanged += listBoxcontax_SelectedIndexChanged;
            // 
            // buttonClear
            // 
            buttonClear.Font = new Font("Microsoft Sans Serif", 18F);
            buttonClear.Location = new Point(599, 2);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(148, 74);
            buttonClear.TabIndex = 11;
            buttonClear.Text = "Clear";
            buttonClear.UseVisualStyleBackColor = true;
            buttonClear.Click += buttonClear_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(782, 284);
            Controls.Add(buttonClear);
            Controls.Add(listBoxcontax);
            Controls.Add(label4);
            Controls.Add(buttonRemove);
            Controls.Add(buttonAdd);
            Controls.Add(maskedTextBoxNumber);
            Controls.Add(textBoxEmail);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(textBoxName);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Xiao Hei Shu";
            FormClosing += Form1_FormClosing_1;
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBoxName;
        private Label label2;
        private TextBox textBoxEmail;
        private MaskedTextBox maskedTextBoxNumber;
        private Button buttonAdd;
        private Button buttonRemove;
        private Label label3;
        private Label label4;
        private ListBox listBoxcontax;
        private Button buttonClear;
    }
}
