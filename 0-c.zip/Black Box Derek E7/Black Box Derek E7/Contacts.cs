﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Black_Box_Derek_E7
{
    public class Contacts
    {
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }  
        public Contacts(string n, string p, string e)
        {
            Name = n;
            Phone = p;
            Email = e;
        }
    }
}
