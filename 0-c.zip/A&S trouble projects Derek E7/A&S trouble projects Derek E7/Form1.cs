using System.Runtime.ExceptionServices;

namespace A_S_trouble_projects_Derek_E7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private bool icyHot(int i, int h)
        {
            if (i < 0 || i > 100 || h < 0 || h > 100)
            {
                if (i < 0 && h > 100) return true;
                else if (i > 100 && h < 0) return true;
                else return false;
            }
            else return false;
        }

        private void icyHotToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int first = int.Parse(textBoxTemp1.Text);
            int second = int.Parse(textBoxTemp2.Text);
            bool icyhot = icyHot(first, second);
            if (icyhot == true) textBoxIcyHotYes.Text = "True";
            else textBoxIcyHotYes.Text = "False";
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private string ClassDetermine(int w)
        {
            if (w <= 100) return "You're lighter than a fly";
            else if (w <= 105) return "Mini flyweight";
            else if (w <= 108) return "Junior flyweight";
            else if (w <= 112) return "Flyweight";
            else if (w <= 115) return "Junior Bantamweight";
            else if (w <= 118) return "Bantamweight";
            else if (w <= 122) return "Junior featherweight";
            else if (w <= 126) return "Featherweight";
            else if (w <= 130) return "Junior lightweight";
            else if (w <= 135) return "Lightweight";
            else if (w <= 140) return "Junior welterweight";
            else if (w <= 147) return "Welterweight";
            else if (w <= 156) return "Junior middleweight";
            else if (w <= 160) return "Middleweight";
            else if (w <= 175) return "Junior heavyweight";
            else if (w > 175) return "Heavyweight";
            else return "Error";
        }


        private void weightClassToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int weight = int.Parse(textBoxWeight.Text);
            string clas = ClassDetermine(weight);
            textBoxClass.Text = clas;
        }

        private bool PickupPhone(bool s, bool m, bool u)
        {
            bool a = false;
            if (s = false)
            {
                if (m = false)
                {
                    if (u = false) return a = true;
                    if (u = true) return a = false;
                }
                if (m = true) return a = true;
            }
            if (s = true) return a = false;
          //  else return a = false;
            return a;
        }



        private void phoneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool sleeping = false, morning = false , mom = false;
            if (checkBoxSleeping.Checked) sleeping = true;
            if (checkBoxMorning.Checked) morning = true;
            if (checkBoxMom.Checked) mom = true;

            bool pickup = PickupPhone(sleeping, morning, mom);
            if (pickup = true) textBoxAnswer.Text = "True.";
            else if (pickup = false) textBoxAnswer.Text = "False.";
        }
    }
}
