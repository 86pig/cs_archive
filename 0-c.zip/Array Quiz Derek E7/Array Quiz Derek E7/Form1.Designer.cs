﻿namespace Array_Quiz_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            label1 = new Label();
            textBoxName = new TextBox();
            textBoxhits = new TextBox();
            label2 = new Label();
            textBoxStrength = new TextBox();
            label3 = new Label();
            checkBoxAlive = new CheckBox();
            listBoxPlayers = new ListBox();
            buttonAdd = new Button();
            buttonClear = new Button();
            buttonPrint = new Button();
            label4 = new Label();
            buttonallclear = new Button();
            printDocumentPlayers = new System.Drawing.Printing.PrintDocument();
            printPreviewDialogPlayers = new PrintPreviewDialog();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(43, 43);
            label1.Name = "label1";
            label1.Size = new Size(39, 15);
            label1.TabIndex = 0;
            label1.Text = "Name";
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(121, 40);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(100, 23);
            textBoxName.TabIndex = 1;
            // 
            // textBoxhits
            // 
            textBoxhits.Location = new Point(121, 69);
            textBoxhits.Name = "textBoxhits";
            textBoxhits.Size = new Size(100, 23);
            textBoxhits.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(43, 72);
            label2.Name = "label2";
            label2.Size = new Size(28, 15);
            label2.TabIndex = 2;
            label2.Text = "Hits";
            // 
            // textBoxStrength
            // 
            textBoxStrength.Location = new Point(121, 98);
            textBoxStrength.Name = "textBoxStrength";
            textBoxStrength.Size = new Size(100, 23);
            textBoxStrength.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(43, 101);
            label3.Name = "label3";
            label3.Size = new Size(52, 15);
            label3.TabIndex = 4;
            label3.Text = "Strength";
            // 
            // checkBoxAlive
            // 
            checkBoxAlive.AutoSize = true;
            checkBoxAlive.Location = new Point(169, 127);
            checkBoxAlive.Name = "checkBoxAlive";
            checkBoxAlive.Size = new Size(52, 19);
            checkBoxAlive.TabIndex = 6;
            checkBoxAlive.Text = "Alive";
            checkBoxAlive.UseVisualStyleBackColor = true;
            checkBoxAlive.CheckedChanged += checkBoxAlive_CheckedChanged;
            // 
            // listBoxPlayers
            // 
            listBoxPlayers.FormattingEnabled = true;
            listBoxPlayers.ItemHeight = 15;
            listBoxPlayers.Location = new Point(243, 70);
            listBoxPlayers.Name = "listBoxPlayers";
            listBoxPlayers.Size = new Size(100, 169);
            listBoxPlayers.TabIndex = 7;
            listBoxPlayers.SelectedIndexChanged += listBoxPlayers_SelectedIndexChanged;
            // 
            // buttonAdd
            // 
            buttonAdd.Location = new Point(43, 152);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(178, 44);
            buttonAdd.TabIndex = 8;
            buttonAdd.Text = "Add";
            buttonAdd.UseVisualStyleBackColor = true;
            buttonAdd.Click += buttonAdd_Click;
            // 
            // buttonClear
            // 
            buttonClear.Location = new Point(43, 202);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(178, 44);
            buttonClear.TabIndex = 9;
            buttonClear.Text = "Clear";
            buttonClear.UseVisualStyleBackColor = true;
            buttonClear.Click += buttonClear_Click;
            // 
            // buttonPrint
            // 
            buttonPrint.Location = new Point(43, 252);
            buttonPrint.Name = "buttonPrint";
            buttonPrint.Size = new Size(178, 44);
            buttonPrint.TabIndex = 10;
            buttonPrint.Text = "Print living";
            buttonPrint.UseVisualStyleBackColor = true;
            buttonPrint.Click += buttonPrint_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(243, 45);
            label4.Name = "label4";
            label4.Size = new Size(44, 15);
            label4.TabIndex = 11;
            label4.Text = "Players";
            // 
            // buttonallclear
            // 
            buttonallclear.Location = new Point(243, 252);
            buttonallclear.Name = "buttonallclear";
            buttonallclear.Size = new Size(100, 44);
            buttonallclear.TabIndex = 12;
            buttonallclear.Text = "Clear player list";
            buttonallclear.UseVisualStyleBackColor = true;
            buttonallclear.Click += buttonallclear_Click;
            // 
            // printDocumentPlayers
            // 
            printDocumentPlayers.PrintPage += printDocumentPlayers_PrintPage;
            // 
            // printPreviewDialogPlayers
            // 
            printPreviewDialogPlayers.AutoScrollMargin = new Size(0, 0);
            printPreviewDialogPlayers.AutoScrollMinSize = new Size(0, 0);
            printPreviewDialogPlayers.ClientSize = new Size(400, 300);
            printPreviewDialogPlayers.Enabled = true;
            printPreviewDialogPlayers.Icon = (Icon)resources.GetObject("printPreviewDialogPlayers.Icon");
            printPreviewDialogPlayers.Name = "printPreviewDialogPlayers";
            printPreviewDialogPlayers.Visible = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(388, 346);
            Controls.Add(buttonallclear);
            Controls.Add(label4);
            Controls.Add(buttonPrint);
            Controls.Add(buttonClear);
            Controls.Add(buttonAdd);
            Controls.Add(listBoxPlayers);
            Controls.Add(checkBoxAlive);
            Controls.Add(textBoxStrength);
            Controls.Add(label3);
            Controls.Add(textBoxhits);
            Controls.Add(label2);
            Controls.Add(textBoxName);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Unit 8 quiz quiz quiz qyuiz quiz quiwz q wuzi  quwiez qqqz uwq quzui ";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBoxName;
        private TextBox textBoxhits;
        private Label label2;
        private TextBox textBoxStrength;
        private Label label3;
        private CheckBox checkBoxAlive;
        private ListBox listBoxPlayers;
        private Button buttonAdd;
        private Button buttonClear;
        private Button buttonPrint;
        private Label label4;
        private Button buttonallclear;
        private System.Drawing.Printing.PrintDocument printDocumentPlayers;
        private PrintPreviewDialog printPreviewDialogPlayers;
    }
}
