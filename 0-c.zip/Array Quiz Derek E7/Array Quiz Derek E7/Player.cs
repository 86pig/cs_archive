﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Array_Quiz_Derek_E7
{
    public class Player
    {
        public Player()
        {
            playerName = string.Empty;
        }
        public Player(string n, int h, int s, bool a)
        {
            playerName = n;
            Hits = h;
            Strength = s;
            Alive = a;
        }
        public string playerName { get; set; }
        public int Hits { get; set; }
        public int Strength { get; set; }
        public bool Alive { get; set; }






    }
}
