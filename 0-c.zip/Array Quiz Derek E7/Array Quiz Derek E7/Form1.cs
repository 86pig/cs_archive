using Microsoft.VisualBasic.ApplicationServices;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace Array_Quiz_Derek_E7
{
    public partial class Form1 : Form
    {
        List<Player> players = new List<Player>();
        bool ALIVE = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            Player player;

            if (listBoxPlayers.Items.Count <= 5)
            {
                try
                {
                    player = new Player(textBoxName.Text, int.Parse(textBoxhits.Text), int.Parse(textBoxStrength.Text), checkBoxAlive.Checked);
                }
                catch
                {
                    MessageBox.Show("invalid input try again");
                    return;
                }
                players.Add(player);
                listBoxPlayers.Items.Add(player.playerName);
            }
            if (listBoxPlayers.Items.Count > 4)
            {
                buttonAdd.Enabled = false;
            }
            if (textBoxName.Text.Length == 0) MessageBox.Show("all required variables must be filled out");
            if (textBoxhits.Text.Length == 0) MessageBox.Show("all required variables must be filled out");
            if (textBoxStrength.Text.Length == 0) MessageBox.Show("all required variables must be filled out");

        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxName.Clear();
            textBoxhits.Clear();
            textBoxStrength.Clear();
            checkBoxAlive.Checked = false;
            textBoxName.Focus();
        }

        private void checkBoxAlive_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxAlive.Checked == true) ALIVE = true;
            else if (checkBoxAlive.Checked == false) ALIVE = false;
        }

        private void listBoxPlayers_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxPlayers.SelectedIndex == -1) return;

            int i = listBoxPlayers.SelectedIndex;
            textBoxName.Text = players[i].playerName;
            textBoxhits.Text = players[i].Hits.ToString();
            textBoxStrength.Text = players[i].Strength.ToString();
        }

        private void buttonallclear_Click(object sender, EventArgs e)
        {
            buttonAdd.Enabled = true;

            int i = listBoxPlayers.SelectedIndex;
            listBoxPlayers.Items.Clear();
            players.Clear();

            textBoxName.Clear();
            textBoxhits.Clear();
            textBoxStrength.Clear();
            checkBoxAlive.Checked = false;
            textBoxName.Focus();
        }

        private void printDocumentPlayers_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Font printFont = new Font("Arial", 12);
            Font headingFont = new Font("Arial", 24, FontStyle.Bold);
            float verticalPrintPositionFloat = e.MarginBounds.Top;
            float horizontalPrintPositionFloat = e.MarginBounds.Left;
            float lineHeightFloat = printFont.GetHeight();

            // Print heading.
            e.Graphics.DrawString("List of alive players",
            headingFont,
            Brushes.SaddleBrown, horizontalPrintPositionFloat,
            verticalPrintPositionFloat);

            verticalPrintPositionFloat += 2 * lineHeightFloat;
            verticalPrintPositionFloat += 2 * lineHeightFloat;
            verticalPrintPositionFloat += 2 * lineHeightFloat;

            float[] cols =
            {
                horizontalPrintPositionFloat,
                horizontalPrintPositionFloat + 200,
                horizontalPrintPositionFloat + 400,
            };
            // Print heading.
            e.Graphics.DrawString("name: ",
            headingFont,
            Brushes.SaddleBrown, cols[0],
            verticalPrintPositionFloat);

            // Print heading.
            e.Graphics.DrawString("hits: ",
            headingFont,
            Brushes.SaddleBrown, cols[1],
            verticalPrintPositionFloat);

            // Print heading.
            e.Graphics.DrawString("strength: ",
            headingFont,
            Brushes.SaddleBrown, cols[2],
            verticalPrintPositionFloat);

            verticalPrintPositionFloat += 2 * lineHeightFloat;

            for (int i = 0; i < listBoxPlayers.Items.Count; i++)
            {
                if (players[i] == null)
                {
                    break;
                }
                if (players[i].Alive == true)
                {

                    // Print heading.
                    e.Graphics.DrawString(players[i].playerName.ToString(),
                    printFont,
                    Brushes.SaddleBrown, cols[0],
                    verticalPrintPositionFloat);

                    // Print heading.
                    e.Graphics.DrawString(players[i].Hits.ToString(),
                    printFont,
                    Brushes.SaddleBrown, cols[1],
                    verticalPrintPositionFloat);

                    // Print heading.
                    e.Graphics.DrawString(players[i].Strength.ToString(),
                    printFont,
                    Brushes.SaddleBrown, cols[2],
                    verticalPrintPositionFloat);



                    verticalPrintPositionFloat += 3 * lineHeightFloat;
                }
            }
        }

        private void buttonPrint_Click(object sender, EventArgs e)
        {
            printPreviewDialogPlayers.Document = printDocumentPlayers;
            printPreviewDialogPlayers.ShowDialog();
        }
    }
}
