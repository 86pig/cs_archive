﻿namespace Bonus_point_calculator_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            pointsToolStripMenuItem = new ToolStripMenuItem();
            summaryToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem1 = new ToolStripSeparator();
            exitToolStripMenuItem = new ToolStripMenuItem();
            helpToolStripMenuItem = new ToolStripMenuItem();
            clearToolStripMenuItem = new ToolStripMenuItem();
            fontToolStripMenuItem = new ToolStripMenuItem();
            colourToolStripMenuItem = new ToolStripMenuItem();
            helpToolStripMenuItem1 = new ToolStripMenuItem();
            abouitToolStripMenuItem = new ToolStripMenuItem();
            fontDialog1 = new FontDialog();
            colorDialog1 = new ColorDialog();
            labelName = new Label();
            labelBooksread = new Label();
            textBoxName = new TextBox();
            textBoxBooksRead = new TextBox();
            textBoxbonuspoints = new TextBox();
            labelBonuspts = new Label();
            label1 = new Label();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem, helpToolStripMenuItem, helpToolStripMenuItem1 });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(362, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { pointsToolStripMenuItem, summaryToolStripMenuItem, toolStripMenuItem1, exitToolStripMenuItem });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(37, 20);
            fileToolStripMenuItem.Text = "&File";
            // 
            // pointsToolStripMenuItem
            // 
            pointsToolStripMenuItem.Name = "pointsToolStripMenuItem";
            pointsToolStripMenuItem.Size = new Size(125, 22);
            pointsToolStripMenuItem.Text = "&Points";
            pointsToolStripMenuItem.Click += pointsToolStripMenuItem_Click;
            // 
            // summaryToolStripMenuItem
            // 
            summaryToolStripMenuItem.Name = "summaryToolStripMenuItem";
            summaryToolStripMenuItem.Size = new Size(125, 22);
            summaryToolStripMenuItem.Text = "&Summary";
            summaryToolStripMenuItem.Click += summaryToolStripMenuItem_Click;
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(122, 6);
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(125, 22);
            exitToolStripMenuItem.Text = "E&xit";
            exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;
            // 
            // helpToolStripMenuItem
            // 
            helpToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { clearToolStripMenuItem, fontToolStripMenuItem, colourToolStripMenuItem });
            helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            helpToolStripMenuItem.Size = new Size(39, 20);
            helpToolStripMenuItem.Text = "&Edit";
            // 
            // clearToolStripMenuItem
            // 
            clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            clearToolStripMenuItem.Size = new Size(110, 22);
            clearToolStripMenuItem.Text = "&Clear";
            clearToolStripMenuItem.Click += clearToolStripMenuItem_Click;
            // 
            // fontToolStripMenuItem
            // 
            fontToolStripMenuItem.Name = "fontToolStripMenuItem";
            fontToolStripMenuItem.Size = new Size(110, 22);
            fontToolStripMenuItem.Text = "Fon&t";
            fontToolStripMenuItem.Click += fontToolStripMenuItem_Click;
            // 
            // colourToolStripMenuItem
            // 
            colourToolStripMenuItem.Name = "colourToolStripMenuItem";
            colourToolStripMenuItem.Size = new Size(110, 22);
            colourToolStripMenuItem.Text = "Colo&ur";
            colourToolStripMenuItem.Click += colourToolStripMenuItem_Click;
            // 
            // helpToolStripMenuItem1
            // 
            helpToolStripMenuItem1.DropDownItems.AddRange(new ToolStripItem[] { abouitToolStripMenuItem });
            helpToolStripMenuItem1.Name = "helpToolStripMenuItem1";
            helpToolStripMenuItem1.Size = new Size(44, 20);
            helpToolStripMenuItem1.Text = "&Help";
            // 
            // abouitToolStripMenuItem
            // 
            abouitToolStripMenuItem.Name = "abouitToolStripMenuItem";
            abouitToolStripMenuItem.Size = new Size(180, 22);
            abouitToolStripMenuItem.Text = "&About";
            abouitToolStripMenuItem.Click += abouitToolStripMenuItem_Click;
            // 
            // labelName
            // 
            labelName.AutoSize = true;
            labelName.Font = new Font("Segoe UI", 10F);
            labelName.Location = new Point(44, 96);
            labelName.Name = "labelName";
            labelName.Size = new Size(48, 19);
            labelName.TabIndex = 1;
            labelName.Text = "Name:";
            // 
            // labelBooksread
            // 
            labelBooksread.AutoSize = true;
            labelBooksread.Font = new Font("Segoe UI", 10F);
            labelBooksread.Location = new Point(44, 130);
            labelBooksread.Name = "labelBooksread";
            labelBooksread.Size = new Size(80, 19);
            labelBooksread.TabIndex = 2;
            labelBooksread.Text = "Books read:";
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(165, 95);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(132, 23);
            textBoxName.TabIndex = 3;
            // 
            // textBoxBooksRead
            // 
            textBoxBooksRead.Location = new Point(165, 129);
            textBoxBooksRead.Name = "textBoxBooksRead";
            textBoxBooksRead.Size = new Size(132, 23);
            textBoxBooksRead.TabIndex = 4;
            // 
            // textBoxbonuspoints
            // 
            textBoxbonuspoints.Location = new Point(165, 190);
            textBoxbonuspoints.Name = "textBoxbonuspoints";
            textBoxbonuspoints.ReadOnly = true;
            textBoxbonuspoints.Size = new Size(132, 23);
            textBoxbonuspoints.TabIndex = 5;
            // 
            // labelBonuspts
            // 
            labelBonuspts.AutoSize = true;
            labelBonuspts.Font = new Font("Segoe UI", 10F);
            labelBonuspts.Location = new Point(44, 191);
            labelBonuspts.Name = "labelBonuspts";
            labelBonuspts.Size = new Size(92, 19);
            labelBonuspts.TabIndex = 6;
            labelBonuspts.Text = "Bonus points:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F);
            label1.Location = new Point(241, 24);
            label1.Name = "label1";
            label1.Size = new Size(56, 19);
            label1.TabIndex = 7;
            label1.Text = "Derek E";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(362, 258);
            Controls.Add(label1);
            Controls.Add(labelBonuspts);
            Controls.Add(textBoxbonuspoints);
            Controls.Add(textBoxBooksRead);
            Controls.Add(textBoxName);
            Controls.Add(labelBooksread);
            Controls.Add(labelName);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Reading bonus point calculator";
            Load += Form1_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem helpToolStripMenuItem;
        private ToolStripMenuItem helpToolStripMenuItem1;
        private ToolStripMenuItem pointsToolStripMenuItem;
        private ToolStripMenuItem summaryToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem1;
        private ToolStripMenuItem exitToolStripMenuItem;
        private ToolStripMenuItem clearToolStripMenuItem;
        private ToolStripMenuItem fontToolStripMenuItem;
        private ToolStripMenuItem colourToolStripMenuItem;
        private ToolStripMenuItem abouitToolStripMenuItem;
        private FontDialog fontDialog1;
        private ColorDialog colorDialog1;
        private Label labelName;
        private Label labelBooksread;
        private TextBox textBoxName;
        private TextBox textBoxBooksRead;
        private TextBox textBoxbonuspoints;
        private Label labelBonuspts;
        private Label label1;
    }
}
