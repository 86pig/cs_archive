namespace Bonus_point_calculator_Derek_E7
{
    public partial class Form1 : Form
    {
        int sessionbooksread = 0;
        int theotherthing = 0;



        public Form1()
        {
            InitializeComponent();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private int BonusPoints(int p)
        {
            int b = 0;

            if (p <= 3) b = p * 10;
            else if (p <= 6) b = 30 + ((p - 3) * 15);
            else b = 75 + ((p - 6) * 20);
            return b;
        }


        private void pointsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int booksread = int.Parse(textBoxBooksRead.Text);
            int bonuspts = BonusPoints(booksread);

            sessionbooksread += booksread;
            theotherthing++;
            textBoxbonuspoints.Text = bonuspts.ToString();

        }

        private void summaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            double average;
            average = sessionbooksread / theotherthing;

            string asdf = average.ToString();
            MessageBox.Show("Average number of books read per person this session so far: " + asdf);
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBoxName.Clear();
            textBoxBooksRead.Clear();
            textBoxbonuspoints.Clear();
            textBoxName.Focus();

        }

        private void colourToolStripMenuItem_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            Color currentColor = colorDialog1.Color;
            this.ForeColor = currentColor;

            textBoxName.ForeColor = currentColor;
            textBoxBooksRead.ForeColor = currentColor;
            textBoxbonuspoints.ForeColor = currentColor;
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowDialog();
            Font currentFont = fontDialog1.Font;
            this.Font = currentFont;
            textBoxName.Font = currentFont;
            textBoxBooksRead.Font = currentFont;
            textBoxbonuspoints.Font = currentFont;
        }

        private void abouitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Bonus point calculator - Derek E");
        }
    }
}
