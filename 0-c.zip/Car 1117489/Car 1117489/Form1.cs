namespace Car_1117489
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Auto_Click(object sender, EventArgs e)
        {
            MessageLabel.Text = "Family Wagon, arguably above average condition! $12,996";
        }

        private void Service_Click(object sender, EventArgs e)
        {
            MessageLabel.Text = "Car lubricant, Car oil, Car filters. All at the cheap price at $26.68 per item!";
        }

        private void Detail_Click(object sender, EventArgs e)
        {
            MessageLabel.Text = "Complete detail $79.88 for most (but not really of) cars";
        }

        private void Employ_Click(object sender, EventArgs e)
        {
            MessageLabel.Text = "Sales position: Contact Mr. Contactee at +1-123-456-7895";
        }
    }
}
