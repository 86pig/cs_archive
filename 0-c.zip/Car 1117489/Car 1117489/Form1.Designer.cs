﻿namespace Car_1117489
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Auto = new Button();
            Service = new Button();
            Detail = new Button();
            Employ = new Button();
            Exit = new Button();
            label1 = new Label();
            label2 = new Label();
            MessageLabel = new Label();
            SuspendLayout();
            // 
            // Auto
            // 
            Auto.Location = new Point(61, 163);
            Auto.Name = "Auto";
            Auto.Size = new Size(303, 108);
            Auto.TabIndex = 0;
            Auto.Text = "Auto Sales";
            Auto.UseVisualStyleBackColor = true;
            Auto.Click += Auto_Click;
            // 
            // Service
            // 
            Service.Location = new Point(61, 277);
            Service.Name = "Service";
            Service.Size = new Size(303, 108);
            Service.TabIndex = 1;
            Service.Text = "Service Centre";
            Service.UseVisualStyleBackColor = true;
            Service.Click += Service_Click;
            // 
            // Detail
            // 
            Detail.Location = new Point(61, 391);
            Detail.Name = "Detail";
            Detail.Size = new Size(303, 108);
            Detail.TabIndex = 2;
            Detail.Text = "Detail Shop";
            Detail.UseVisualStyleBackColor = true;
            Detail.Click += Detail_Click;
            // 
            // Employ
            // 
            Employ.Location = new Point(61, 505);
            Employ.Name = "Employ";
            Employ.Size = new Size(303, 108);
            Employ.TabIndex = 3;
            Employ.Text = "Employment Opportunities";
            Employ.UseVisualStyleBackColor = true;
            Employ.Click += Employ_Click;
            // 
            // Exit
            // 
            Exit.BackColor = SystemColors.ControlDark;
            Exit.Location = new Point(61, 662);
            Exit.Name = "Exit";
            Exit.Size = new Size(303, 65);
            Exit.TabIndex = 4;
            Exit.Text = "Exit";
            Exit.UseVisualStyleBackColor = false;
            Exit.Click += Exit_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(1065, 590);
            label1.Name = "label1";
            label1.Size = new Size(96, 32);
            label1.TabIndex = 5;
            label1.Text = "Derek E";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(61, 79);
            label2.Name = "label2";
            label2.Size = new Size(1012, 32);
            label2.TabIndex = 6;
            label2.Text = "Select a button to look at amazingly amazing deals so you feel inclined to buy from us!";
            // 
            // MessageLabel
            // 
            MessageLabel.AutoSize = true;
            MessageLabel.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            MessageLabel.Location = new Point(645, 277);
            MessageLabel.Name = "MessageLabel";
            MessageLabel.Size = new Size(0, 32);
            MessageLabel.TabIndex = 7;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1722, 1061);
            Controls.Add(MessageLabel);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(Exit);
            Controls.Add(Employ);
            Controls.Add(Detail);
            Controls.Add(Service);
            Controls.Add(Auto);
            Name = "Form1";
            Text = "Car Stuff Order Preview";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Auto;
        private Button Service;
        private Button Detail;
        private Button Employ;
        private Button Exit;
        private Label label1;
        private Label label2;
        private Label MessageLabel;
    }
}
