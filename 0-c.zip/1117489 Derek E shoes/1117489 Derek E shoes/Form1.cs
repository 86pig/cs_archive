using System.Windows.Forms.Design;

namespace _1117489_Derek_E_shoes
{
    public partial class shooshopform : Form
    {
        public shooshopform()
        {
            InitializeComponent();
            malegroupBox.Visible = false;
            FemalegroupBox.Visible = false;
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void optionMale_CheckedChanged(object sender, EventArgs e)
        {
            malegroupBox.Visible = true;
            FemalegroupBox.Visible = false;
            puictureui.Image = null;
        }

        private void maleclown_CheckedChanged(object sender, EventArgs e)
        {
            puictureui.Image = Properties.Resources.clown;
            bigbogbox.Text = "Clown shoes - Clown shoos for the circus";
        }

        private void Dress_CheckedChanged(object sender, EventArgs e)
        {
            puictureui.Image = Properties.Resources.fishshoes;
            bigbogbox.Text = "Fish shoes - Shoes for fishing";
        }

        private void maletrump_CheckedChanged(object sender, EventArgs e)
        {
            puictureui.Image = Properties.Resources.trumpshoes;
            bigbogbox.Text = "Shoe shoes - Walk around like a wrong american";
        }

        private void malefeet_CheckedChanged(object sender, EventArgs e)
        {
            puictureui.Image = Properties.Resources.feetshoes;
            bigbogbox.Text = "Feet shoes - That's a little wierd man.";
        }

        private void fmailtall_CheckedChanged(object sender, EventArgs e)
        {
            puictureui.Image = Properties.Resources.fmaildreshshoes;
            bigbogbox.Text = "Dress shoes - You will look fancy at work";
        }

        private void fmailfurri_CheckedChanged(object sender, EventArgs e)
        {
            puictureui.Image = Properties.Resources.fmailfurry;
            bigbogbox.Text = "Fur shoes - will keep your feet warm";
        }

        private void fmailcow_CheckedChanged(object sender, EventArgs e)
        {
            puictureui.Image = Properties.Resources.fmailsandles;
            bigbogbox.Text = "Sandles - will not ensure that sand will not get under your feet";
        }

        private void fmailrunning_CheckedChanged(object sender, EventArgs e)
        {
            puictureui.Image = Properties.Resources.REALFMALRUNGING;
            bigbogbox.Text = "Running shoes - good for days where you don't want to run";
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            malegroupBox.Visible = false;
            FemalegroupBox.Visible = false;
            deeeeeeeeeeeeeeef.Focus();
            puictureui.Image = null;
            bigbogbox.Clear();
            radioButton1.Focus();
            radioButton2.Focus();
            optionFemale.Checked = false;
            optionMale.Checked = false;
            FemalegroupBox.Visible = false;
            malegroupBox.Visible = false;
        }

        private void optionFemale_CheckedChanged(object sender, EventArgs e)
        {
            FemalegroupBox.Visible = true;
            malegroupBox.Visible = false;
            puictureui.Image = null;
        }
    }
}
