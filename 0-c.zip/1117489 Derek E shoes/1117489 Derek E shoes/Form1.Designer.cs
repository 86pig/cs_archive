﻿namespace _1117489_Derek_E_shoes
{
    partial class shooshopform
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            groupBox1 = new GroupBox();
            deeeeeeeeeeeeeeef = new RadioButton();
            optionFemale = new RadioButton();
            optionMale = new RadioButton();
            malegroupBox = new GroupBox();
            radioButton1 = new RadioButton();
            malefeet = new RadioButton();
            maletrump = new RadioButton();
            Dress = new RadioButton();
            maleclown = new RadioButton();
            FemalegroupBox = new GroupBox();
            radioButton2 = new RadioButton();
            fmailrunning = new RadioButton();
            fmailcow = new RadioButton();
            fmailfurri = new RadioButton();
            fmailtall = new RadioButton();
            Exit = new Button();
            exittt = new ToolTip(components);
            Clear = new Button();
            bigbogbox = new RichTextBox();
            puictureui = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            genderselection = new ToolTip(components);
            maleslection = new ToolTip(components);
            fmailsuselectionwuw = new ToolTip(components);
            groupBox1.SuspendLayout();
            malegroupBox.SuspendLayout();
            FemalegroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)puictureui).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(deeeeeeeeeeeeeeef);
            groupBox1.Controls.Add(optionFemale);
            groupBox1.Controls.Add(optionMale);
            groupBox1.Location = new Point(55, 101);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(156, 129);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Gender";
            genderselection.SetToolTip(groupBox1, "Selecte a gender to start");
            // 
            // deeeeeeeeeeeeeeef
            // 
            deeeeeeeeeeeeeeef.AutoSize = true;
            deeeeeeeeeeeeeeef.Checked = true;
            deeeeeeeeeeeeeeef.Location = new Point(48, 103);
            deeeeeeeeeeeeeeef.Name = "deeeeeeeeeeeeeeef";
            deeeeeeeeeeeeeeef.Size = new Size(94, 19);
            deeeeeeeeeeeeeeef.TabIndex = 8;
            deeeeeeeeeeeeeeef.TabStop = true;
            deeeeeeeeeeeeeeef.Text = "radioButton1";
            deeeeeeeeeeeeeeef.UseVisualStyleBackColor = true;
            deeeeeeeeeeeeeeef.Visible = false;
            // 
            // optionFemale
            // 
            optionFemale.AutoSize = true;
            optionFemale.Location = new Point(6, 47);
            optionFemale.Name = "optionFemale";
            optionFemale.Size = new Size(63, 19);
            optionFemale.TabIndex = 7;
            optionFemale.Text = "&Female";
            optionFemale.UseVisualStyleBackColor = true;
            optionFemale.CheckedChanged += optionFemale_CheckedChanged;
            // 
            // optionMale
            // 
            optionMale.AutoSize = true;
            optionMale.Location = new Point(6, 22);
            optionMale.Name = "optionMale";
            optionMale.Size = new Size(51, 19);
            optionMale.TabIndex = 6;
            optionMale.Text = "&Male";
            optionMale.UseVisualStyleBackColor = true;
            optionMale.CheckedChanged += optionMale_CheckedChanged;
            // 
            // malegroupBox
            // 
            malegroupBox.Controls.Add(radioButton1);
            malegroupBox.Controls.Add(malefeet);
            malegroupBox.Controls.Add(maletrump);
            malegroupBox.Controls.Add(Dress);
            malegroupBox.Controls.Add(maleclown);
            malegroupBox.Location = new Point(312, 101);
            malegroupBox.Name = "malegroupBox";
            malegroupBox.Size = new Size(156, 129);
            malegroupBox.TabIndex = 1;
            malegroupBox.TabStop = false;
            malegroupBox.Text = "Male shoes";
            maleslection.SetToolTip(malegroupBox, "Choose a style for mens shoes");
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Checked = true;
            radioButton1.Location = new Point(97, 97);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(94, 19);
            radioButton1.TabIndex = 9;
            radioButton1.TabStop = true;
            radioButton1.Text = "radioButton1";
            radioButton1.UseVisualStyleBackColor = true;
            radioButton1.Visible = false;
            // 
            // malefeet
            // 
            malefeet.AutoSize = true;
            malefeet.Location = new Point(6, 97);
            malefeet.Name = "malefeet";
            malefeet.Size = new Size(47, 19);
            malefeet.TabIndex = 11;
            malefeet.TabStop = true;
            malefeet.Text = "Fe&et";
            malefeet.UseVisualStyleBackColor = true;
            malefeet.CheckedChanged += malefeet_CheckedChanged;
            // 
            // maletrump
            // 
            maletrump.AutoSize = true;
            maletrump.Location = new Point(6, 72);
            maletrump.Name = "maletrump";
            maletrump.Size = new Size(76, 19);
            maletrump.TabIndex = 10;
            maletrump.TabStop = true;
            maletrump.Text = "&American";
            maletrump.UseVisualStyleBackColor = true;
            maletrump.CheckedChanged += maletrump_CheckedChanged;
            // 
            // Dress
            // 
            Dress.AutoSize = true;
            Dress.Location = new Point(6, 47);
            Dress.Name = "Dress";
            Dress.Size = new Size(46, 19);
            Dress.TabIndex = 9;
            Dress.TabStop = true;
            Dress.Text = "Fis&h";
            Dress.UseVisualStyleBackColor = true;
            Dress.CheckedChanged += Dress_CheckedChanged;
            // 
            // maleclown
            // 
            maleclown.AutoSize = true;
            maleclown.Location = new Point(6, 22);
            maleclown.Name = "maleclown";
            maleclown.Size = new Size(59, 19);
            maleclown.TabIndex = 8;
            maleclown.TabStop = true;
            maleclown.Text = "Clo&wn";
            maleclown.UseVisualStyleBackColor = true;
            maleclown.CheckedChanged += maleclown_CheckedChanged;
            // 
            // FemalegroupBox
            // 
            FemalegroupBox.Controls.Add(radioButton2);
            FemalegroupBox.Controls.Add(fmailrunning);
            FemalegroupBox.Controls.Add(fmailcow);
            FemalegroupBox.Controls.Add(fmailfurri);
            FemalegroupBox.Controls.Add(fmailtall);
            FemalegroupBox.Location = new Point(522, 101);
            FemalegroupBox.Name = "FemalegroupBox";
            FemalegroupBox.Size = new Size(156, 129);
            FemalegroupBox.TabIndex = 1;
            FemalegroupBox.TabStop = false;
            FemalegroupBox.Text = "Female shoes";
            fmailsuselectionwuw.SetToolTip(FemalegroupBox, "Select a shoe style for female shoes");
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Checked = true;
            radioButton2.Location = new Point(104, 72);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(94, 19);
            radioButton2.TabIndex = 12;
            radioButton2.TabStop = true;
            radioButton2.Text = "radioButton1";
            radioButton2.UseVisualStyleBackColor = true;
            radioButton2.Visible = false;
            // 
            // fmailrunning
            // 
            fmailrunning.AutoSize = true;
            fmailrunning.Location = new Point(6, 97);
            fmailrunning.Name = "fmailrunning";
            fmailrunning.Size = new Size(70, 19);
            fmailrunning.TabIndex = 15;
            fmailrunning.TabStop = true;
            fmailrunning.Text = "&Running";
            fmailrunning.UseVisualStyleBackColor = true;
            fmailrunning.CheckedChanged += fmailrunning_CheckedChanged;
            // 
            // fmailcow
            // 
            fmailcow.AutoSize = true;
            fmailcow.Location = new Point(6, 72);
            fmailcow.Name = "fmailcow";
            fmailcow.Size = new Size(60, 19);
            fmailcow.TabIndex = 14;
            fmailcow.TabStop = true;
            fmailcow.Text = "&Sandle";
            fmailcow.UseVisualStyleBackColor = true;
            fmailcow.CheckedChanged += fmailcow_CheckedChanged;
            // 
            // fmailfurri
            // 
            fmailfurri.AutoSize = true;
            fmailfurri.Location = new Point(6, 47);
            fmailfurri.Name = "fmailfurri";
            fmailfurri.Size = new Size(42, 19);
            fmailfurri.TabIndex = 13;
            fmailfurri.TabStop = true;
            fmailfurri.Text = "F&ur";
            fmailfurri.UseVisualStyleBackColor = true;
            fmailfurri.CheckedChanged += fmailfurri_CheckedChanged;
            // 
            // fmailtall
            // 
            fmailtall.AutoSize = true;
            fmailtall.Location = new Point(6, 22);
            fmailtall.Name = "fmailtall";
            fmailtall.Size = new Size(53, 19);
            fmailtall.TabIndex = 12;
            fmailtall.TabStop = true;
            fmailtall.Text = "&Dress";
            fmailtall.UseVisualStyleBackColor = true;
            fmailtall.CheckedChanged += fmailtall_CheckedChanged;
            // 
            // Exit
            // 
            Exit.Location = new Point(522, 339);
            Exit.Name = "Exit";
            Exit.Size = new Size(177, 37);
            Exit.TabIndex = 2;
            Exit.Text = "E&xit";
            exittt.SetToolTip(Exit, "Close the form (or pess escape or enter)");
            Exit.UseVisualStyleBackColor = true;
            Exit.Click += Exit_Click;
            // 
            // Clear
            // 
            Clear.Location = new Point(522, 272);
            Clear.Name = "Clear";
            Clear.Size = new Size(177, 37);
            Clear.TabIndex = 7;
            Clear.Text = "&Clear";
            exittt.SetToolTip(Clear, "Close the form (or pess escape or enter)");
            Clear.UseVisualStyleBackColor = true;
            Clear.Click += Clear_Click;
            // 
            // bigbogbox
            // 
            bigbogbox.Location = new Point(32, 339);
            bigbogbox.Name = "bigbogbox";
            bigbogbox.ReadOnly = true;
            bigbogbox.Size = new Size(179, 71);
            bigbogbox.TabIndex = 3;
            bigbogbox.Text = "";
            // 
            // puictureui
            // 
            puictureui.Location = new Point(237, 263);
            puictureui.Name = "puictureui";
            puictureui.Size = new Size(231, 147);
            puictureui.SizeMode = PictureBoxSizeMode.StretchImage;
            puictureui.TabIndex = 4;
            puictureui.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(536, 399);
            label1.Name = "label1";
            label1.Size = new Size(46, 15);
            label1.TabIndex = 5;
            label1.Text = "Derek E";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(55, 22);
            label2.Name = "label2";
            label2.Size = new Size(183, 30);
            label2.TabIndex = 6;
            label2.Text = "THE SHOO STOAR";
            // 
            // shooshopform
            // 
            AcceptButton = Exit;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = Exit;
            ClientSize = new Size(800, 450);
            Controls.Add(Clear);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(puictureui);
            Controls.Add(bigbogbox);
            Controls.Add(FemalegroupBox);
            Controls.Add(Exit);
            Controls.Add(malegroupBox);
            Controls.Add(groupBox1);
            Name = "shooshopform";
            Text = "Shoo StorE";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            malegroupBox.ResumeLayout(false);
            malegroupBox.PerformLayout();
            FemalegroupBox.ResumeLayout(false);
            FemalegroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)puictureui).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox malegroupBox;
        private GroupBox FemalegroupBox;
        private Button Exit;
        private RadioButton optionFemale;
        private RadioButton optionMale;
        private RadioButton malefeet;
        private RadioButton maletrump;
        private RadioButton Dress;
        private RadioButton maleclown;
        private ToolTip exittt;
        private RichTextBox bigbogbox;
        private PictureBox puictureui;
        private Label label1;
        private RadioButton fmailrunning;
        private RadioButton fmailcow;
        private RadioButton fmailfurri;
        private RadioButton fmailtall;
        private RadioButton deeeeeeeeeeeeeeef;
        private Label label2;
        private Button Clear;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private ToolTip genderselection;
        private ToolTip maleslection;
        private ToolTip fmailsuselectionwuw;
    }
}
