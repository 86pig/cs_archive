﻿namespace antoherdemo4radbcb
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            textBoxCustom = new TextBox();
            radioButtonCUSTOM = new RadioButton();
            radioButton20percent = new RadioButton();
            radioButton15percent = new RadioButton();
            radioButton10percent = new RadioButton();
            radioButton5percent = new RadioButton();
            label1 = new Label();
            label2 = new Label();
            textBoxSalesTotal = new TextBox();
            label3 = new Label();
            textBoxTipAmount = new TextBox();
            textBoxTotalCost = new TextBox();
            buttonCalculate = new Button();
            groupBox2 = new GroupBox();
            label4 = new Label();
            checkBoxH30 = new CheckBox();
            checkBoxL20 = new CheckBox();
            checkBoxT40 = new CheckBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBoxCustom);
            groupBox1.Controls.Add(radioButtonCUSTOM);
            groupBox1.Controls.Add(radioButton20percent);
            groupBox1.Controls.Add(radioButton15percent);
            groupBox1.Controls.Add(radioButton10percent);
            groupBox1.Controls.Add(radioButton5percent);
            groupBox1.Location = new Point(53, 42);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(228, 270);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Tip Amount";
            // 
            // textBoxCustom
            // 
            textBoxCustom.Location = new Point(6, 241);
            textBoxCustom.Name = "textBoxCustom";
            textBoxCustom.Size = new Size(100, 23);
            textBoxCustom.TabIndex = 5;
            textBoxCustom.Text = "0";
            textBoxCustom.Visible = false;
            // 
            // radioButtonCUSTOM
            // 
            radioButtonCUSTOM.AutoSize = true;
            radioButtonCUSTOM.Font = new Font("Segoe UI", 11F);
            radioButtonCUSTOM.Location = new Point(6, 202);
            radioButtonCUSTOM.Name = "radioButtonCUSTOM";
            radioButtonCUSTOM.Size = new Size(77, 24);
            radioButtonCUSTOM.TabIndex = 4;
            radioButtonCUSTOM.TabStop = true;
            radioButtonCUSTOM.Text = "Custom";
            radioButtonCUSTOM.UseVisualStyleBackColor = true;
            radioButtonCUSTOM.CheckedChanged += radioButtonCUSTOM_CheckedChanged;
            // 
            // radioButton20percent
            // 
            radioButton20percent.AutoSize = true;
            radioButton20percent.Font = new Font("Segoe UI", 11F);
            radioButton20percent.Location = new Point(6, 112);
            radioButton20percent.Name = "radioButton20percent";
            radioButton20percent.Size = new Size(55, 24);
            radioButton20percent.TabIndex = 3;
            radioButton20percent.TabStop = true;
            radioButton20percent.Text = "20%";
            radioButton20percent.UseVisualStyleBackColor = true;
            // 
            // radioButton15percent
            // 
            radioButton15percent.AutoSize = true;
            radioButton15percent.Font = new Font("Segoe UI", 11F);
            radioButton15percent.Location = new Point(6, 82);
            radioButton15percent.Name = "radioButton15percent";
            radioButton15percent.Size = new Size(55, 24);
            radioButton15percent.TabIndex = 2;
            radioButton15percent.TabStop = true;
            radioButton15percent.Text = "15%";
            radioButton15percent.UseVisualStyleBackColor = true;
            // 
            // radioButton10percent
            // 
            radioButton10percent.AutoSize = true;
            radioButton10percent.Font = new Font("Segoe UI", 11F);
            radioButton10percent.Location = new Point(6, 52);
            radioButton10percent.Name = "radioButton10percent";
            radioButton10percent.Size = new Size(55, 24);
            radioButton10percent.TabIndex = 1;
            radioButton10percent.TabStop = true;
            radioButton10percent.Text = "10%";
            radioButton10percent.UseVisualStyleBackColor = true;
            // 
            // radioButton5percent
            // 
            radioButton5percent.AutoSize = true;
            radioButton5percent.Font = new Font("Segoe UI", 11F);
            radioButton5percent.Location = new Point(6, 22);
            radioButton5percent.Name = "radioButton5percent";
            radioButton5percent.Size = new Size(47, 24);
            radioButton5percent.TabIndex = 0;
            radioButton5percent.TabStop = true;
            radioButton5percent.Text = "5%";
            radioButton5percent.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F);
            label1.Location = new Point(377, 42);
            label1.Name = "label1";
            label1.Size = new Size(72, 19);
            label1.TabIndex = 6;
            label1.Text = "Sales Total";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F);
            label2.Location = new Point(377, 94);
            label2.Name = "label2";
            label2.Size = new Size(81, 19);
            label2.TabIndex = 7;
            label2.Text = "Tip Amount";
            // 
            // textBoxSalesTotal
            // 
            textBoxSalesTotal.Location = new Point(461, 41);
            textBoxSalesTotal.Name = "textBoxSalesTotal";
            textBoxSalesTotal.Size = new Size(100, 23);
            textBoxSalesTotal.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10F);
            label3.Location = new Point(377, 158);
            label3.Name = "label3";
            label3.Size = new Size(70, 19);
            label3.TabIndex = 8;
            label3.Text = "Total Cost";
            // 
            // textBoxTipAmount
            // 
            textBoxTipAmount.Location = new Point(461, 97);
            textBoxTipAmount.Name = "textBoxTipAmount";
            textBoxTipAmount.ReadOnly = true;
            textBoxTipAmount.Size = new Size(100, 23);
            textBoxTipAmount.TabIndex = 9;
            // 
            // textBoxTotalCost
            // 
            textBoxTotalCost.Location = new Point(461, 157);
            textBoxTotalCost.Name = "textBoxTotalCost";
            textBoxTotalCost.ReadOnly = true;
            textBoxTotalCost.Size = new Size(100, 23);
            textBoxTotalCost.TabIndex = 10;
            // 
            // buttonCalculate
            // 
            buttonCalculate.Location = new Point(618, 90);
            buttonCalculate.Name = "buttonCalculate";
            buttonCalculate.Size = new Size(119, 88);
            buttonCalculate.TabIndex = 11;
            buttonCalculate.Text = "Calculate";
            buttonCalculate.UseVisualStyleBackColor = true;
            buttonCalculate.Click += buttonCalculate_Click;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(checkBoxH30);
            groupBox2.Controls.Add(checkBoxL20);
            groupBox2.Controls.Add(checkBoxT40);
            groupBox2.Location = new Point(329, 257);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(129, 166);
            groupBox2.TabIndex = 12;
            groupBox2.TabStop = false;
            groupBox2.Text = "Merch";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10F);
            label4.Location = new Point(0, 127);
            label4.Name = "label4";
            label4.Size = new Size(106, 19);
            label4.TabIndex = 13;
            label4.Text = "cost is in dolalrs";
            // 
            // checkBoxH30
            // 
            checkBoxH30.AutoSize = true;
            checkBoxH30.Font = new Font("Segoe UI", 11F);
            checkBoxH30.Location = new Point(6, 82);
            checkBoxH30.Name = "checkBoxH30";
            checkBoxH30.Size = new Size(69, 24);
            checkBoxH30.TabIndex = 2;
            checkBoxH30.Text = "H - 30";
            checkBoxH30.UseVisualStyleBackColor = true;
            // 
            // checkBoxL20
            // 
            checkBoxL20.AutoSize = true;
            checkBoxL20.Font = new Font("Segoe UI", 11F);
            checkBoxL20.Location = new Point(6, 52);
            checkBoxL20.Name = "checkBoxL20";
            checkBoxL20.Size = new Size(65, 24);
            checkBoxL20.TabIndex = 1;
            checkBoxL20.Text = "L - 20";
            checkBoxL20.UseVisualStyleBackColor = true;
            // 
            // checkBoxT40
            // 
            checkBoxT40.AutoSize = true;
            checkBoxT40.Font = new Font("Segoe UI", 11F);
            checkBoxT40.Location = new Point(6, 22);
            checkBoxT40.Name = "checkBoxT40";
            checkBoxT40.Size = new Size(66, 24);
            checkBoxT40.TabIndex = 0;
            checkBoxT40.Text = "T - 40";
            checkBoxT40.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox2);
            Controls.Add(buttonCalculate);
            Controls.Add(textBoxTotalCost);
            Controls.Add(textBoxTipAmount);
            Controls.Add(label3);
            Controls.Add(textBoxSalesTotal);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private RadioButton radioButtonCUSTOM;
        private RadioButton radioButton20percent;
        private RadioButton radioButton15percent;
        private RadioButton radioButton10percent;
        private RadioButton radioButton5percent;
        private TextBox textBoxCustom;
        private Label label1;
        private Label label2;
        private TextBox textBoxSalesTotal;
        private Label label3;
        private TextBox textBoxTipAmount;
        private TextBox textBoxTotalCost;
        private Button buttonCalculate;
        private GroupBox groupBox2;
        private Label label4;
        private CheckBox checkBoxH30;
        private CheckBox checkBoxL20;
        private CheckBox checkBoxT40;
    }
}
