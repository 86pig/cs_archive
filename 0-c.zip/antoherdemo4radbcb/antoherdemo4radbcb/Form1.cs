using System.CodeDom;

namespace antoherdemo4radbcb
{
    public partial class Form1 : Form
    {
        const double BTIP = 0.05;
        const double TENTIP = 0.1;
        const double FIFTEENTIP = 0.15;
        const double TWENTYTIP = 0.2;

        //?



        public Form1()
        {
            InitializeComponent();

        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            double sales, tiprate;

            try
            {
                sales = double.Parse(textBoxSalesTotal.Text);

                //figure out the tip percentage

                tiprate = 0;
                //get info from the ui


                //set up ifs
                if (radioButton5percent.Checked) tiprate = BTIP;
                else if (radioButton10percent.Checked) tiprate = TENTIP;
                else if (radioButton15percent.Checked) tiprate = FIFTEENTIP;
                else if (radioButton20percent.Checked) tiprate = TWENTYTIP;
                else tiprate = double.Parse(textBoxCustom.Text) / 100;

                //do calcs after get tiprate
                double tipamount = sales * tiprate;
                double totalcost = sales + tipamount;


                // see if we need to add any merch
                if (checkBoxT40.Checked) totalcost += 40;
                if (checkBoxL20.Checked) totalcost += 20;
                if (checkBoxH30.Checked) totalcost += 30;




                textBoxTipAmount.Text = tipamount.ToString("C");
                textBoxTotalCost.Text = totalcost.ToString("C");

            }


            catch
            {
                MessageBox.Show("bad value, enter an int, try again");
                textBoxSalesTotal.Clear();
                textBoxTipAmount.Clear();
                textBoxCustom.Clear();
                textBoxTotalCost.Clear();
                textBoxSalesTotal.Focus();




            }

        }

        private void radioButtonCUSTOM_CheckedChanged(object sender, EventArgs e)
        {
            textBoxCustom.Visible = !textBoxCustom.Visible;
        }
    }
}
