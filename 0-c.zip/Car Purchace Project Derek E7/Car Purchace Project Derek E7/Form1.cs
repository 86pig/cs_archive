using System.CodeDom;

namespace Car_Purchace_Project_Derek_E7
{
    public partial class Form1 : Form
    {
        const double TAX = 0.08;
        const double STERIO = 425.76;
        const double LEATHER = 987.41;
        const double NAV = 1741.23;
        const double PEARL = 345.72;
        const double CUSTOM = 599.99;


        public Form1()
        {
            InitializeComponent();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            /*

            try
            {
                double therealsubtotal = 0;
                double subtotal = 0;

                if (checkBoxSterio.Checked) subtotal += STERIO;
                if (checkBoxLeather.Checked) subtotal += LEATHER;
                if (checkBoxNav.Checked)
                {
                    subtotal += NAV;
                }

                if (radioButtonStandard.Checked) therealsubtotal += 0;
                else if (radioButtonPearlized.Checked) subtotal += PEARL;
                else if (radioButtonCustom.Checked) subtotal += CUSTOM;

                double baseprice = double.Parse(textBoxCarsaleprice.Text);
                therealsubtotal = subtotal + baseprice;
                double salestax = therealsubtotal * TAX;
                double total = therealsubtotal + salestax;
                double tradein = double.Parse(textBoxTradeinallowance.Text);
                double amountdue = total - tradein;


                textBoxAccessoriesandFInish.Text = subtotal.ToString("C");
                textBoxSubtotal.Text = therealsubtotal.ToString("C");
                textBoxTAx.Text = salestax.ToString("C");
                textBoxTotal.Text = total.ToString("C");
                textBoxamontDue.Text = amountdue.ToString("C");

            }

            catch
            {
                MessageBox.Show("enter valid value.");
                textBoxCarsaleprice.Clear();
                textBoxTradeinallowance.Clear();
                textBoxCarsaleprice.Focus();

            }
            */
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {

            /*
            
            textBoxCarsaleprice.Clear();
            textBoxTradeinallowance.Clear();
            textBoxAccessoriesandFInish.Clear();
            textBoxSubtotal.Clear();
            textBoxTAx.Clear();
            textBoxTotal.Clear();
            textBoxamontDue.Clear();
            checkBoxLeather.Checked = false;
            checkBoxNav.Checked = false;
            checkBoxSterio.Checked = false;
            radioButtonStandard.Checked = true;
            textBoxCarsaleprice.Focus();

            */


        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowDialog();
            Font currentFont = fontDialog1.Font;
            textBoxamontDue.Font = currentFont;
            labelDUE.Font = currentFont;
        }

        private void colourToolStripMenuItem_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            Color currentColor = colorDialog1.Color;
            this.ForeColor = currentColor;
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBoxCarsaleprice.Clear();
            textBoxTradeinallowance.Clear();
            textBoxAccessoriesandFInish.Clear();
            textBoxSubtotal.Clear();
            textBoxTAx.Clear();
            textBoxTotal.Clear();
            textBoxamontDue.Clear();
            checkBoxLeather.Checked = false;
            checkBoxNav.Checked = false;
            checkBoxSterio.Checked = false;
            radioButtonStandard.Checked = true;
            textBoxCarsaleprice.Focus();
        }

        private double CalculateSalesTax(double a)
        {


            return a * TAX;
        }



        private void calculateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                double therealsubtotal = 0;
                double subtotal = 0;

                if (checkBoxSterio.Checked) subtotal += STERIO;
                if (checkBoxLeather.Checked) subtotal += LEATHER;
                if (checkBoxNav.Checked)
                {
                    subtotal += NAV;
                }

                if (radioButtonStandard.Checked) therealsubtotal += 0;
                else if (radioButtonPearlized.Checked) subtotal += PEARL;
                else if (radioButtonCustom.Checked) subtotal += CUSTOM;

                double baseprice = double.Parse(textBoxCarsaleprice.Text);
                therealsubtotal = subtotal + baseprice;
                //double salestax = therealsubtotal * TAX;
                double salestax = CalculateSalesTax(therealsubtotal);

                double total = therealsubtotal + salestax;

                double tradein = double.Parse(textBoxTradeinallowance.Text);
                double amountdue = total - tradein;


                textBoxAccessoriesandFInish.Text = subtotal.ToString("C");
                textBoxSubtotal.Text = therealsubtotal.ToString("C");
                textBoxTAx.Text = salestax.ToString("C");
                textBoxTotal.Text = total.ToString("C");
                textBoxamontDue.Text = amountdue.ToString("C");

            }

            catch
            {
                MessageBox.Show("enter valid value.");
                textBoxCarsaleprice.Clear();
                textBoxTradeinallowance.Clear();
                textBoxCarsaleprice.Focus();

            }

        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Revised car purchace project - Derek E");
        }
    }
}


