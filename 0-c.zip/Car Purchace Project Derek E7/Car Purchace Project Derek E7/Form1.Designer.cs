﻿namespace Car_Purchace_Project_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            checkBoxNav = new CheckBox();
            checkBoxLeather = new CheckBox();
            checkBoxSterio = new CheckBox();
            groupBox2 = new GroupBox();
            radioButtonCustom = new RadioButton();
            radioButtonPearlized = new RadioButton();
            radioButtonStandard = new RadioButton();
            label1 = new Label();
            textBoxCarsaleprice = new TextBox();
            textBoxAccessoriesandFInish = new TextBox();
            label2 = new Label();
            textBoxSubtotal = new TextBox();
            label3 = new Label();
            textBoxTAx = new TextBox();
            label4 = new Label();
            textBoxTotal = new TextBox();
            label5 = new Label();
            textBoxTradeinallowance = new TextBox();
            label6 = new Label();
            textBoxamontDue = new TextBox();
            labelDUE = new Label();
            label8 = new Label();
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            exitToolStripMenuItem = new ToolStripMenuItem();
            editToolStripMenuItem = new ToolStripMenuItem();
            calculateToolStripMenuItem = new ToolStripMenuItem();
            clearToolStripMenuItem = new ToolStripMenuItem();
            fontToolStripMenuItem = new ToolStripMenuItem();
            colourToolStripMenuItem = new ToolStripMenuItem();
            helpToolStripMenuItem = new ToolStripMenuItem();
            aboutToolStripMenuItem = new ToolStripMenuItem();
            colorDialog1 = new ColorDialog();
            fontDialog1 = new FontDialog();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(checkBoxNav);
            groupBox1.Controls.Add(checkBoxLeather);
            groupBox1.Controls.Add(checkBoxSterio);
            groupBox1.Location = new Point(32, 125);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(198, 101);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Accessories";
            // 
            // checkBoxNav
            // 
            checkBoxNav.AutoSize = true;
            checkBoxNav.Location = new Point(6, 72);
            checkBoxNav.Name = "checkBoxNav";
            checkBoxNav.Size = new Size(47, 19);
            checkBoxNav.TabIndex = 2;
            checkBoxNav.Text = "Nav";
            checkBoxNav.UseVisualStyleBackColor = true;
            // 
            // checkBoxLeather
            // 
            checkBoxLeather.AutoSize = true;
            checkBoxLeather.Location = new Point(6, 47);
            checkBoxLeather.Name = "checkBoxLeather";
            checkBoxLeather.Size = new Size(65, 19);
            checkBoxLeather.TabIndex = 1;
            checkBoxLeather.Text = "Leather";
            checkBoxLeather.UseVisualStyleBackColor = true;
            // 
            // checkBoxSterio
            // 
            checkBoxSterio.AutoSize = true;
            checkBoxSterio.Location = new Point(6, 22);
            checkBoxSterio.Name = "checkBoxSterio";
            checkBoxSterio.Size = new Size(56, 19);
            checkBoxSterio.TabIndex = 0;
            checkBoxSterio.Text = "Sterio";
            checkBoxSterio.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(radioButtonCustom);
            groupBox2.Controls.Add(radioButtonPearlized);
            groupBox2.Controls.Add(radioButtonStandard);
            groupBox2.Location = new Point(32, 240);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(198, 146);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Exterior Finish";
            // 
            // radioButtonCustom
            // 
            radioButtonCustom.AutoSize = true;
            radioButtonCustom.Location = new Point(6, 111);
            radioButtonCustom.Name = "radioButtonCustom";
            radioButtonCustom.Size = new Size(116, 19);
            radioButtonCustom.TabIndex = 4;
            radioButtonCustom.Text = "Custom detailing";
            radioButtonCustom.UseVisualStyleBackColor = true;
            // 
            // radioButtonPearlized
            // 
            radioButtonPearlized.AutoSize = true;
            radioButtonPearlized.Location = new Point(6, 66);
            radioButtonPearlized.Name = "radioButtonPearlized";
            radioButtonPearlized.Size = new Size(72, 19);
            radioButtonPearlized.TabIndex = 3;
            radioButtonPearlized.Text = "Pearlized";
            radioButtonPearlized.UseVisualStyleBackColor = true;
            // 
            // radioButtonStandard
            // 
            radioButtonStandard.AutoSize = true;
            radioButtonStandard.Checked = true;
            radioButtonStandard.Location = new Point(6, 22);
            radioButtonStandard.Name = "radioButtonStandard";
            radioButtonStandard.Size = new Size(72, 19);
            radioButtonStandard.TabIndex = 2;
            radioButtonStandard.TabStop = true;
            radioButtonStandard.Text = "Standard";
            radioButtonStandard.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F);
            label1.Location = new Point(362, 67);
            label1.Name = "label1";
            label1.Size = new Size(90, 19);
            label1.TabIndex = 5;
            label1.Text = "Car sale price";
            // 
            // textBoxCarsaleprice
            // 
            textBoxCarsaleprice.Location = new Point(495, 66);
            textBoxCarsaleprice.Name = "textBoxCarsaleprice";
            textBoxCarsaleprice.Size = new Size(100, 23);
            textBoxCarsaleprice.TabIndex = 6;
            // 
            // textBoxAccessoriesandFInish
            // 
            textBoxAccessoriesandFInish.Location = new Point(495, 107);
            textBoxAccessoriesandFInish.Name = "textBoxAccessoriesandFInish";
            textBoxAccessoriesandFInish.ReadOnly = true;
            textBoxAccessoriesandFInish.Size = new Size(100, 23);
            textBoxAccessoriesandFInish.TabIndex = 8;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F);
            label2.Location = new Point(316, 108);
            label2.Name = "label2";
            label2.Size = new Size(141, 19);
            label2.TabIndex = 7;
            label2.Text = "Accessories and finish";
            // 
            // textBoxSubtotal
            // 
            textBoxSubtotal.Location = new Point(495, 157);
            textBoxSubtotal.Name = "textBoxSubtotal";
            textBoxSubtotal.ReadOnly = true;
            textBoxSubtotal.Size = new Size(100, 23);
            textBoxSubtotal.TabIndex = 10;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10F);
            label3.Location = new Point(362, 158);
            label3.Name = "label3";
            label3.Size = new Size(60, 19);
            label3.TabIndex = 9;
            label3.Text = "Subtotal";
            // 
            // textBoxTAx
            // 
            textBoxTAx.Location = new Point(495, 206);
            textBoxTAx.Name = "textBoxTAx";
            textBoxTAx.ReadOnly = true;
            textBoxTAx.Size = new Size(100, 23);
            textBoxTAx.TabIndex = 12;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10F);
            label4.Location = new Point(362, 207);
            label4.Name = "label4";
            label4.Size = new Size(83, 19);
            label4.TabIndex = 11;
            label4.Text = "8% sales tax";
            // 
            // textBoxTotal
            // 
            textBoxTotal.Location = new Point(495, 258);
            textBoxTotal.Name = "textBoxTotal";
            textBoxTotal.ReadOnly = true;
            textBoxTotal.Size = new Size(100, 23);
            textBoxTotal.TabIndex = 14;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10F);
            label5.Location = new Point(362, 259);
            label5.Name = "label5";
            label5.Size = new Size(38, 19);
            label5.TabIndex = 13;
            label5.Text = "Total";
            // 
            // textBoxTradeinallowance
            // 
            textBoxTradeinallowance.Location = new Point(495, 305);
            textBoxTradeinallowance.Name = "textBoxTradeinallowance";
            textBoxTradeinallowance.Size = new Size(100, 23);
            textBoxTradeinallowance.TabIndex = 16;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 10F);
            label6.Location = new Point(362, 306);
            label6.Name = "label6";
            label6.Size = new Size(120, 19);
            label6.TabIndex = 15;
            label6.Text = "Trade in allowance";
            // 
            // textBoxamontDue
            // 
            textBoxamontDue.Location = new Point(495, 350);
            textBoxamontDue.Name = "textBoxamontDue";
            textBoxamontDue.ReadOnly = true;
            textBoxamontDue.Size = new Size(100, 23);
            textBoxamontDue.TabIndex = 18;
            // 
            // labelDUE
            // 
            labelDUE.AutoSize = true;
            labelDUE.Font = new Font("Segoe UI", 10F);
            labelDUE.Location = new Point(362, 351);
            labelDUE.Name = "labelDUE";
            labelDUE.Size = new Size(86, 19);
            labelDUE.TabIndex = 17;
            labelDUE.Text = "Amount due";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 10F);
            label8.Location = new Point(32, 410);
            label8.Name = "label8";
            label8.Size = new Size(56, 19);
            label8.TabIndex = 22;
            label8.Text = "Derek E";
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem, editToolStripMenuItem, helpToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 24);
            menuStrip1.TabIndex = 23;
            menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { exitToolStripMenuItem });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(37, 20);
            fileToolStripMenuItem.Text = "&File";
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(180, 22);
            exitToolStripMenuItem.Text = "E&xit";
            // 
            // editToolStripMenuItem
            // 
            editToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { calculateToolStripMenuItem, clearToolStripMenuItem, fontToolStripMenuItem, colourToolStripMenuItem });
            editToolStripMenuItem.Name = "editToolStripMenuItem";
            editToolStripMenuItem.Size = new Size(39, 20);
            editToolStripMenuItem.Text = "&Edit";
            // 
            // calculateToolStripMenuItem
            // 
            calculateToolStripMenuItem.Name = "calculateToolStripMenuItem";
            calculateToolStripMenuItem.Size = new Size(180, 22);
            calculateToolStripMenuItem.Text = "&Calculate";
            calculateToolStripMenuItem.Click += calculateToolStripMenuItem_Click;
            // 
            // clearToolStripMenuItem
            // 
            clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            clearToolStripMenuItem.Size = new Size(180, 22);
            clearToolStripMenuItem.Text = "Clea&r";
            clearToolStripMenuItem.Click += clearToolStripMenuItem_Click;
            // 
            // fontToolStripMenuItem
            // 
            fontToolStripMenuItem.Name = "fontToolStripMenuItem";
            fontToolStripMenuItem.Size = new Size(180, 22);
            fontToolStripMenuItem.Text = "Fo&nt";
            fontToolStripMenuItem.Click += fontToolStripMenuItem_Click;
            // 
            // colourToolStripMenuItem
            // 
            colourToolStripMenuItem.Name = "colourToolStripMenuItem";
            colourToolStripMenuItem.Size = new Size(180, 22);
            colourToolStripMenuItem.Text = "Colo&ur";
            colourToolStripMenuItem.Click += colourToolStripMenuItem_Click;
            // 
            // helpToolStripMenuItem
            // 
            helpToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { aboutToolStripMenuItem });
            helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            helpToolStripMenuItem.Size = new Size(44, 20);
            helpToolStripMenuItem.Text = "&Help";
            // 
            // aboutToolStripMenuItem
            // 
            aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            aboutToolStripMenuItem.Size = new Size(180, 22);
            aboutToolStripMenuItem.Text = "A&bout";
            aboutToolStripMenuItem.Click += aboutToolStripMenuItem_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label8);
            Controls.Add(textBoxamontDue);
            Controls.Add(labelDUE);
            Controls.Add(textBoxTradeinallowance);
            Controls.Add(label6);
            Controls.Add(textBoxTotal);
            Controls.Add(label5);
            Controls.Add(textBoxTAx);
            Controls.Add(label4);
            Controls.Add(textBoxSubtotal);
            Controls.Add(label3);
            Controls.Add(textBoxAccessoriesandFInish);
            Controls.Add(label2);
            Controls.Add(textBoxCarsaleprice);
            Controls.Add(label1);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "METHOD REVISED Car purchace project";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private CheckBox checkBoxNav;
        private CheckBox checkBoxLeather;
        private CheckBox checkBoxSterio;
        private GroupBox groupBox2;
        private RadioButton radioButtonCustom;
        private RadioButton radioButtonPearlized;
        private RadioButton radioButtonStandard;
        private Label label1;
        private TextBox textBoxCarsaleprice;
        private TextBox textBoxAccessoriesandFInish;
        private Label label2;
        private TextBox textBoxSubtotal;
        private Label label3;
        private TextBox textBoxTAx;
        private Label label4;
        private TextBox textBoxTotal;
        private Label label5;
        private TextBox textBoxTradeinallowance;
        private Label label6;
        private TextBox textBoxamontDue;
        private Label labelDUE;
        private Label label8;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private ToolStripMenuItem editToolStripMenuItem;
        private ToolStripMenuItem calculateToolStripMenuItem;
        private ToolStripMenuItem clearToolStripMenuItem;
        private ToolStripMenuItem fontToolStripMenuItem;
        private ToolStripMenuItem colourToolStripMenuItem;
        private ToolStripMenuItem helpToolStripMenuItem;
        private ToolStripMenuItem aboutToolStripMenuItem;
        private ColorDialog colorDialog1;
        private FontDialog fontDialog1;
    }
}
