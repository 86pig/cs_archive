﻿namespace _1117474_Li_Unit9StockClassProject
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            textBoxName = new TextBox();
            textBoxPLPercent = new TextBox();
            textBoxPL = new TextBox();
            textBoxMarketValue = new TextBox();
            textBoxLastPrice = new TextBox();
            textBoxPrice = new TextBox();
            textBoxQuantity = new TextBox();
            textBoxSymbol = new TextBox();
            buttonBuy = new Button();
            buttonUpdate = new Button();
            label9 = new Label();
            listBoxStocks = new ListBox();
            buttonSave = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(22, 15);
            label1.Name = "label1";
            label1.Size = new Size(94, 15);
            label1.TabIndex = 0;
            label1.Text = "Company Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(22, 409);
            label2.Name = "label2";
            label2.Size = new Size(74, 15);
            label2.TabIndex = 1;
            label2.Text = "Profit/Loss%";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(22, 346);
            label3.Name = "label3";
            label3.Size = new Size(64, 15);
            label3.TabIndex = 2;
            label3.Text = "Profit/Loss";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(22, 294);
            label4.Name = "label4";
            label4.Size = new Size(75, 15);
            label4.TabIndex = 3;
            label4.Text = "Market Value";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(22, 234);
            label5.Name = "label5";
            label5.Size = new Size(57, 15);
            label5.TabIndex = 4;
            label5.Text = "Last Price";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(22, 171);
            label6.Name = "label6";
            label6.Size = new Size(33, 15);
            label6.TabIndex = 5;
            label6.Text = "Price";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(22, 116);
            label7.Name = "label7";
            label7.Size = new Size(53, 15);
            label7.TabIndex = 6;
            label7.Text = "Quantity";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(22, 59);
            label8.Name = "label8";
            label8.Size = new Size(47, 15);
            label8.TabIndex = 7;
            label8.Text = "Symbol";
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(158, 17);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(100, 23);
            textBoxName.TabIndex = 8;
            // 
            // textBoxPLPercent
            // 
            textBoxPLPercent.Location = new Point(158, 409);
            textBoxPLPercent.Name = "textBoxPLPercent";
            textBoxPLPercent.ReadOnly = true;
            textBoxPLPercent.Size = new Size(100, 23);
            textBoxPLPercent.TabIndex = 9;
            // 
            // textBoxPL
            // 
            textBoxPL.Location = new Point(158, 346);
            textBoxPL.Name = "textBoxPL";
            textBoxPL.ReadOnly = true;
            textBoxPL.Size = new Size(100, 23);
            textBoxPL.TabIndex = 10;
            // 
            // textBoxMarketValue
            // 
            textBoxMarketValue.Location = new Point(158, 294);
            textBoxMarketValue.Name = "textBoxMarketValue";
            textBoxMarketValue.ReadOnly = true;
            textBoxMarketValue.Size = new Size(100, 23);
            textBoxMarketValue.TabIndex = 11;
            // 
            // textBoxLastPrice
            // 
            textBoxLastPrice.Location = new Point(158, 234);
            textBoxLastPrice.Name = "textBoxLastPrice";
            textBoxLastPrice.Size = new Size(100, 23);
            textBoxLastPrice.TabIndex = 12;
            // 
            // textBoxPrice
            // 
            textBoxPrice.Location = new Point(158, 171);
            textBoxPrice.Name = "textBoxPrice";
            textBoxPrice.Size = new Size(100, 23);
            textBoxPrice.TabIndex = 13;
            // 
            // textBoxQuantity
            // 
            textBoxQuantity.Location = new Point(158, 116);
            textBoxQuantity.Name = "textBoxQuantity";
            textBoxQuantity.Size = new Size(100, 23);
            textBoxQuantity.TabIndex = 14;
            // 
            // textBoxSymbol
            // 
            textBoxSymbol.Location = new Point(158, 59);
            textBoxSymbol.Name = "textBoxSymbol";
            textBoxSymbol.Size = new Size(100, 23);
            textBoxSymbol.TabIndex = 15;
            // 
            // buttonBuy
            // 
            buttonBuy.Location = new Point(375, 25);
            buttonBuy.Name = "buttonBuy";
            buttonBuy.Size = new Size(127, 49);
            buttonBuy.TabIndex = 16;
            buttonBuy.Text = "Buy Stock";
            buttonBuy.UseVisualStyleBackColor = true;
            buttonBuy.Click += buttonBuy_Click;
            // 
            // buttonUpdate
            // 
            buttonUpdate.Location = new Point(375, 102);
            buttonUpdate.Name = "buttonUpdate";
            buttonUpdate.Size = new Size(127, 49);
            buttonUpdate.TabIndex = 17;
            buttonUpdate.Text = "Update Stock Value";
            buttonUpdate.UseVisualStyleBackColor = true;
            buttonUpdate.Click += buttonUpdate_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(519, 147);
            label9.Name = "label9";
            label9.Size = new Size(53, 15);
            label9.TabIndex = 18;
            label9.Text = "Portfolio";
            // 
            // listBoxStocks
            // 
            listBoxStocks.FormattingEnabled = true;
            listBoxStocks.ItemHeight = 15;
            listBoxStocks.Location = new Point(519, 187);
            listBoxStocks.Name = "listBoxStocks";
            listBoxStocks.Size = new Size(250, 214);
            listBoxStocks.TabIndex = 19;
            listBoxStocks.SelectedIndexChanged += listBoxStocks_SelectedIndexChanged;
            // 
            // buttonSave
            // 
            buttonSave.Location = new Point(381, 175);
            buttonSave.Name = "buttonSave";
            buttonSave.Size = new Size(121, 52);
            buttonSave.TabIndex = 20;
            buttonSave.Text = "Save Portfolio";
            buttonSave.UseVisualStyleBackColor = true;
            buttonSave.Click += buttonSave_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonSave);
            Controls.Add(listBoxStocks);
            Controls.Add(label9);
            Controls.Add(buttonUpdate);
            Controls.Add(buttonBuy);
            Controls.Add(textBoxSymbol);
            Controls.Add(textBoxQuantity);
            Controls.Add(textBoxPrice);
            Controls.Add(textBoxLastPrice);
            Controls.Add(textBoxMarketValue);
            Controls.Add(textBoxPL);
            Controls.Add(textBoxPLPercent);
            Controls.Add(textBoxName);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Unit 9 Stock Class Project";
            FormClosing += Form1_FormClosing;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private TextBox textBoxName;
        private TextBox textBoxPLPercent;
        private TextBox textBoxPL;
        private TextBox textBoxMarketValue;
        private TextBox textBoxLastPrice;
        private TextBox textBoxPrice;
        private TextBox textBoxQuantity;
        private TextBox textBoxSymbol;
        private Button buttonBuy;
        private Button buttonUpdate;
        private Label label9;
        private ListBox listBoxStocks;
        private Button buttonSave;
    }
}
