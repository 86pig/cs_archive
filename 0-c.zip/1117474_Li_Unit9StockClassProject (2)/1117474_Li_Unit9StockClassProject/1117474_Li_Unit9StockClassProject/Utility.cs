﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace _1117474_Li_Unit9StockClassProject
{
    public class Utility
    {
        public static bool IsDirty { get; set; }

        private static JsonSerializer serializer = new JsonSerializer();
        public static void WriteToFile(Stock[] stocks, string fileName)
        {
            //created serializer

            StreamWriter streamwriter = new StreamWriter(fileName);
            serializer.Formatting = Formatting.Indented;

            //serialize the array
            serializer.Serialize(streamwriter, stocks, typeof(Stock[]));

            streamwriter.Flush();
            streamwriter.Close();
        }

        public static Stock[] ReadFromFile(string fileName)
        {
            StreamReader reader = new StreamReader(fileName);

            var stocks = serializer.Deserialize(reader, typeof(Stock[]));
            reader.Close();

            if (stocks == null) return new Stock[10];

            

            return (Stock[])stocks;
        }
    }
}