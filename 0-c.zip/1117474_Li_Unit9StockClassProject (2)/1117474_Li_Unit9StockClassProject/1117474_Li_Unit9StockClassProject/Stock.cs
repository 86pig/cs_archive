﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace _1117474_Li_Unit9StockClassProject
{
    public class Stock
    {
        public string CompanyName { get; set; }
        public string Symbol { get; set; }
        public int Quantity { get; set; }
        public double PricePaid { get; set; }
        public double LastPrice { get; set; }

        public Stock(string cn, string s, int q,  double p, double pp)
        {
            CompanyName = cn;
            Symbol = s;
            Quantity = q;
            PricePaid = p;
            LastPrice = pp;
        }

        public double MarketValue
        {
            get
            {
                return GetMarketValue();
            }
        }

        public double Profit
        {
            get
            {
                return GetProfit();
            }
        }

        public double ProfitPercentage
        {
            get
            {
                return GetProfitPercentage();   
            }
        }

        public double GetMarketValue()
        {
            return Quantity * LastPrice;
        }
        public double GetProfit()
        {
            return (Quantity*LastPrice)-(Quantity*PricePaid);
        }
        public double GetProfitPercentage()
        {
            return ((Quantity*LastPrice)-(Quantity* PricePaid))/(Quantity*PricePaid);
        }
    }
}
