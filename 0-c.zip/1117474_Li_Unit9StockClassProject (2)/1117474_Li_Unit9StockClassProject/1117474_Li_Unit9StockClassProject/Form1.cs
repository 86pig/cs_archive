using Newtonsoft.Json;
using System.Net.Http.Headers;
namespace _1117474_Li_Unit9StockClassProject
{
    public partial class Form1 : Form
    {
        private List<Stock> stocks = new List<Stock>();
        const string DATA_FILE = "stocks.json";
        public Form1()
        {
            InitializeComponent();

            FileInfo fileinfo = new FileInfo(DATA_FILE);
            if (fileinfo.Exists)
            {
                stocks = Utility.ReadFromFile(fileinfo.FullName).ToList();

                //listBoxStocks.Items.AddRange(Utility.ReadFromFile(fileinfo.FullName));
            }

            foreach (Stock stock in stocks)
            {
                listBoxStocks.Items.Add(stock.CompanyName);
            }

            Utility.IsDirty = false;
        }

        private void buttonBuy_Click(object sender, EventArgs e)
        {
            try
            {
                Stock stock = new Stock(textBoxName.Text, textBoxSymbol.Text, int.Parse(textBoxQuantity.Text),
                                         double.Parse(textBoxPrice.Text), double.Parse(textBoxPrice.Text));
                textBoxMarketValue.Text = stock.MarketValue.ToString("C");
                textBoxPL.Text = stock.Profit.ToString("C");
                textBoxPLPercent.Text = stock.ProfitPercentage.ToString("P");
                stocks.Add(stock);
                listBoxStocks.Items.Add(stock.CompanyName);
                Utility.IsDirty = true;
            }
            catch
            {
                MessageBox.Show("Enter valid information!");
            }
            //WriteToFile("stocks.json", stocks);
        }

        private void listBoxStocks_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxStocks.SelectedIndex == -1) return;
            int idx = listBoxStocks.SelectedIndex;
            textBoxName.Text = stocks[idx].CompanyName;
            textBoxSymbol.Text = stocks[idx].Symbol;
            textBoxQuantity.Text = stocks[idx].Quantity.ToString();
            textBoxPrice.Text = stocks[idx].PricePaid.ToString();
            textBoxLastPrice.Text = stocks[idx].LastPrice.ToString();
            textBoxMarketValue.Text = stocks[idx].MarketValue.ToString("C");
            textBoxPL.Text = (stocks[idx].Profit >= 0 ? stocks[idx].Profit.ToString("C") : '-' + Math.Abs(stocks[idx].Profit).ToString("C"));
            textBoxPLPercent.Text = stocks[idx].ProfitPercentage.ToString("P");
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            if (listBoxStocks.SelectedIndex == -1) return;
            int idx = listBoxStocks.SelectedIndex;
            stocks[idx].LastPrice = double.Parse(textBoxLastPrice.Text);

            textBoxMarketValue.Text = stocks[idx].MarketValue.ToString("C");
            textBoxPL.Text = (stocks[idx].Profit >= 0 ? stocks[idx].Profit.ToString("C") : '-' + Math.Abs(stocks[idx].Profit).ToString("C"));
            textBoxPLPercent.Text = stocks[idx].ProfitPercentage.ToString("P");

            Utility.IsDirty = true;
            //WriteToFile("stocks.json", stocks);
        }

        public static void WriteToFile(string dataFile, List<Stock> stocks)
        {
            StreamWriter writer = new StreamWriter(dataFile, false);
            JsonSerializer jsonSerializer = new JsonSerializer();
            jsonSerializer.Serialize(writer, stocks, typeof(List<Stock>));
            writer.Flush();
            writer.Close();
        }

        public static List<Stock> ReadFromFile(string dataFile)
        {
            StreamReader reader = new StreamReader(dataFile);
            JsonSerializer jsonSerializer = new JsonSerializer();
            var list = (List<Stock>)jsonSerializer.Deserialize(reader, typeof(List<Stock>));
            reader.Close();
            return list;
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            Utility.WriteToFile(stocks.ToArray(), DATA_FILE);
            Utility.IsDirty = false;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Utility.IsDirty)
            {
                var result = MessageBox.Show("You have unsaved data. Save now?", "Unsaved Data", MessageBoxButtons.YesNo);
                if (result==DialogResult.Yes)
                {
                    Utility.WriteToFile(stocks.ToArray(), DATA_FILE);
                }
            }
        }
    }
}
