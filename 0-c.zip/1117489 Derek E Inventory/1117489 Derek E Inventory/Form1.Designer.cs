﻿namespace _1117489_Derek_E_Inventory
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            BegggingingINVENTORY = new TextBox();
            endingINVENtory = new TextBox();
            costofGOODSsold = new TextBox();
            averageInventory = new TextBox();
            turnover = new TextBox();
            buttonCALCULATE = new Button();
            buttonClear = new Button();
            buttonExit = new Button();
            nameTEXTOX = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F);
            label1.Location = new Point(50, 50);
            label1.Name = "label1";
            label1.Size = new Size(150, 21);
            label1.TabIndex = 0;
            label1.Text = "Beginning Inventory";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F);
            label2.Location = new Point(50, 100);
            label2.Name = "label2";
            label2.Size = new Size(128, 21);
            label2.TabIndex = 1;
            label2.Text = "Ending Inventory";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F);
            label3.Location = new Point(50, 150);
            label3.Name = "label3";
            label3.Size = new Size(139, 21);
            label3.TabIndex = 2;
            label3.Text = "Cost of goods sold";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F);
            label4.Location = new Point(50, 250);
            label4.Name = "label4";
            label4.Size = new Size(137, 21);
            label4.TabIndex = 3;
            label4.Text = "Average Inventory";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F);
            label5.Location = new Point(50, 300);
            label5.Name = "label5";
            label5.Size = new Size(117, 21);
            label5.TabIndex = 4;
            label5.Text = "Apple Turnover";
            // 
            // BegggingingINVENTORY
            // 
            BegggingingINVENTORY.Location = new Point(220, 52);
            BegggingingINVENTORY.Name = "BegggingingINVENTORY";
            BegggingingINVENTORY.Size = new Size(100, 23);
            BegggingingINVENTORY.TabIndex = 5;
            // 
            // endingINVENtory
            // 
            endingINVENtory.Location = new Point(220, 102);
            endingINVENtory.Name = "endingINVENtory";
            endingINVENtory.Size = new Size(100, 23);
            endingINVENtory.TabIndex = 6;
            // 
            // costofGOODSsold
            // 
            costofGOODSsold.Location = new Point(220, 152);
            costofGOODSsold.Name = "costofGOODSsold";
            costofGOODSsold.Size = new Size(100, 23);
            costofGOODSsold.TabIndex = 7;
            // 
            // averageInventory
            // 
            averageInventory.Location = new Point(220, 252);
            averageInventory.Name = "averageInventory";
            averageInventory.ReadOnly = true;
            averageInventory.Size = new Size(100, 23);
            averageInventory.TabIndex = 8;
            // 
            // turnover
            // 
            turnover.Location = new Point(220, 302);
            turnover.Name = "turnover";
            turnover.ReadOnly = true;
            turnover.Size = new Size(100, 23);
            turnover.TabIndex = 9;
            // 
            // buttonCALCULATE
            // 
            buttonCALCULATE.Location = new Point(370, 50);
            buttonCALCULATE.Name = "buttonCALCULATE";
            buttonCALCULATE.Size = new Size(153, 45);
            buttonCALCULATE.TabIndex = 10;
            buttonCALCULATE.Text = "Calcula&te";
            buttonCALCULATE.UseVisualStyleBackColor = true;
            buttonCALCULATE.Click += buttonCALCULATE_Click;
            // 
            // buttonClear
            // 
            buttonClear.Location = new Point(370, 130);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(153, 45);
            buttonClear.TabIndex = 11;
            buttonClear.Text = "&Clear";
            buttonClear.UseVisualStyleBackColor = true;
            buttonClear.Click += buttonClear_Click;
            // 
            // buttonExit
            // 
            buttonExit.Location = new Point(370, 280);
            buttonExit.Name = "buttonExit";
            buttonExit.Size = new Size(153, 45);
            buttonExit.TabIndex = 12;
            buttonExit.Text = "E&xit";
            buttonExit.UseVisualStyleBackColor = true;
            buttonExit.Click += buttonExit_Click;
            // 
            // nameTEXTOX
            // 
            nameTEXTOX.AutoSize = true;
            nameTEXTOX.Location = new Point(436, 212);
            nameTEXTOX.Name = "nameTEXTOX";
            nameTEXTOX.Size = new Size(46, 15);
            nameTEXTOX.TabIndex = 13;
            nameTEXTOX.Text = "Derek E";
            // 
            // Form1
            // 
            AcceptButton = buttonCALCULATE;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = buttonExit;
            ClientSize = new Size(800, 450);
            Controls.Add(nameTEXTOX);
            Controls.Add(buttonExit);
            Controls.Add(buttonClear);
            Controls.Add(buttonCALCULATE);
            Controls.Add(turnover);
            Controls.Add(averageInventory);
            Controls.Add(costofGOODSsold);
            Controls.Add(endingINVENtory);
            Controls.Add(BegggingingINVENTORY);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Inventory";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox BegggingingINVENTORY;
        private TextBox endingINVENtory;
        private TextBox costofGOODSsold;
        private TextBox averageInventory;
        private TextBox turnover;
        private Button buttonCALCULATE;
        private Button buttonClear;
        private Button buttonExit;
        private Label nameTEXTOX;
    }
}
