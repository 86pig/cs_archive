using System.Linq.Expressions;

namespace _1117489_Derek_E_Inventory
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            BegggingingINVENTORY.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonCALCULATE_Click(object sender, EventArgs e)
        {
            int beginning, end, cost;
            double average, turnoverF;

            try
            {

                beginning = int.Parse(BegggingingINVENTORY.Text);
                end = int.Parse(endingINVENtory.Text);
                cost = int.Parse(costofGOODSsold.Text);

                average = (beginning + end) / 2;
                turnoverF = cost / average;

                averageInventory.Text = average.ToString("C");
                turnover.Text = turnoverF.ToString("N1");
                nameTEXTOX.Focus();
            }
            catch
            {
                MessageBox.Show("use a number");
                BegggingingINVENTORY.Clear();
                endingINVENtory.Clear();
                costofGOODSsold.Clear();
                averageInventory.Clear();
                turnover.Clear();
                BegggingingINVENTORY.Focus();
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            BegggingingINVENTORY.Clear();
            endingINVENtory.Clear();
            costofGOODSsold.Clear();
            averageInventory.Clear();
            turnover.Clear();
            BegggingingINVENTORY.Focus();
        }
    }
}
