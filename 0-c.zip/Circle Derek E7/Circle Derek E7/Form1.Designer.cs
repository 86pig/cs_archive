﻿namespace Circle_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBoxame = new TextBox();
            textBoxradius = new TextBox();
            label2 = new Label();
            textBoxdiameter = new TextBox();
            label3 = new Label();
            textBoxarea = new TextBox();
            label4 = new Label();
            textBoxcircumffer = new TextBox();
            label5 = new Label();
            listBoxCircle = new ListBox();
            buttonadd = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(42, 50);
            label1.Name = "label1";
            label1.Size = new Size(39, 15);
            label1.TabIndex = 0;
            label1.Text = "Name";
            // 
            // textBoxame
            // 
            textBoxame.Location = new Point(121, 47);
            textBoxame.Name = "textBoxame";
            textBoxame.Size = new Size(100, 23);
            textBoxame.TabIndex = 1;
            // 
            // textBoxradius
            // 
            textBoxradius.Location = new Point(121, 76);
            textBoxradius.Name = "textBoxradius";
            textBoxradius.Size = new Size(100, 23);
            textBoxradius.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(42, 79);
            label2.Name = "label2";
            label2.Size = new Size(42, 15);
            label2.TabIndex = 2;
            label2.Text = "Radius";
            // 
            // textBoxdiameter
            // 
            textBoxdiameter.Location = new Point(121, 105);
            textBoxdiameter.Name = "textBoxdiameter";
            textBoxdiameter.ReadOnly = true;
            textBoxdiameter.Size = new Size(100, 23);
            textBoxdiameter.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(42, 108);
            label3.Name = "label3";
            label3.Size = new Size(55, 15);
            label3.TabIndex = 4;
            label3.Text = "Diameter";
            // 
            // textBoxarea
            // 
            textBoxarea.Location = new Point(121, 134);
            textBoxarea.Name = "textBoxarea";
            textBoxarea.ReadOnly = true;
            textBoxarea.Size = new Size(100, 23);
            textBoxarea.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(42, 137);
            label4.Name = "label4";
            label4.Size = new Size(31, 15);
            label4.TabIndex = 6;
            label4.Text = "Area";
            // 
            // textBoxcircumffer
            // 
            textBoxcircumffer.Location = new Point(121, 163);
            textBoxcircumffer.Name = "textBoxcircumffer";
            textBoxcircumffer.ReadOnly = true;
            textBoxcircumffer.Size = new Size(100, 23);
            textBoxcircumffer.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(42, 166);
            label5.Name = "label5";
            label5.Size = new Size(85, 15);
            label5.TabIndex = 8;
            label5.Text = "Circumference";
            // 
            // listBoxCircle
            // 
            listBoxCircle.FormattingEnabled = true;
            listBoxCircle.ItemHeight = 15;
            listBoxCircle.Location = new Point(255, 47);
            listBoxCircle.Name = "listBoxCircle";
            listBoxCircle.Size = new Size(211, 139);
            listBoxCircle.TabIndex = 10;
            listBoxCircle.SelectedIndexChanged += listBoxCircle_SelectedIndexChanged;
            // 
            // buttonadd
            // 
            buttonadd.Location = new Point(42, 203);
            buttonadd.Name = "buttonadd";
            buttonadd.Size = new Size(424, 144);
            buttonadd.TabIndex = 11;
            buttonadd.Text = "add circle";
            buttonadd.UseVisualStyleBackColor = true;
            buttonadd.Click += buttonadd_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonadd);
            Controls.Add(listBoxCircle);
            Controls.Add(textBoxcircumffer);
            Controls.Add(label5);
            Controls.Add(textBoxarea);
            Controls.Add(label4);
            Controls.Add(textBoxdiameter);
            Controls.Add(label3);
            Controls.Add(textBoxradius);
            Controls.Add(label2);
            Controls.Add(textBoxame);
            Controls.Add(label1);
            Name = "Form1";
            Text = "textBoxName.Text";
            TopMost = true;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBoxame;
        private TextBox textBoxradius;
        private Label label2;
        private TextBox textBoxdiameter;
        private Label label3;
        private TextBox textBoxarea;
        private Label label4;
        private TextBox textBoxcircumffer;
        private Label label5;
        private ListBox listBoxCircle;
        private Button buttonadd;
    }
}
