using System.Windows.Forms;

namespace Circle_Derek_E7
{
    public partial class Form1 : Form
    {
        List<Circle> circles = new List<Circle>();


        public Form1()
        {
            InitializeComponent();
        }

        private void buttonadd_Click(object sender, EventArgs e)
        {
            Circle circle;
            try
            {
                circle = new Circle(textBoxame.Text, double.Parse(textBoxradius.Text));

            }
            catch
            {
                MessageBox.Show("wrong input you lost iq.");
                return;
            }
            textBoxarea.Text = circle.Area.ToString();
            textBoxdiameter.Text = circle.Diameter.ToString();
            textBoxcircumffer.Text = circle.Circum.ToString();
            
            circles.Add(circle);
            listBoxCircle.Items.Add(circle.CircleName);

        }

        private void listBoxCircle_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxCircle.SelectedIndex == -1) return;

            int index = listBoxCircle.SelectedIndex;
            textBoxame.Text = circles[index].CircleName;
            textBoxcircumffer.Text = circles[index].Circum.ToString();
            textBoxradius.Text = circles[index].Radius.ToString();
            textBoxarea.Text = circles[index].Area.ToString();
            textBoxdiameter.Text = circles[index ].Diameter.ToString();

        }
    }
}
