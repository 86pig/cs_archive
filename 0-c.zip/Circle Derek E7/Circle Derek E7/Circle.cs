﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;

namespace Circle_Derek_E7
{
    public class Circle
    {


        public Circle()
        {
            CircleName = string.Empty;
        }
        public Circle(string circleName, double radius)
        {
            CircleName = circleName;
            Radius = radius;
        }

        public string CircleName { get; set; }
        public double Radius { get; set; }

        public double Area
        {
            get
            {
                return GetArea();
            }
        }
        public double Diameter
        {
            get
            {
                return GetDiam();
            }
        }
        public double Circum
        {
            get
            {
                return GetCircum();
            }
        }

        public double GetDiam()
        {
            return 2 * Radius;
        }
        public double GetCircum()
        {
            return 2 * Math.PI * Radius;
        }
        public double GetArea()
        {
            return Math.PI * Math.Pow(Radius, 2);
        }








    }
}
