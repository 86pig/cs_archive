﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace Bank_Derek_E7
{
    public class Account
    {
        public string AccountName { get; set; }
        public string AccountNumber { get; set; }
        public double Balance { get; set; }
        public List<Transaction> Transactions { get; set; }
        public Account (string n, string h, double b)
        {
            AccountName = n;
            AccountNumber = h;
            Balance = b;
            Transactions = new List<Transaction> ();
        }
        public void Deposit(double amt)
        {
            Balance += amt;
            return;
        }
        public bool Wtihd(double amt)
        {
            if (Balance >= amt)
            {
                Balance -= amt;
                return true;
            }
            else
            {
                return false;
            }
            
        }
        public override string ToString()
        {
            return AccountName += "\n Acc #" + AccountNumber + "\n Balance: " + Balance + "\n Transaction:"; 
        }
    }
}
