﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank_Derek_E7
{
    public partial class Accountinfo : Form
    {
        public Accountinfo()
        {
            InitializeComponent();
        }

        public int index { get; set; }
        public List<Account> Accounts { get; set; }
        public List<Transaction> AccountTransactions { get; set; }

        private void AccountInfo_Load(object sender, EventArgs e)
        {
            textbonamaenemNAME.Text = Accounts[index].AccountName;
            textBoxaccnum.Text = Accounts[index].AccountNumber;
            textBoxbal.Text = Accounts[index].Balance.ToString("C");

            foreach (Transaction t in AccountTransactions)
            {
                transactionsbox.Items.Add(t.Desc);
            }

            desctxt.Clear();

        }

        private void buttonDoTransaction_Click(object sender, EventArgs e)
        {
            if (radioButtonDepos.Checked || radiobuttonwithrdar.Checked)
            {
                if (!string.IsNullOrEmpty(desctxt.Text) &&
                    !string.IsNullOrEmpty(datemasekd.Text) &&
                    !string.IsNullOrEmpty(amounttxtx.Text))
                {
                    try
                    {
                        string desc = desctxt.Text;
                        string date = datemasekd.Text;
                        double amount = double.Parse(amounttxtx.Text);

                        if (radioButtonDepos.Checked)
                        {
                            Transaction transaction = new Transaction(radioButtonDepos.Checked, radiobuttonwithrdar.Checked, desc, date, amount);
                            Accounts[index].Deposit(amount);

                            Accounts[index].Transactions.Add(transaction);
                            transactionsbox.Items.Add(desc);
                        }
                        else if (radiobuttonwithrdar.Checked)
                        {
                            if (Accounts[index].Wtihd(amount))
                            {
                                Transaction transaction = new Transaction(radioButtonDepos.Checked, radiobuttonwithrdar.Checked, desc, date, amount);
                                Accounts[index].Balance -= amount;

                                Accounts[index].Transactions.Add(transaction);
                                transactionsbox.Items.Add(desc);
                            }
                        }

                        transactionsbox.SelectedIndex = -1;
                        radioButtonDepos.Checked = false;
                        radiobuttonwithrdar.Checked = false;
                        desctxt.Clear();
                        amounttxtx.Clear();
                        datemasekd.Clear();
                        textBoxbal.Text = Accounts[index].Balance.ToString("C");

                    }
                    catch
                    {
                        MessageBox.Show("bad input");
                    }
                }
                else
                {
                    MessageBox.Show("fill out all shown inputs");
                }
            }
            else
            {
                MessageBox.Show("select a transaction method");
            }
        }

        private void AccountInfo_Click(object sender, EventArgs e)
        {
            if (transactionsbox.SelectedIndex != -1)
            {
                transactionsbox.SelectedIndex = -1;
                radioButtonDepos.Checked = false;
                radiobuttonwithrdar.Checked = false;
                desctxt.Clear();
                amounttxtx.Clear();
                datemasekd.Clear();
            }
        }

        private void listBoxTransactions_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (transactionsbox.SelectedIndex != -1)
            {
                int i = transactionsbox.SelectedIndex;
                radioButtonDepos.Checked = Accounts[index].Transactions[i].Deposit;
                radiobuttonwithrdar.Checked = !Accounts[index].Transactions[i].Deposit;
                desctxt.Text = Accounts[index].Transactions[i].Desc;
                amounttxtx.Text = Accounts[index].Transactions[i].Amount.ToString("C");
                datemasekd.Text = Accounts[index].Transactions[i].Date;

            }
        }
    }
}
