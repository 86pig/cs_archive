namespace Bank_Derek_E7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public List<Account> accounts = new List<Account>();
        private void buttoncreate_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBoxName.Text)
                && !string.IsNullOrWhiteSpace(textBoxaccnum.Text)
                && !string.IsNullOrWhiteSpace(textBoxbalance.Text))
            {
                accounts.Add(new Account(textBoxName.Text, textBoxaccnum.Text, double.Parse(textBoxbalance.Text)));
            }
            else
            {
                MessageBox.Show("try again");
                listBoxaccounts.SelectedIndex = -1;
                return;
            }
            listBoxaccounts.Items.Add(textBoxName.Text);
            textBoxName.Clear();
            textBoxbalance.Clear();
            textBoxaccnum.Clear();
            listBoxaccounts.SelectedIndex = -1;
            textBoxName.Focus();
        }

        private void listBoxaccounts_DoubleClick(object sender, EventArgs e)
        {
            if (listBoxaccounts.SelectedItems.Count != -1)
            {
                int i = listBoxaccounts.SelectedIndex;
                Account account = accounts[i];
                Accountinfo transactionDlg = new Accountinfo();
                //transactionDlg.NameThing = accounts[i].AccountName;
                //transactionDlg.AccountThing = accounts[i].AccountNumber;
                //transactionDlg.BalanceThing = accounts[i].Balance;
               
                //textBoxbalance.Text = accounts[i].Balance.ToString("C");
                transactionDlg.ShowDialog();
                i = transactionDlg.index;
                
                account.Transactions = transactionDlg.AccountTransactions;
            }

        }

        private void listBoxaccounts_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int i = listBoxaccounts.SelectedIndex;
                textBoxName.Text = accounts[i].AccountName;
                textBoxaccnum.Text = accounts[i].AccountNumber;
                textBoxbalance.Text = accounts[i].Balance.ToString("C");
            }
            catch
            {
                listBoxaccounts.SelectedIndex = -1;
                textBoxName.Focus();
            }
        }

        private void label3_DoubleClick(object sender, EventArgs e)
        {

        }

        private void textBoxName_MouseClick(object sender, MouseEventArgs e)
        {
            textBoxName.Clear();
            textBoxaccnum.Clear();
            textBoxbalance.Clear();
            listBoxaccounts.SelectedIndex = -1;
            textBoxName.Clear();
        }
    }
}