﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank_Derek_E7
{
    public class Transaction
    {
        public bool Deposit { get; set; }
        public bool Withdrawl { get; set; }
        public string Desc { get; set; }
        public string Date { get; set; }
        public double Amount { get; set; }

        public Transaction (bool d, bool w, string desc, string date, double a)
        {
            Deposit = d;
            Withdrawl = w;
            Desc = desc;
            Date = date;
            Amount = a;

        }
        public override string ToString()
        {
            string achoo = "";
            if (Deposit = true)
            {
                achoo = "Deposit";
            }
            else if (Withdrawl = true)
            {
                achoo = "Withdrawl";
            }
            else
            {
                achoo = "eorrer";
            }
            return Desc + "\n " + "Transaction type: " + achoo + "\n" + "Date: " + Date + "\n Amount: " + Amount;
        }


    }
}
