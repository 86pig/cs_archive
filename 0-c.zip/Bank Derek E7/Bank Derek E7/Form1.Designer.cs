﻿namespace Bank_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listBoxaccounts = new ListBox();
            label1 = new Label();
            textBoxName = new TextBox();
            textBoxaccnum = new TextBox();
            label2 = new Label();
            textBoxbalance = new TextBox();
            label3 = new Label();
            buttoncreate = new Button();
            SuspendLayout();
            // 
            // listBoxaccounts
            // 
            listBoxaccounts.FormattingEnabled = true;
            listBoxaccounts.ItemHeight = 15;
            listBoxaccounts.Location = new Point(47, 50);
            listBoxaccounts.Name = "listBoxaccounts";
            listBoxaccounts.Size = new Size(152, 229);
            listBoxaccounts.TabIndex = 0;
            listBoxaccounts.SelectedIndexChanged += listBoxaccounts_SelectedIndexChanged;
            listBoxaccounts.DoubleClick += listBoxaccounts_DoubleClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(245, 59);
            label1.Name = "label1";
            label1.Size = new Size(39, 15);
            label1.TabIndex = 1;
            label1.Text = "Name";
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(307, 56);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(100, 23);
            textBoxName.TabIndex = 2;
            textBoxName.MouseClick += textBoxName_MouseClick;
            // 
            // textBoxaccnum
            // 
            textBoxaccnum.Location = new Point(307, 85);
            textBoxaccnum.Name = "textBoxaccnum";
            textBoxaccnum.Size = new Size(100, 23);
            textBoxaccnum.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(245, 88);
            label2.Name = "label2";
            label2.Size = new Size(35, 15);
            label2.TabIndex = 3;
            label2.Text = "acc #";
            // 
            // textBoxbalance
            // 
            textBoxbalance.Location = new Point(307, 114);
            textBoxbalance.Name = "textBoxbalance";
            textBoxbalance.Size = new Size(100, 23);
            textBoxbalance.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(245, 117);
            label3.Name = "label3";
            label3.Size = new Size(42, 15);
            label3.TabIndex = 5;
            label3.Text = "blance";
            label3.DoubleClick += label3_DoubleClick;
            // 
            // buttoncreate
            // 
            buttoncreate.Location = new Point(235, 149);
            buttoncreate.Name = "buttoncreate";
            buttoncreate.Size = new Size(172, 130);
            buttoncreate.TabIndex = 7;
            buttoncreate.Text = "create new accunt";
            buttoncreate.UseVisualStyleBackColor = true;
            buttoncreate.Click += buttoncreate_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(496, 340);
            Controls.Add(buttoncreate);
            Controls.Add(textBoxbalance);
            Controls.Add(label3);
            Controls.Add(textBoxaccnum);
            Controls.Add(label2);
            Controls.Add(textBoxName);
            Controls.Add(label1);
            Controls.Add(listBoxaccounts);
            Name = "Form1";
            Text = "Bank";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox listBoxaccounts;
        private Label label1;
        private TextBox textBoxName;
        private TextBox textBoxaccnum;
        private Label label2;
        private TextBox textBoxbalance;
        private Label label3;
        private Button buttoncreate;
    }
}
