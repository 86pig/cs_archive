﻿namespace Bank_Derek_E7
{
    partial class Accountinfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBoxbalance = new TextBox();
            label3 = new Label();
            textBoxaccnum = new TextBox();
            label2 = new Label();
            textBoxName = new TextBox();
            label1 = new Label();
            listBoxTransactions = new ListBox();
            label4 = new Label();
            dsaoifhasiougfiasouhgisuahg = new GroupBox();
            buttonTrans = new Button();
            label7 = new Label();
            maskedTextBoxDate = new MaskedTextBox();
            textBoxAMount = new TextBox();
            label6 = new Label();
            textBoxDesc = new TextBox();
            label5 = new Label();
            radioButtonWithdrawl = new RadioButton();
            radioButtonDeposit = new RadioButton();
            textBoxbal = new TextBox();
            label8 = new Label();
            textBoxacccun = new TextBox();
            label9 = new Label();
            textbonamaenemNAME = new TextBox();
            label10 = new Label();
            transactionsbox = new ListBox();
            groupBox1 = new GroupBox();
            buttontransact = new Button();
            datemasekd = new MaskedTextBox();
            amounttxtx = new TextBox();
            radiobuttonwithrdar = new RadioButton();
            label11 = new Label();
            radioButtonDepos = new RadioButton();
            label12 = new Label();
            label13 = new Label();
            desctxt = new TextBox();
            dsaoifhasiougfiasouhgisuahg.SuspendLayout();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // textBoxbalance
            // 
            textBoxbalance.Location = new Point(125, 99);
            textBoxbalance.Name = "textBoxbalance";
            textBoxbalance.ReadOnly = true;
            textBoxbalance.Size = new Size(100, 23);
            textBoxbalance.TabIndex = 12;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(63, 102);
            label3.Name = "label3";
            label3.Size = new Size(42, 15);
            label3.TabIndex = 11;
            label3.Text = "blance";
            // 
            // textBoxaccnum
            // 
            textBoxaccnum.Location = new Point(125, 70);
            textBoxaccnum.Name = "textBoxaccnum";
            textBoxaccnum.ReadOnly = true;
            textBoxaccnum.Size = new Size(100, 23);
            textBoxaccnum.TabIndex = 10;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(63, 73);
            label2.Name = "label2";
            label2.Size = new Size(35, 15);
            label2.TabIndex = 9;
            label2.Text = "acc #";
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(125, 41);
            textBoxName.Name = "textBoxName";
            textBoxName.ReadOnly = true;
            textBoxName.Size = new Size(100, 23);
            textBoxName.TabIndex = 8;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(63, 44);
            label1.Name = "label1";
            label1.Size = new Size(39, 15);
            label1.TabIndex = 7;
            label1.Text = "Name";
            // 
            // listBoxTransactions
            // 
            listBoxTransactions.FormattingEnabled = true;
            listBoxTransactions.ItemHeight = 15;
            listBoxTransactions.Location = new Point(63, 170);
            listBoxTransactions.Name = "listBoxTransactions";
            listBoxTransactions.Size = new Size(162, 214);
            listBoxTransactions.TabIndex = 13;
            listBoxTransactions.SelectedIndexChanged += listBoxTransactions_SelectedIndexChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(63, 139);
            label4.Name = "label4";
            label4.Size = new Size(72, 15);
            label4.TabIndex = 14;
            label4.Text = "Transactions";
            // 
            // dsaoifhasiougfiasouhgisuahg
            // 
            dsaoifhasiougfiasouhgisuahg.Controls.Add(buttonTrans);
            dsaoifhasiougfiasouhgisuahg.Controls.Add(label7);
            dsaoifhasiougfiasouhgisuahg.Controls.Add(maskedTextBoxDate);
            dsaoifhasiougfiasouhgisuahg.Controls.Add(textBoxAMount);
            dsaoifhasiougfiasouhgisuahg.Controls.Add(label6);
            dsaoifhasiougfiasouhgisuahg.Controls.Add(textBoxDesc);
            dsaoifhasiougfiasouhgisuahg.Controls.Add(label5);
            dsaoifhasiougfiasouhgisuahg.Controls.Add(radioButtonWithdrawl);
            dsaoifhasiougfiasouhgisuahg.Controls.Add(radioButtonDeposit);
            dsaoifhasiougfiasouhgisuahg.Location = new Point(277, 44);
            dsaoifhasiougfiasouhgisuahg.Name = "dsaoifhasiougfiasouhgisuahg";
            dsaoifhasiougfiasouhgisuahg.Size = new Size(230, 340);
            dsaoifhasiougfiasouhgisuahg.TabIndex = 15;
            dsaoifhasiougfiasouhgisuahg.TabStop = false;
            dsaoifhasiougfiasouhgisuahg.Text = "Transaction";
            // 
            // buttonTrans
            // 
            buttonTrans.Location = new Point(0, 0);
            buttonTrans.Name = "buttonTrans";
            buttonTrans.Size = new Size(75, 23);
            buttonTrans.TabIndex = 0;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(6, 134);
            label7.Name = "label7";
            label7.Size = new Size(41, 15);
            label7.TabIndex = 23;
            label7.Text = "Date :(";
            // 
            // maskedTextBoxDate
            // 
            maskedTextBoxDate.Location = new Point(78, 131);
            maskedTextBoxDate.Mask = "00/00/0000";
            maskedTextBoxDate.Name = "maskedTextBoxDate";
            maskedTextBoxDate.Size = new Size(100, 23);
            maskedTextBoxDate.TabIndex = 22;
            maskedTextBoxDate.ValidatingType = typeof(DateTime);
            // 
            // textBoxAMount
            // 
            textBoxAMount.Location = new Point(78, 160);
            textBoxAMount.Name = "textBoxAMount";
            textBoxAMount.Size = new Size(100, 23);
            textBoxAMount.TabIndex = 21;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(6, 163);
            label6.Name = "label6";
            label6.Size = new Size(51, 15);
            label6.TabIndex = 20;
            label6.Text = "Amount";
            // 
            // textBoxDesc
            // 
            textBoxDesc.Location = new Point(78, 102);
            textBoxDesc.Name = "textBoxDesc";
            textBoxDesc.Size = new Size(100, 23);
            textBoxDesc.TabIndex = 19;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(6, 105);
            label5.Name = "label5";
            label5.Size = new Size(32, 15);
            label5.TabIndex = 18;
            label5.Text = "Desc";
            // 
            // radioButtonWithdrawl
            // 
            radioButtonWithdrawl.AutoSize = true;
            radioButtonWithdrawl.Location = new Point(6, 56);
            radioButtonWithdrawl.Name = "radioButtonWithdrawl";
            radioButtonWithdrawl.Size = new Size(79, 19);
            radioButtonWithdrawl.TabIndex = 17;
            radioButtonWithdrawl.TabStop = true;
            radioButtonWithdrawl.Text = "Withdrawl";
            radioButtonWithdrawl.UseVisualStyleBackColor = true;
            // 
            // radioButtonDeposit
            // 
            radioButtonDeposit.AutoSize = true;
            radioButtonDeposit.Location = new Point(6, 30);
            radioButtonDeposit.Name = "radioButtonDeposit";
            radioButtonDeposit.Size = new Size(65, 19);
            radioButtonDeposit.TabIndex = 16;
            radioButtonDeposit.TabStop = true;
            radioButtonDeposit.Text = "Deposit";
            radioButtonDeposit.UseVisualStyleBackColor = true;
            // 
            // textBoxbal
            // 
            textBoxbal.Location = new Point(115, 91);
            textBoxbal.Name = "textBoxbal";
            textBoxbal.Size = new Size(100, 23);
            textBoxbal.TabIndex = 12;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(53, 94);
            label8.Name = "label8";
            label8.Size = new Size(42, 15);
            label8.TabIndex = 11;
            label8.Text = "blance";
            // 
            // textBoxacccun
            // 
            textBoxacccun.Location = new Point(115, 62);
            textBoxacccun.Name = "textBoxacccun";
            textBoxacccun.Size = new Size(100, 23);
            textBoxacccun.TabIndex = 10;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(53, 65);
            label9.Name = "label9";
            label9.Size = new Size(35, 15);
            label9.TabIndex = 9;
            label9.Text = "acc #";
            // 
            // textbonamaenemNAME
            // 
            textbonamaenemNAME.Location = new Point(115, 33);
            textbonamaenemNAME.Name = "textbonamaenemNAME";
            textbonamaenemNAME.Size = new Size(100, 23);
            textbonamaenemNAME.TabIndex = 8;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(53, 36);
            label10.Name = "label10";
            label10.Size = new Size(39, 15);
            label10.TabIndex = 7;
            label10.Text = "Name";
            // 
            // transactionsbox
            // 
            transactionsbox.FormattingEnabled = true;
            transactionsbox.ItemHeight = 15;
            transactionsbox.Location = new Point(58, 136);
            transactionsbox.Name = "transactionsbox";
            transactionsbox.Size = new Size(157, 109);
            transactionsbox.TabIndex = 13;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(buttontransact);
            groupBox1.Controls.Add(datemasekd);
            groupBox1.Controls.Add(amounttxtx);
            groupBox1.Controls.Add(radiobuttonwithrdar);
            groupBox1.Controls.Add(label11);
            groupBox1.Controls.Add(radioButtonDepos);
            groupBox1.Controls.Add(label12);
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(desctxt);
            groupBox1.Location = new Point(248, 33);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(210, 212);
            groupBox1.TabIndex = 14;
            groupBox1.TabStop = false;
            groupBox1.Text = "transactoin";
            // 
            // buttontransact
            // 
            buttontransact.Location = new Point(42, 156);
            buttontransact.Name = "buttontransact";
            buttontransact.Size = new Size(110, 50);
            buttontransact.TabIndex = 15;
            buttontransact.Text = "transact";
            buttontransact.UseVisualStyleBackColor = true;
            // 
            // datemasekd
            // 
            datemasekd.Location = new Point(84, 87);
            datemasekd.Mask = "00/00/0000";
            datemasekd.Name = "datemasekd";
            datemasekd.Size = new Size(100, 23);
            datemasekd.TabIndex = 15;
            datemasekd.ValidatingType = typeof(DateTime);
            // 
            // amounttxtx
            // 
            amounttxtx.Location = new Point(83, 116);
            amounttxtx.Name = "amounttxtx";
            amounttxtx.Size = new Size(100, 23);
            amounttxtx.TabIndex = 20;
            // 
            // radiobuttonwithrdar
            // 
            radiobuttonwithrdar.AutoSize = true;
            radiobuttonwithrdar.Location = new Point(106, 22);
            radiobuttonwithrdar.Name = "radiobuttonwithrdar";
            radiobuttonwithrdar.Size = new Size(79, 19);
            radiobuttonwithrdar.TabIndex = 1;
            radiobuttonwithrdar.TabStop = true;
            radiobuttonwithrdar.Text = "Withdrawl";
            radiobuttonwithrdar.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(21, 119);
            label11.Name = "label11";
            label11.Size = new Size(49, 15);
            label11.TabIndex = 19;
            label11.Text = "amount";
            // 
            // radioButtonDepos
            // 
            radioButtonDepos.AutoSize = true;
            radioButtonDepos.Location = new Point(6, 22);
            radioButtonDepos.Name = "radioButtonDepos";
            radioButtonDepos.Size = new Size(65, 19);
            radioButtonDepos.TabIndex = 0;
            radioButtonDepos.TabStop = true;
            radioButtonDepos.Text = "Deposit";
            radioButtonDepos.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(21, 90);
            label12.Name = "label12";
            label12.Size = new Size(35, 15);
            label12.TabIndex = 17;
            label12.Text = "acc #";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(21, 61);
            label13.Name = "label13";
            label13.Size = new Size(32, 15);
            label13.TabIndex = 15;
            label13.Text = "Desc";
            label13.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // desctxt
            // 
            desctxt.Location = new Point(83, 58);
            desctxt.Name = "desctxt";
            desctxt.Size = new Size(100, 23);
            desctxt.TabIndex = 16;
            // 
            // Accountinfo
            // 
            ClientSize = new Size(480, 289);
            Controls.Add(groupBox1);
            Controls.Add(transactionsbox);
            Controls.Add(textBoxbal);
            Controls.Add(label8);
            Controls.Add(textBoxacccun);
            Controls.Add(label9);
            Controls.Add(textbonamaenemNAME);
            Controls.Add(label10);
            Name = "Accountinfo";
            Text = "Accountinfo";
            dsaoifhasiougfiasouhgisuahg.ResumeLayout(false);
            dsaoifhasiougfiasouhgisuahg.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxbalance;
        private Label label3;
        private TextBox textBoxaccnum;
        private Label label2;
        private TextBox textBoxName;
        private Label label1;
        private ListBox listBoxTransactions;
        private Label label4;
        private GroupBox dsaoifhasiougfiasouhgisuahg;
        private RadioButton radioButtonDeposit;
        private Label label7;
        private MaskedTextBox maskedTextBoxDate;
        private TextBox textBoxAMount;
        private Label label6;
        private TextBox textBoxDesc;
        private Label label5;
        private RadioButton radioButtonWithdrawl;
        private Button buttonTrans;
        private TextBox textBoxbal;
        private Label label8;
        private TextBox textBoxacccun;
        private Label label9;
        private TextBox textbonamaenemNAME;
        private Label label10;
        private ListBox transactionsbox;
        private GroupBox groupBox1;
        private Button buttontransact;
        private MaskedTextBox datemasekd;
        private TextBox amounttxtx;
        private RadioButton radiobuttonwithrdar;
        private Label label11;
        private RadioButton radioButtonDepos;
        private Label label12;
        private Label label13;
        private TextBox desctxt;
    }
}