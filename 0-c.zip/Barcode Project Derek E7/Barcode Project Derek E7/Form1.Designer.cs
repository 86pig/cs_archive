﻿namespace Barcode_Project_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBoxsip = new TextBox();
            textBoxbarcode = new TextBox();
            label3 = new Label();
            buttonexit = new Button();
            buttongetbcode = new Button();
            listBoxcodes = new ListBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(147, 42);
            label1.Name = "label1";
            label1.Size = new Size(50, 15);
            label1.TabIndex = 1;
            label1.Text = "Zipcode";
            // 
            // textBoxsip
            // 
            textBoxsip.Location = new Point(203, 39);
            textBoxsip.MaxLength = 5;
            textBoxsip.Name = "textBoxsip";
            textBoxsip.Size = new Size(126, 23);
            textBoxsip.TabIndex = 2;
            // 
            // textBoxbarcode
            // 
            textBoxbarcode.Location = new Point(203, 97);
            textBoxbarcode.Name = "textBoxbarcode";
            textBoxbarcode.ReadOnly = true;
            textBoxbarcode.Size = new Size(126, 23);
            textBoxbarcode.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(147, 100);
            label3.Name = "label3";
            label3.Size = new Size(50, 15);
            label3.TabIndex = 5;
            label3.Text = "Barcode";
            // 
            // buttonexit
            // 
            buttonexit.Location = new Point(179, 197);
            buttonexit.Name = "buttonexit";
            buttonexit.Size = new Size(96, 62);
            buttonexit.TabIndex = 7;
            buttonexit.Text = "buttonex9t";
            buttonexit.UseVisualStyleBackColor = true;
            buttonexit.Click += buttonexit_Click;
            // 
            // buttongetbcode
            // 
            buttongetbcode.Location = new Point(147, 172);
            buttongetbcode.Name = "buttongetbcode";
            buttongetbcode.Size = new Size(182, 126);
            buttongetbcode.TabIndex = 8;
            buttongetbcode.Text = "Get barcode";
            buttongetbcode.UseVisualStyleBackColor = true;
            buttongetbcode.Click += buttongetbcode_Click;
            // 
            // listBoxcodes
            // 
            listBoxcodes.Font = new Font("Segoe UI", 13.5F);
            listBoxcodes.FormattingEnabled = true;
            listBoxcodes.ItemHeight = 25;
            listBoxcodes.Items.AddRange(new object[] { "||╷╷╷", "╷╷╷||", "╷╷|╷|", "╷╷||╷", "╷|╷╷|", "╷|╷|╷", "╷||╷╷", "|╷╷╷|", "|╷╷|╷", "|╷|╷╷" });
            listBoxcodes.Location = new Point(21, 42);
            listBoxcodes.Name = "listBoxcodes";
            listBoxcodes.Size = new Size(94, 254);
            listBoxcodes.TabIndex = 9;
            // 
            // Form1
            // 
            AcceptButton = buttongetbcode;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = buttonexit;
            ClientSize = new Size(378, 336);
            Controls.Add(listBoxcodes);
            Controls.Add(buttongetbcode);
            Controls.Add(buttonexit);
            Controls.Add(textBoxbarcode);
            Controls.Add(label3);
            Controls.Add(textBoxsip);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Postal Barcodes";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private TextBox textBoxsip;
        private TextBox textBoxbarcode;
        private Label label3;
        private Button buttonexit;
        private Button buttongetbcode;
        private ListBox listBoxcodes;
    }
}
