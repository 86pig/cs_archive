namespace Barcode_Project_Derek_E7
{
    public partial class Form1 : Form
    { 

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonexit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttongetbcode_Click(object sender, EventArgs e)
        {
            try
            {
                string number = textBoxsip.Text;
                string barcode = string.Empty;

                for (int i = 0; i < number.Length; i++)
                {
                    int index = int.Parse(number[i].ToString());

                    barcode += listBoxcodes.Items[index];

                }
                textBoxbarcode.Text = barcode;
            }

            catch
            {
                MessageBox.Show("enter a number only zipcode");

            }
        }

    }
}
