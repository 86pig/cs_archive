﻿namespace Bank_Calculations_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            textBoxBalance = new TextBox();
            textBoxTransaction = new TextBox();
            label3 = new Label();
            label2 = new Label();
            radioButtonServiceCharge = new RadioButton();
            radioButtonDeposit = new RadioButton();
            radioButtonCheck = new RadioButton();
            labelName = new Label();
            buttoncalculate = new Button();
            buttonreset = new Button();
            buttonEXit = new Button();
            buttonsummary = new Button();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBoxBalance);
            groupBox1.Controls.Add(textBoxTransaction);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(radioButtonServiceCharge);
            groupBox1.Controls.Add(radioButtonDeposit);
            groupBox1.Controls.Add(radioButtonCheck);
            groupBox1.Location = new Point(90, 49);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(246, 250);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Account Calcualtions";
            // 
            // textBoxBalance
            // 
            textBoxBalance.Location = new Point(140, 193);
            textBoxBalance.Name = "textBoxBalance";
            textBoxBalance.ReadOnly = true;
            textBoxBalance.Size = new Size(100, 23);
            textBoxBalance.TabIndex = 5;
            textBoxBalance.Text = "$500.00";
            // 
            // textBoxTransaction
            // 
            textBoxTransaction.Location = new Point(140, 160);
            textBoxTransaction.Name = "textBoxTransaction";
            textBoxTransaction.Size = new Size(100, 23);
            textBoxTransaction.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10F);
            label3.Location = new Point(6, 194);
            label3.Name = "label3";
            label3.Size = new Size(55, 19);
            label3.TabIndex = 3;
            label3.Text = "Balance";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F);
            label2.Location = new Point(6, 161);
            label2.Name = "label2";
            label2.Size = new Size(78, 19);
            label2.TabIndex = 2;
            label2.Text = "Transaction";
            // 
            // radioButtonServiceCharge
            // 
            radioButtonServiceCharge.AutoSize = true;
            radioButtonServiceCharge.Location = new Point(28, 86);
            radioButtonServiceCharge.Name = "radioButtonServiceCharge";
            radioButtonServiceCharge.Size = new Size(101, 19);
            radioButtonServiceCharge.TabIndex = 2;
            radioButtonServiceCharge.Text = "Service charge";
            radioButtonServiceCharge.UseVisualStyleBackColor = true;
            radioButtonServiceCharge.CheckedChanged += radioButtonServiceCharge_CheckedChanged;
            // 
            // radioButtonDeposit
            // 
            radioButtonDeposit.AutoSize = true;
            radioButtonDeposit.Location = new Point(28, 61);
            radioButtonDeposit.Name = "radioButtonDeposit";
            radioButtonDeposit.Size = new Size(65, 19);
            radioButtonDeposit.TabIndex = 1;
            radioButtonDeposit.Text = "Deposit";
            radioButtonDeposit.UseVisualStyleBackColor = true;
            radioButtonDeposit.CheckedChanged += radioButtonDeposit_CheckedChanged;
            // 
            // radioButtonCheck
            // 
            radioButtonCheck.AutoSize = true;
            radioButtonCheck.Checked = true;
            radioButtonCheck.Location = new Point(28, 36);
            radioButtonCheck.Name = "radioButtonCheck";
            radioButtonCheck.Size = new Size(58, 19);
            radioButtonCheck.TabIndex = 0;
            radioButtonCheck.TabStop = true;
            radioButtonCheck.Text = "Check";
            radioButtonCheck.UseVisualStyleBackColor = true;
            radioButtonCheck.CheckedChanged += radioButtonCheck_CheckedChanged;
            // 
            // labelName
            // 
            labelName.AutoSize = true;
            labelName.Font = new Font("Segoe UI", 10F);
            labelName.Location = new Point(90, 366);
            labelName.Name = "labelName";
            labelName.Size = new Size(64, 19);
            labelName.TabIndex = 1;
            labelName.Text = "Derek E7";
            // 
            // buttoncalculate
            // 
            buttoncalculate.Location = new Point(368, 49);
            buttoncalculate.Name = "buttoncalculate";
            buttoncalculate.Size = new Size(106, 80);
            buttoncalculate.TabIndex = 2;
            buttoncalculate.Text = "&Calculate";
            buttoncalculate.UseVisualStyleBackColor = true;
            buttoncalculate.Click += buttoncalculate_Click;
            // 
            // buttonreset
            // 
            buttonreset.Location = new Point(368, 133);
            buttonreset.Name = "buttonreset";
            buttonreset.Size = new Size(106, 80);
            buttonreset.TabIndex = 3;
            buttonreset.Text = "&Reset";
            buttonreset.UseVisualStyleBackColor = true;
            buttonreset.Click += buttonreset_Click;
            // 
            // buttonEXit
            // 
            buttonEXit.Location = new Point(368, 305);
            buttonEXit.Name = "buttonEXit";
            buttonEXit.Size = new Size(106, 80);
            buttonEXit.TabIndex = 4;
            buttonEXit.Text = "E&xit";
            buttonEXit.UseVisualStyleBackColor = true;
            buttonEXit.Click += buttonEXit_Click;
            // 
            // buttonsummary
            // 
            buttonsummary.Location = new Point(368, 219);
            buttonsummary.Name = "buttonsummary";
            buttonsummary.Size = new Size(106, 80);
            buttonsummary.TabIndex = 5;
            buttonsummary.Text = "&Summary";
            buttonsummary.UseVisualStyleBackColor = true;
            buttonsummary.Click += buttonsummary_Click;
            // 
            // Form1
            // 
            AcceptButton = buttoncalculate;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = buttonEXit;
            ClientSize = new Size(540, 410);
            Controls.Add(buttonsummary);
            Controls.Add(buttonEXit);
            Controls.Add(buttonreset);
            Controls.Add(buttoncalculate);
            Controls.Add(labelName);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Banc Acc Calc";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox textBoxBalance;
        private TextBox textBoxTransaction;
        private Label label3;
        private Label label2;
        private RadioButton radioButtonServiceCharge;
        private RadioButton radioButtonDeposit;
        private RadioButton radioButtonCheck;
        private Label labelName;
        private Button buttoncalculate;
        private Button buttonreset;
        private Button buttonEXit;
        private Button buttonsummary;
    }
}
