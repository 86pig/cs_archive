namespace Bank_Calculations_Derek_E7
{
    public partial class Form1 : Form
    {
        double Balance = 500.00;
        const double servicecharge = 35.00;
        const double feee = 10.00;

        int numberofdeposits = 0;
        double totaldollaramountofdeposits = 0;
        int numberofchecks = 0;
        double dollamountofchecks = 0;


        public Form1()
        {
            InitializeComponent();
            textBoxTransaction.Focus();


        }

        private void buttonEXit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonreset_Click(object sender, EventArgs e)
        {
            radioButtonCheck.Checked = true;
            textBoxTransaction.Clear();
            textBoxTransaction.Focus();
            Balance = 500.00;
            numberofdeposits = 0;
            totaldollaramountofdeposits = 0;
            numberofchecks = 0;
            dollamountofchecks = 0;
            textBoxBalance.Text = Balance.ToString("C");
        }

        private void buttoncalculate_Click(object sender, EventArgs e)
        {
            labelName.Focus();

            try
            {
                double transaction, depositamount, chargeee, valueofdebt;

                transaction = double.Parse(textBoxTransaction.Text);
                if (radioButtonCheck.Checked)
                {
                    if (transaction <= Balance)
                    {
                        Balance -= transaction;
                        numberofchecks++;
                        dollamountofchecks += transaction;
                        textBoxBalance.Text = Balance.ToString("C");
                        textBoxTransaction.Clear();
                        textBoxTransaction.Focus();
                        textBoxTransaction.ReadOnly = false;
                    }
                    else
                    {
                        valueofdebt = Balance - transaction;
                        MessageBox.Show("You ... would ... be in debt...:  " + valueofdebt);
                        Balance -= feee;
                        textBoxBalance.Text = Balance.ToString("C");
                        textBoxTransaction.Clear();
                        textBoxTransaction.Focus();
                    }
                }

                else if (radioButtonDeposit.Checked)
                {
                    depositamount = double.Parse(textBoxTransaction.Text);
                    Balance += depositamount;
                    numberofdeposits++;
                    totaldollaramountofdeposits += depositamount;
                    textBoxBalance.Text = Balance.ToString("C");
                    textBoxTransaction.Clear();
                    textBoxTransaction.Focus();
                    textBoxTransaction.ReadOnly = false;
                }

                else if (radioButtonServiceCharge.Checked)
                {
                    textBoxTransaction.ReadOnly = true;
                    textBoxTransaction.Text = servicecharge.ToString();
                    chargeee = double.Parse(textBoxTransaction.Text);
                    Balance -= chargeee;
                    textBoxBalance.Text = Balance.ToString("C");
                    textBoxTransaction.Clear();
                    textBoxTransaction.Focus();

                }

            }


            catch
            {
                MessageBox.Show("Enter a valid value");
                textBoxTransaction.Clear();
                textBoxTransaction.Focus();
            }
        }

        private void buttonsummary_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Total number of deposits: " + numberofdeposits + "\n" + "Total dollar amount of deposits: " + totaldollaramountofdeposits + "\n" + "Total number of checks: " + numberofchecks + "\n" + "Total dollar amount of checks: " + dollamountofchecks);




        }

        private void radioButtonServiceCharge_CheckedChanged(object sender, EventArgs e)
        {
            textBoxTransaction.Text = servicecharge.ToString();
            textBoxTransaction.Focus();
            textBoxTransaction.ReadOnly = true;
        }

        private void radioButtonDeposit_CheckedChanged(object sender, EventArgs e)
        {
            textBoxTransaction.Clear();
            textBoxTransaction.Focus();
            textBoxTransaction.ReadOnly = false;
        }

        private void radioButtonCheck_CheckedChanged(object sender, EventArgs e)
        {
            textBoxTransaction.Clear();
            textBoxTransaction.Focus();
            textBoxTransaction.ReadOnly = false;
        }
    }
}
//get help
//figure it out


//i figured it out!
//if theres a problem pls let me know and ill fix it (ill try my very very best))))~~~~!!!!!!!!!!!!!!