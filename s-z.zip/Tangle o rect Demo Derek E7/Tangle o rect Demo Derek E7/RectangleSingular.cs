﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace Tangle_o_rect_Demo_Derek_E7
{
    public class RectangleSingular
    {
        public RectangleSingular()
        {
            rectName = string.Empty;
        }
        public RectangleSingular(double length, double width, string name)
        {
            Length = length;
            Width = width;
            rectName = name;
        }
        
        public string rectName { get; set; }
        public double Length { get; set; }
        public double Width { get; set; }
        
        public double Area
        {
            get
            {
                return GetArea();
            }
        }
        public double Perimeter
        {
            get
            {
                return GetPerimeter();
            }
        }
        public double GetArea()
        {
            return Length * Width;
        }

        public double GetPerimeter()
        {
            return (Length + Width) * 2;
        }
        
    }
}
