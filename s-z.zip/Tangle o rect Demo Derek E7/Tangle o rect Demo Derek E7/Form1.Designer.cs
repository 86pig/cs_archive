﻿namespace Tangle_o_rect_Demo_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBoxName = new TextBox();
            textBoxLength = new TextBox();
            label2 = new Label();
            textBoxWidth = new TextBox();
            label3 = new Label();
            textBoxArea = new TextBox();
            label4 = new Label();
            textBoxPerim = new TextBox();
            label5 = new Label();
            listBoxRect = new ListBox();
            buttonadd = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(116, 105);
            label1.Name = "label1";
            label1.Size = new Size(39, 15);
            label1.TabIndex = 0;
            label1.Text = "Name";
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(194, 102);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(100, 23);
            textBoxName.TabIndex = 1;
            // 
            // textBoxLength
            // 
            textBoxLength.Location = new Point(194, 131);
            textBoxLength.Name = "textBoxLength";
            textBoxLength.Size = new Size(100, 23);
            textBoxLength.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(116, 134);
            label2.Name = "label2";
            label2.Size = new Size(44, 15);
            label2.TabIndex = 2;
            label2.Text = "Length";
            // 
            // textBoxWidth
            // 
            textBoxWidth.Location = new Point(194, 160);
            textBoxWidth.Name = "textBoxWidth";
            textBoxWidth.Size = new Size(100, 23);
            textBoxWidth.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(116, 163);
            label3.Name = "label3";
            label3.Size = new Size(39, 15);
            label3.TabIndex = 4;
            label3.Text = "Width";
            // 
            // textBoxArea
            // 
            textBoxArea.Location = new Point(194, 189);
            textBoxArea.Name = "textBoxArea";
            textBoxArea.Size = new Size(100, 23);
            textBoxArea.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(116, 192);
            label4.Name = "label4";
            label4.Size = new Size(31, 15);
            label4.TabIndex = 6;
            label4.Text = "Area";
            // 
            // textBoxPerim
            // 
            textBoxPerim.Location = new Point(194, 218);
            textBoxPerim.Name = "textBoxPerim";
            textBoxPerim.Size = new Size(100, 23);
            textBoxPerim.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(116, 221);
            label5.Name = "label5";
            label5.Size = new Size(38, 15);
            label5.TabIndex = 8;
            label5.Text = "Perim";
            // 
            // listBoxRect
            // 
            listBoxRect.FormattingEnabled = true;
            listBoxRect.ItemHeight = 15;
            listBoxRect.Location = new Point(324, 102);
            listBoxRect.Name = "listBoxRect";
            listBoxRect.Size = new Size(178, 139);
            listBoxRect.TabIndex = 10;
            listBoxRect.SelectedIndexChanged += listBoxRect_SelectedIndexChanged;
            // 
            // buttonadd
            // 
            buttonadd.Location = new Point(116, 247);
            buttonadd.Name = "buttonadd";
            buttonadd.Size = new Size(386, 38);
            buttonadd.TabIndex = 11;
            buttonadd.Text = "add a stupid freacking rectangle";
            buttonadd.UseVisualStyleBackColor = true;
            buttonadd.Click += buttonadd_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonadd);
            Controls.Add(listBoxRect);
            Controls.Add(textBoxPerim);
            Controls.Add(label5);
            Controls.Add(textBoxArea);
            Controls.Add(label4);
            Controls.Add(textBoxWidth);
            Controls.Add(label3);
            Controls.Add(textBoxLength);
            Controls.Add(label2);
            Controls.Add(textBoxName);
            Controls.Add(label1);
            Name = "Form1";
            Text = "dumb spedy rectangl";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBoxName;
        private TextBox textBoxLength;
        private Label label2;
        private TextBox textBoxWidth;
        private Label label3;
        private TextBox textBoxArea;
        private Label label4;
        private TextBox textBoxPerim;
        private Label label5;
        private ListBox listBoxRect;
        private Button buttonadd;
    }
}
