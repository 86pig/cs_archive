namespace Tangle_o_rect_Demo_Derek_E7
{
    public partial class Form1 : Form
    {
        List<Rectangle> rectangles = new List<Rectangle>();


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttonadd_Click(object sender, EventArgs e)
        {
            RectangleSingular rectangle;
            try
            {
                rectangle = new RectangleSingular(double.Parse(textBoxLength.Text), double.Parse(textBoxWidth.Text), textBoxName.Text);
            }
            catch
            {
                MessageBox.Show("no");
                return;
            }

            textBoxArea.Text = rectangle.Area.ToString();
            textBoxPerim.Text = rectangle.Perimeter.ToString();

            rectangles.Add(rectangle);
            listBoxRect.Items.Add(rectangle.rectName);


        }

        private void listBoxRect_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxRect.SelectedIndex == -1) return;

            int index = listBoxRect.SelectedIndex;
            textBoxName.Text = rectangles[index].   ;
            textBoxLength.Text = rectangles[index].length


        }
    }
}
