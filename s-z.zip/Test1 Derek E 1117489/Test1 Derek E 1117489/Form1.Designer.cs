﻿namespace Test1_Derek_E_1117489
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            groupBox1 = new GroupBox();
            makthisinvis = new Label();
            schooladdressLABEL = new Label();
            logopictureboxX = new PictureBox();
            TEMPSELECTBUTTTTTTON = new RadioButton();
            addressboxofhohefiawhf = new CheckBox();
            woodinvillescholool = new RadioButton();
            northcreekSchoool = new RadioButton();
            inglemoorshocoool = new RadioButton();
            bothellschoool = new RadioButton();
            groupBox2 = new GroupBox();
            ressettBUTTOnnnnn = new Button();
            DispalAYYButton = new Button();
            isthislegalTEXTBOXage = new TextBox();
            SIDtextboxoxe = new TextBox();
            nametextBOX = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            bigboiinfoboxa = new RichTextBox();
            myname = new Label();
            exttttt = new Button();
            buttonDISPLA = new ToolTip(components);
            reset = new ToolTip(components);
            exittooltipbottno = new ToolTip(components);
            checkkker = new ToolTip(components);
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)logopictureboxX).BeginInit();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(makthisinvis);
            groupBox1.Controls.Add(schooladdressLABEL);
            groupBox1.Controls.Add(logopictureboxX);
            groupBox1.Controls.Add(TEMPSELECTBUTTTTTTON);
            groupBox1.Controls.Add(addressboxofhohefiawhf);
            groupBox1.Controls.Add(woodinvillescholool);
            groupBox1.Controls.Add(northcreekSchoool);
            groupBox1.Controls.Add(inglemoorshocoool);
            groupBox1.Controls.Add(bothellschoool);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(598, 168);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "School";
            // 
            // makthisinvis
            // 
            makthisinvis.AutoSize = true;
            makthisinvis.Location = new Point(127, 121);
            makthisinvis.Name = "makthisinvis";
            makthisinvis.Size = new Size(85, 15);
            makthisinvis.TabIndex = 17;
            makthisinvis.Text = "make this invis";
            makthisinvis.Visible = false;
            // 
            // schooladdressLABEL
            // 
            schooladdressLABEL.AutoSize = true;
            schooladdressLABEL.Location = new Point(127, 91);
            schooladdressLABEL.Name = "schooladdressLABEL";
            schooladdressLABEL.Size = new Size(52, 15);
            schooladdressLABEL.TabIndex = 16;
            schooladdressLABEL.Text = "Address:";
            schooladdressLABEL.Visible = false;
            // 
            // logopictureboxX
            // 
            logopictureboxX.Image = Properties.Resources.bothell_high_school;
            logopictureboxX.Location = new Point(378, 13);
            logopictureboxX.Name = "logopictureboxX";
            logopictureboxX.Size = new Size(214, 149);
            logopictureboxX.SizeMode = PictureBoxSizeMode.StretchImage;
            logopictureboxX.TabIndex = 1;
            logopictureboxX.TabStop = false;
            // 
            // TEMPSELECTBUTTTTTTON
            // 
            TEMPSELECTBUTTTTTTON.AutoSize = true;
            TEMPSELECTBUTTTTTTON.Checked = true;
            TEMPSELECTBUTTTTTTON.Location = new Point(127, 13);
            TEMPSELECTBUTTTTTTON.Name = "TEMPSELECTBUTTTTTTON";
            TEMPSELECTBUTTTTTTON.Size = new Size(257, 19);
            TEMPSELECTBUTTTTTTON.TabIndex = 6;
            TEMPSELECTBUTTTTTTON.TabStop = true;
            TEMPSELECTBUTTTTTTON.Text = "hidden (ignore. i read the instructions last :|)";
            TEMPSELECTBUTTTTTTON.UseVisualStyleBackColor = true;
            TEMPSELECTBUTTTTTTON.Visible = false;
            TEMPSELECTBUTTTTTTON.CheckedChanged += TEMPSELECTBUTTTTTTON_CheckedChanged;
            // 
            // addressboxofhohefiawhf
            // 
            addressboxofhohefiawhf.AutoSize = true;
            addressboxofhohefiawhf.Checked = true;
            addressboxofhohefiawhf.CheckState = CheckState.Checked;
            addressboxofhohefiawhf.Location = new Point(3, 143);
            addressboxofhohefiawhf.Name = "addressboxofhohefiawhf";
            addressboxofhohefiawhf.Size = new Size(100, 19);
            addressboxofhohefiawhf.TabIndex = 5;
            addressboxofhohefiawhf.Text = "&Show Address";
            checkkker.SetToolTip(addressboxofhohefiawhf, "Display selected school address");
            addressboxofhohefiawhf.UseVisualStyleBackColor = true;
            addressboxofhohefiawhf.CheckedChanged += addressboxofhohefiawhf_CheckedChanged;
            // 
            // woodinvillescholool
            // 
            woodinvillescholool.AutoSize = true;
            woodinvillescholool.Location = new Point(6, 97);
            woodinvillescholool.Name = "woodinvillescholool";
            woodinvillescholool.Size = new Size(88, 19);
            woodinvillescholool.TabIndex = 4;
            woodinvillescholool.Text = "&Woodinville";
            woodinvillescholool.UseVisualStyleBackColor = true;
            woodinvillescholool.CheckedChanged += woodinvillescholool_CheckedChanged;
            // 
            // northcreekSchoool
            // 
            northcreekSchoool.AutoSize = true;
            northcreekSchoool.Location = new Point(6, 72);
            northcreekSchoool.Name = "northcreekSchoool";
            northcreekSchoool.Size = new Size(84, 19);
            northcreekSchoool.TabIndex = 3;
            northcreekSchoool.Text = "&Northcreek";
            northcreekSchoool.UseVisualStyleBackColor = true;
            northcreekSchoool.CheckedChanged += northcreekSchoool_CheckedChanged;
            // 
            // inglemoorshocoool
            // 
            inglemoorshocoool.AutoSize = true;
            inglemoorshocoool.Location = new Point(6, 47);
            inglemoorshocoool.Name = "inglemoorshocoool";
            inglemoorshocoool.Size = new Size(80, 19);
            inglemoorshocoool.TabIndex = 2;
            inglemoorshocoool.Text = "&Inglemoor";
            inglemoorshocoool.UseVisualStyleBackColor = true;
            inglemoorshocoool.CheckedChanged += inglemoorshocoool_CheckedChanged;
            // 
            // bothellschoool
            // 
            bothellschoool.AutoSize = true;
            bothellschoool.Location = new Point(6, 22);
            bothellschoool.Name = "bothellschoool";
            bothellschoool.Size = new Size(62, 19);
            bothellschoool.TabIndex = 1;
            bothellschoool.Text = "&Bothell";
            bothellschoool.UseVisualStyleBackColor = true;
            bothellschoool.CheckedChanged += bothellschoool_CheckedChanged;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(ressettBUTTOnnnnn);
            groupBox2.Controls.Add(DispalAYYButton);
            groupBox2.Controls.Add(isthislegalTEXTBOXage);
            groupBox2.Controls.Add(SIDtextboxoxe);
            groupBox2.Controls.Add(nametextBOX);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(bigboiinfoboxa);
            groupBox2.Location = new Point(12, 206);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(598, 168);
            groupBox2.TabIndex = 7;
            groupBox2.TabStop = false;
            groupBox2.Text = "Student Info";
            // 
            // ressettBUTTOnnnnn
            // 
            ressettBUTTOnnnnn.Location = new Point(163, 134);
            ressettBUTTOnnnnn.Name = "ressettBUTTOnnnnn";
            ressettBUTTOnnnnn.Size = new Size(146, 28);
            ressettBUTTOnnnnn.TabIndex = 14;
            ressettBUTTOnnnnn.Text = "&Reset";
            reset.SetToolTip(ressettBUTTOnnnnn, "Clear all student info and reset school info");
            ressettBUTTOnnnnn.UseVisualStyleBackColor = true;
            ressettBUTTOnnnnn.Click += ressettBUTTOnnnnn_Click;
            // 
            // DispalAYYButton
            // 
            DispalAYYButton.Location = new Point(6, 134);
            DispalAYYButton.Name = "DispalAYYButton";
            DispalAYYButton.Size = new Size(146, 28);
            DispalAYYButton.TabIndex = 9;
            DispalAYYButton.Text = "Display Info";
            buttonDISPLA.SetToolTip(DispalAYYButton, "Display name, student ID, and age");
            DispalAYYButton.UseVisualStyleBackColor = true;
            DispalAYYButton.Click += DispalAYYButton_Click;
            // 
            // isthislegalTEXTBOXage
            // 
            isthislegalTEXTBOXage.Location = new Point(127, 83);
            isthislegalTEXTBOXage.Name = "isthislegalTEXTBOXage";
            isthislegalTEXTBOXage.Size = new Size(182, 23);
            isthislegalTEXTBOXage.TabIndex = 13;
            // 
            // SIDtextboxoxe
            // 
            SIDtextboxoxe.Location = new Point(127, 52);
            SIDtextboxoxe.Name = "SIDtextboxoxe";
            SIDtextboxoxe.Size = new Size(182, 23);
            SIDtextboxoxe.TabIndex = 12;
            // 
            // nametextBOX
            // 
            nametextBOX.Location = new Point(127, 22);
            nametextBOX.Name = "nametextBOX";
            nametextBOX.Size = new Size(182, 23);
            nametextBOX.TabIndex = 9;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(6, 81);
            label4.Name = "label4";
            label4.Size = new Size(37, 21);
            label4.TabIndex = 11;
            label4.Text = "Age";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(6, 50);
            label3.Name = "label3";
            label3.Size = new Size(82, 21);
            label3.TabIndex = 10;
            label3.Text = "Student ID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(6, 19);
            label2.Name = "label2";
            label2.Size = new Size(52, 21);
            label2.TabIndex = 9;
            label2.Text = "Name";
            // 
            // bigboiinfoboxa
            // 
            bigboiinfoboxa.Location = new Point(378, 22);
            bigboiinfoboxa.Name = "bigboiinfoboxa";
            bigboiinfoboxa.ReadOnly = true;
            bigboiinfoboxa.Size = new Size(214, 126);
            bigboiinfoboxa.TabIndex = 0;
            bigboiinfoboxa.Text = "";
            // 
            // myname
            // 
            myname.AutoSize = true;
            myname.Location = new Point(544, 404);
            myname.Name = "myname";
            myname.Size = new Size(46, 15);
            myname.TabIndex = 8;
            myname.Text = "Derek E";
            // 
            // exttttt
            // 
            exttttt.Location = new Point(293, 397);
            exttttt.Name = "exttttt";
            exttttt.Size = new Size(146, 28);
            exttttt.TabIndex = 15;
            exttttt.Text = "E&xit";
            exittooltipbottno.SetToolTip(exttttt, "Exit the program");
            exttttt.UseVisualStyleBackColor = true;
            exttttt.Click += exttttt_Click;
            // 
            // Form1
            // 
            AcceptButton = DispalAYYButton;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = exttttt;
            ClientSize = new Size(800, 450);
            Controls.Add(exttttt);
            Controls.Add(myname);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "It's a quiz, actually. #1 (Derek E)";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)logopictureboxX).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private CheckBox addressboxofhohefiawhf;
        private RadioButton woodinvillescholool;
        private RadioButton northcreekSchoool;
        private RadioButton inglemoorshocoool;
        private RadioButton bothellschoool;
        private PictureBox logopictureboxX;
        private RadioButton TEMPSELECTBUTTTTTTON;
        private GroupBox groupBox2;
        private RichTextBox bigboiinfoboxa;
        private Label myname;
        private TextBox isthislegalTEXTBOXage;
        private TextBox SIDtextboxoxe;
        private TextBox nametextBOX;
        private Label label4;
        private Label label3;
        private Label label2;
        private Button ressettBUTTOnnnnn;
        private Button DispalAYYButton;
        private Button exttttt;
        private Label makthisinvis;
        private Label schooladdressLABEL;
        private ToolTip checkkker;
        private ToolTip reset;
        private ToolTip buttonDISPLA;
        private ToolTip exittooltipbottno;
    }
}
