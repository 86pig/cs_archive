namespace Test1_Derek_E_1117489
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            bothellschoool.Checked = true;
            schooladdressLABEL.Visible = true;
            makthisinvis.Visible = true;
            //above, force the initial ui to look as standard
        }

        private void exttttt_Click(object sender, EventArgs e)
            //tie the exit button to closing the form. Also tie esc key to this button
        {
            this.Close();
        }
        
        //Make each radio button connect to their picture and address


        private void bothellschoool_CheckedChanged(object sender, EventArgs e)
        {
            logopictureboxX.Image = Properties.Resources.bothell_high_school;
            makthisinvis.Text = "9130 NE 180th St, Bothell, WA 98011";
        }

        private void inglemoorshocoool_CheckedChanged(object sender, EventArgs e)
        {
            logopictureboxX.Image = Properties.Resources.Inglemoor_Viking_Logo;
            makthisinvis.Text = "15500 Simonds Rd NE, Kenmore, WA 98028";
        }

        private void northcreekSchoool_CheckedChanged(object sender, EventArgs e)
        {
            logopictureboxX.Image = Properties.Resources.north_creek_high_school;
            makthisinvis.Text = "3613 191st Pl SE, Bothell, WA 98012";
        }

        private void woodinvillescholool_CheckedChanged(object sender, EventArgs e)
        {
            logopictureboxX.Image = Properties.Resources.woodinville_high_school;
            makthisinvis.Text = "19819 136th Ave NE, Woodinville, WA 98072";
        }


        //Make the address show or hide whenever the checkbox is changed

        private void addressboxofhohefiawhf_CheckedChanged(object sender, EventArgs e)
        {
            schooladdressLABEL.Visible = !schooladdressLABEL.Visible;
            makthisinvis.Visible = !makthisinvis.Visible;
        }

        //When the display button is clicked, make the user input into strings and display them in the rich text box.

        private void DispalAYYButton_Click(object sender, EventArgs e)
        {
            string name = nametextBOX.Text;
            string id = SIDtextboxoxe.Text;
            string age = isthislegalTEXTBOXage.Text;
            myname.Focus();

            bigboiinfoboxa.Text = "Name: " + name + "\n" + "Student ID: " + id + "\n" + "Age: " + age;
        }


        //When the reset button is clicked, clear all user info, clear the rich text box, and reset the school information to its default

        private void ressettBUTTOnnnnn_Click(object sender, EventArgs e)
        {
            bothellschoool.Checked = true;
            addressboxofhohefiawhf.Checked = true;
            logopictureboxX.Image = Properties.Resources.bothell_high_school;

            nametextBOX.Clear();
            SIDtextboxoxe.Clear();
            isthislegalTEXTBOXage.Clear();
            bigboiinfoboxa.Clear();
        }

        private void TEMPSELECTBUTTTTTTON_CheckedChanged(object sender, EventArgs e)
        {
            //oops an accidental click
        }
    }
}
