﻿namespace Sandwich_class_project_Derek_E7
{
    partial class Summary
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            buttonok = new Button();
            richTextBoxORder = new RichTextBox();
            timerE = new System.Windows.Forms.Timer(components);
            SuspendLayout();
            // 
            // buttonok
            // 
            buttonok.Location = new Point(323, 45);
            buttonok.Name = "buttonok";
            buttonok.Size = new Size(225, 312);
            buttonok.TabIndex = 0;
            buttonok.Text = "ok";
            buttonok.UseVisualStyleBackColor = true;
            buttonok.Click += buttonok_Click;
            // 
            // richTextBoxORder
            // 
            richTextBoxORder.Location = new Point(64, 45);
            richTextBoxORder.Name = "richTextBoxORder";
            richTextBoxORder.Size = new Size(226, 312);
            richTextBoxORder.TabIndex = 1;
            richTextBoxORder.Text = "";
            // 
            // timerE
            // 
            timerE.Interval = 2;
            timerE.Tick += timerE_Tick;
            // 
            // Summary
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(richTextBoxORder);
            Controls.Add(buttonok);
            Name = "Summary";
            Text = "Summary";
            Load += Summary_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button buttonok;
        private RichTextBox richTextBoxORder;
        private System.Windows.Forms.Timer timerE;
    }
}