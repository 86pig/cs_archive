﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sandwich_class_project_Derek_E7
{
    public partial class Summary : Form
    {
        public Sandwich CurrentSandwich { get; set; }

        public Summary()
        {
            InitializeComponent();
        }

        private void buttonok_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void timerE_Tick(object sender, EventArgs e)
        {
            richTextBoxORder.Text = CurrentSandwich.ToString();
        }

        private void Summary_Load(object sender, EventArgs e)
        {
            richTextBoxORder.Text = CurrentSandwich.ToString();
        }
    }
}
