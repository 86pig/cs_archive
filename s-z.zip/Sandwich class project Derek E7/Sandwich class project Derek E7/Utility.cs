﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Sandwich_class_project_Derek_E7
{
    internal class Utility
    {
        private static JsonSerializer serializer = new JsonSerializer();
        public static void WriteToFile(Sandwich[] stocks, string filename)
        {
            JsonSerializer serializer = new JsonSerializer();
            StreamWriter sr = new StreamWriter(filename);
            serializer.Serialize(sr, stocks, typeof(Sandwich[]));
            sr.Flush();
            sr.Close();

        }// this is the return  v
        public static Sandwich[] ReadFromFile(string filename)
        {
            StreamReader sr = new StreamReader(filename);
            var stocks = (Sandwich[])serializer.Deserialize(sr, typeof(Sandwich[]));
            sr.Close();
            if (stocks == null)
            {
                return new Sandwich[10];
            }
            Sandwich[] stock = (Sandwich[])stocks;
            return stock;
        }
    }
}

