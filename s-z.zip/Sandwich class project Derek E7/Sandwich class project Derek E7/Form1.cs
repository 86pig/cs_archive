namespace Sandwich_class_project_Derek_E7;
using Newtonsoft.Json;

public partial class Form1 : Form
{
    List<Sandwich> sandwiches = new List<Sandwich>();
    const string DATAFILE = "Sandwiches.json";
    bool isDirty = false;


    public Form1()
    {
        InitializeComponent();
        FileInfo fi = new FileInfo(DATAFILE);
        if (fi.Exists)
        {
            sandwiches = ReadFromFile(DATAFILE);
            foreach (Sandwich sandwich in sandwiches)
            {
                listBoxorder.Items.Add(sandwich.PersonName);
            }

        }
    }

    private void buttonAdd_Click(object sender, EventArgs e)
    {
        Sandwich sandwich;
        if (textBoxName.Text == "")
        {
            MessageBox.Show("Invalid input please select all values");
            return;
        }
        if (comboBoxbred.SelectedIndex == -1)
        {
            MessageBox.Show("Invalid input please select all values");
            return;
        }
        if (comboBoxcheze.SelectedIndex == -1)
        {
            MessageBox.Show("Invalid input please select all values");
            return;
        }
        if (comboBoxmeat.SelectedIndex == -1)
        {
            MessageBox.Show("Invalid input please select all values");
            return;
        }

        try
        {
            bool[] con = new bool[6];
            con[0] = checkBoxmayo.Checked;
            con[1] = checkBoxonion.Checked;
            con[2] = checkBoxMustard.Checked;
            con[3] = checkBoxtomato.Checked;
            con[4] = checkBoxletuc.Checked;
            con[5] = checkBoxpepper.Checked;


            sandwich = new Sandwich(textBoxName.Text, comboBoxbred.Text, comboBoxmeat.Text,
                comboBoxcheze.Text, con);

        }
        catch
        {
            MessageBox.Show("WRONGGGGGGGG!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! invalid input try again.");
            return;
        }

        sandwiches.Add(sandwich);
        listBoxorder.Items.Add(sandwich.PersonName);
        isDirty = true;
        //  WriteToFile(DATAFILE, sandwiches);
    }

    private void listBoxorder_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (listBoxorder.SelectedIndex == -1) return;
        int i = listBoxorder.SelectedIndex;

        textBoxName.Text = sandwiches[i].PersonName;
        comboBoxbred.Text = sandwiches[i].Bread;
        comboBoxmeat.Text = sandwiches[i].Meat;
        comboBoxcheze.Text = sandwiches[i].Cheese;

        checkBoxmayo.Checked = sandwiches[i].Con[0];
        checkBoxonion.Checked = sandwiches[i].Con[1];
        checkBoxMustard.Checked = sandwiches[i].Con[2];
        checkBoxtomato.Checked = sandwiches[i].Con[3];
        checkBoxletuc.Checked = sandwiches[i].Con[4];
        checkBoxpepper.Checked = sandwiches[i].Con[5];

    }

    private void buttonClear_Click(object sender, EventArgs e)
    {
        textBoxName.Clear();
        comboBoxbred.Text = null;
        comboBoxmeat.Text = null;
        comboBoxcheze.Text = null;
        checkBoxletuc.Checked = false;
        checkBoxmayo.Checked = false;
        checkBoxMustard.Checked = false;
        checkBoxonion.Checked = false;
        checkBoxpepper.Checked = false;
        checkBoxtomato.Checked = false;
        listBoxorder.SelectedIndex = -1;
        textBoxName.Focus();
    }

    private void listBoxorder_DoubleClick(object sender, EventArgs e)
    {
        Summary summaryDlg = new Summary();
        int i = listBoxorder.SelectedIndex;
        summaryDlg.CurrentSandwich = sandwiches[i];

        summaryDlg.ShowDialog();
    }
    public static void WriteToFile(string dataFile, List<Sandwich> stocks)
    {
        if (!File.Exists(dataFile)) return;
        StreamWriter writer = new StreamWriter(dataFile, false);
        JsonSerializer serializer = new JsonSerializer();
        serializer.Formatting = Formatting.Indented;
        serializer.Serialize(writer, stocks, typeof(List<Sandwich>));
        writer.Flush();
        writer.Close();

    }
    public static List<Sandwich> ReadFromFile(string dataFile)
    {
        StreamReader reader = new StreamReader(dataFile);
        JsonSerializer serializer = new JsonSerializer();
        var list = (List<Sandwich>)serializer.Deserialize(reader, typeof(List<Sandwich>));
        reader.Close();
        return list;
    }
    private void Form1_Load(object sender, EventArgs e)
    {
        sandwiches = ReadFromFile("Sandwiches.json");
        foreach (Sandwich stock in sandwiches)
        {
            listBoxorder.Items.Add(stock.PersonName);
        }
        listBoxorder.SelectedIndex = -1;
    }

    private void buttonsave_Click(object sender, EventArgs e)
    {
        if (isDirty == true)
        {
            WriteToFile(DATAFILE, sandwiches);
            isDirty = false;
        }
    }

    private void Form1_FormClosing(object sender, FormClosingEventArgs e)
    {
        if (isDirty == true)
        {
            DialogResult yesno = MessageBox.Show("You have unsaved changes! Do you want to save?", "Alert", MessageBoxButtons.YesNo);
            if (yesno == DialogResult.Yes)
            {
                WriteToFile(DATAFILE, sandwiches);
                isDirty = false;
            }
            
        }
        

    }
}
