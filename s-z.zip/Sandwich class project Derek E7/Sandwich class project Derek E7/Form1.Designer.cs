﻿namespace Sandwich_class_project_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            listBoxorder = new ListBox();
            textBoxName = new TextBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            comboBoxbred = new ComboBox();
            comboBoxmeat = new ComboBox();
            comboBoxcheze = new ComboBox();
            checkBoxmayo = new CheckBox();
            checkBoxonion = new CheckBox();
            checkBoxMustard = new CheckBox();
            checkBoxtomato = new CheckBox();
            checkBoxletuc = new CheckBox();
            checkBoxpepper = new CheckBox();
            buttonAdd = new Button();
            buttonClear = new Button();
            label5 = new Label();
            buttonsave = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(31, 46);
            label1.Name = "label1";
            label1.Size = new Size(37, 15);
            label1.TabIndex = 0;
            label1.Text = "naem";
            // 
            // listBoxorder
            // 
            listBoxorder.FormattingEnabled = true;
            listBoxorder.ItemHeight = 15;
            listBoxorder.Location = new Point(266, 99);
            listBoxorder.Name = "listBoxorder";
            listBoxorder.Size = new Size(206, 229);
            listBoxorder.TabIndex = 1;
            listBoxorder.SelectedIndexChanged += listBoxorder_SelectedIndexChanged;
            listBoxorder.DoubleClick += listBoxorder_DoubleClick;
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(135, 43);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(98, 23);
            textBoxName.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(31, 89);
            label2.Name = "label2";
            label2.Size = new Size(31, 15);
            label2.TabIndex = 3;
            label2.Text = "bred";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(31, 114);
            label3.Name = "label3";
            label3.Size = new Size(34, 15);
            label3.TabIndex = 5;
            label3.Text = "meet";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(31, 139);
            label4.Name = "label4";
            label4.Size = new Size(40, 15);
            label4.TabIndex = 7;
            label4.Text = "chezzr";
            // 
            // comboBoxbred
            // 
            comboBoxbred.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxbred.FormattingEnabled = true;
            comboBoxbred.Items.AddRange(new object[] { "White", "Yellow", "Blue", "Black", "Red", "Flour", "Brown" });
            comboBoxbred.Location = new Point(135, 77);
            comboBoxbred.Name = "comboBoxbred";
            comboBoxbred.Size = new Size(98, 23);
            comboBoxbred.TabIndex = 9;
            // 
            // comboBoxmeat
            // 
            comboBoxmeat.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxmeat.FormattingEnabled = true;
            comboBoxmeat.Items.AddRange(new object[] { "Cow", "Sheep", "Chicken", "Squirrel", "Raccoon", "Mouse", "Bird" });
            comboBoxmeat.Location = new Point(135, 106);
            comboBoxmeat.Name = "comboBoxmeat";
            comboBoxmeat.Size = new Size(98, 23);
            comboBoxmeat.TabIndex = 10;
            // 
            // comboBoxcheze
            // 
            comboBoxcheze.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxcheze.FormattingEnabled = true;
            comboBoxcheze.Items.AddRange(new object[] { "Cheddar", "Mozzerella", "Yozzerella", "Sezzerella", "Kezzerella", "Swiss", "Stilton" });
            comboBoxcheze.Location = new Point(135, 135);
            comboBoxcheze.Name = "comboBoxcheze";
            comboBoxcheze.Size = new Size(98, 23);
            comboBoxcheze.TabIndex = 11;
            // 
            // checkBoxmayo
            // 
            checkBoxmayo.AutoSize = true;
            checkBoxmayo.Location = new Point(31, 184);
            checkBoxmayo.Name = "checkBoxmayo";
            checkBoxmayo.Size = new Size(56, 19);
            checkBoxmayo.TabIndex = 12;
            checkBoxmayo.Text = "maeo";
            checkBoxmayo.UseVisualStyleBackColor = true;
            // 
            // checkBoxonion
            // 
            checkBoxonion.AutoSize = true;
            checkBoxonion.Location = new Point(31, 209);
            checkBoxonion.Name = "checkBoxonion";
            checkBoxonion.Size = new Size(67, 19);
            checkBoxonion.TabIndex = 13;
            checkBoxonion.Text = "onyonn";
            checkBoxonion.UseVisualStyleBackColor = true;
            // 
            // checkBoxMustard
            // 
            checkBoxMustard.AutoSize = true;
            checkBoxMustard.Location = new Point(31, 234);
            checkBoxMustard.Name = "checkBoxMustard";
            checkBoxMustard.Size = new Size(71, 19);
            checkBoxMustard.TabIndex = 14;
            checkBoxMustard.Text = "mostord";
            checkBoxMustard.UseVisualStyleBackColor = true;
            // 
            // checkBoxtomato
            // 
            checkBoxtomato.AutoSize = true;
            checkBoxtomato.Location = new Point(31, 259);
            checkBoxtomato.Name = "checkBoxtomato";
            checkBoxtomato.Size = new Size(54, 19);
            checkBoxtomato.TabIndex = 15;
            checkBoxtomato.Text = "toato";
            checkBoxtomato.UseVisualStyleBackColor = true;
            // 
            // checkBoxletuc
            // 
            checkBoxletuc.AutoSize = true;
            checkBoxletuc.Location = new Point(31, 284);
            checkBoxletuc.Name = "checkBoxletuc";
            checkBoxletuc.Size = new Size(52, 19);
            checkBoxletuc.TabIndex = 16;
            checkBoxletuc.Text = "letuc";
            checkBoxletuc.UseVisualStyleBackColor = true;
            // 
            // checkBoxpepper
            // 
            checkBoxpepper.AutoSize = true;
            checkBoxpepper.Location = new Point(31, 309);
            checkBoxpepper.Name = "checkBoxpepper";
            checkBoxpepper.Size = new Size(62, 19);
            checkBoxpepper.TabIndex = 17;
            checkBoxpepper.Text = "peeper";
            checkBoxpepper.UseVisualStyleBackColor = true;
            // 
            // buttonAdd
            // 
            buttonAdd.Location = new Point(135, 184);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(98, 69);
            buttonAdd.TabIndex = 18;
            buttonAdd.Text = "Add";
            buttonAdd.UseVisualStyleBackColor = true;
            buttonAdd.Click += buttonAdd_Click;
            // 
            // buttonClear
            // 
            buttonClear.Location = new Point(135, 259);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(98, 69);
            buttonClear.TabIndex = 19;
            buttonClear.Text = "Clear";
            buttonClear.UseVisualStyleBackColor = true;
            buttonClear.Click += buttonClear_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(325, 66);
            label5.Name = "label5";
            label5.Size = new Size(53, 15);
            label5.TabIndex = 20;
            label5.Text = "order list";
            // 
            // buttonsave
            // 
            buttonsave.Location = new Point(275, 357);
            buttonsave.Name = "buttonsave";
            buttonsave.Size = new Size(75, 23);
            buttonsave.TabIndex = 21;
            buttonsave.Text = "save";
            buttonsave.UseVisualStyleBackColor = true;
            buttonsave.Click += buttonsave_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(536, 392);
            Controls.Add(buttonsave);
            Controls.Add(label5);
            Controls.Add(buttonClear);
            Controls.Add(buttonAdd);
            Controls.Add(checkBoxpepper);
            Controls.Add(checkBoxletuc);
            Controls.Add(checkBoxtomato);
            Controls.Add(checkBoxMustard);
            Controls.Add(checkBoxonion);
            Controls.Add(checkBoxmayo);
            Controls.Add(comboBoxcheze);
            Controls.Add(comboBoxmeat);
            Controls.Add(comboBoxbred);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(textBoxName);
            Controls.Add(listBoxorder);
            Controls.Add(label1);
            Name = "Form1";
            Text = "S\u007fa\u007fn\u007fd\u007fw\u007fi\u007fc\u007fh";
            FormClosing += Form1_FormClosing;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private ListBox listBoxorder;
        private TextBox textBoxName;
        private Label label2;
        private Label label3;
        private Label label4;
        private ComboBox comboBoxbred;
        private ComboBox comboBoxmeat;
        private ComboBox comboBoxcheze;
        private CheckBox checkBoxmayo;
        private CheckBox checkBoxonion;
        private CheckBox checkBoxMustard;
        private CheckBox checkBoxtomato;
        private CheckBox checkBoxletuc;
        private CheckBox checkBoxpepper;
        private Button buttonAdd;
        private Button buttonClear;
        private Label label5;
        private Button buttonsave;
    }
}
