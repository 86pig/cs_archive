﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Sandwich_class_project_Derek_E7
{
    public class Sandwich
    {
        public Sandwich()
        {
            PersonName = string.Empty;
            Bread = string.Empty;
            Meat = string.Empty;
            Cheese = string.Empty;

        }

        public Sandwich(string n, string b, string m, string c, bool[] con)
        {
            PersonName = n;
            Bread = b;
            Meat = m;
            Cheese = c;
            Con = con;
        }
        public string PersonName { get; set; }
        public string Bread { get; set; }
        public string Meat { get; set; }
        public string Cheese { get; set; }
        public bool[] Con { get; set; }
      //  public string GetAchoo
        //{
        //    get
        //    {
        //        string condi = "";
        //        if (Con[0]) condi += "Mayo \n";
        //        if (Con[1]) condi += "Onion \n";
        //        if (Con[2]) condi += "Mustard \n";
        //        if (Con[3]) condi += "Tomato \n";
        //        if (Con[4]) condi += "Lettuce \n";
        //        if (Con[5]) condi += "Peppers \n";

        //        string sand =
        //                "Name: " + PersonName + "\n" +
        //                "Bread: " + Bread + "\n" +
        //                "Meat: " + Meat + "\n" +
        //                "Cheese: " + Cheese + "\n" +
        //                "Condiments: " + condi;
        //        return sand;
        //    }
        //}

        public override string ToString()
        {
            string condi = "";
            if (Con[0]) condi += "Mayo \n";
            if (Con[1]) condi += "Onion \n";
            if (Con[2]) condi += "Mustard \n";
            if (Con[3]) condi += "Tomato \n";
            if (Con[4]) condi += "Lettuce \n";
            if (Con[5]) condi += "Peppers \n";

            string sand = 
                    "Name: " + PersonName + "\n" +
                    "Bread: " + Bread + "\n" +
                    "Meat: " + Meat + "\n" +
                    "Cheese: " + Cheese + "\n" +
                    "Condiments: \n" + condi;
            return sand;
        }



    }
}
