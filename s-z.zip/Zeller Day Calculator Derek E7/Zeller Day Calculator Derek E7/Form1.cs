using System.Diagnostics.Eventing.Reader;
using System.Runtime.InteropServices;

namespace Zeller_Day_Calculator_Derek_E7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }



        private int GetYear(int y, int m)
        {
            if (m == 1 || m == 2)
                return y - 1;

            else return y;
        }

        private int ConvertMonth(int f)
        {
            if (f == 1 || f == 2)
            {
                return f + 10;
            }
            else return f - 2;
            
        }

        private int FirstTwoYear(int t)
        {
            return t / 100;
        }

        private int LastTwoYear(int l)
        {
            return l % 100;
        }

        private int GetDayOTW(int k, int m, int D, int C)
        {
            int F = k + ((13 * m - 1) / 5) + D + (D / 4) + (C / 4) - 2 * C;
            if (F < 0)
            {
                return 7 - Math.Abs(F) % 7;
            }
            else
            {
                return F % 7;
            }

        }

        private string GetString(int h)
        {
            //string daystring = "";
            if (h == 0) return "Sunday";
            else if (h == 1) return "Monday";
            else if (h == 2) return "Tuesday";
            else if (h == 3) return "Wednesday";
            else if (h == 4) return "Thursday";
            else if (h == 5) return "Friday";
            else if (h == 6) return "Saturday";
            else return "ERROR";


        }

        private void buttonCalcualte_Click(object sender, EventArgs e)
        {
            int month = int.Parse(textBoxMonth.Text);
            int year = int.Parse(textBoxYear.Text);
            int day = int.Parse(textBoxDay.Text);

            int yar = GetYear(year, month);
            int mont = ConvertMonth(month);
            int first2yar = FirstTwoYear(year);
            int last2yar = LastTwoYear(year);
            int DOTW = GetDayOTW(day, mont, last2yar, first2yar);
            string SDOTW = GetString(DOTW);


            labelTheDAY.Text = SDOTW.ToString();
        }
    }
}
