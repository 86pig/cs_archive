﻿namespace Zeller_Day_Calculator_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBoxMonth = new TextBox();
            textBoxDay = new TextBox();
            label2 = new Label();
            textBoxYear = new TextBox();
            label3 = new Label();
            labelTheDAY = new Label();
            buttonCalcualte = new Button();
            buttonExit = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F);
            label1.Location = new Point(80, 73);
            label1.Name = "label1";
            label1.Size = new Size(51, 19);
            label1.TabIndex = 0;
            label1.Text = "Month";
            // 
            // textBoxMonth
            // 
            textBoxMonth.Location = new Point(167, 72);
            textBoxMonth.Name = "textBoxMonth";
            textBoxMonth.Size = new Size(100, 23);
            textBoxMonth.TabIndex = 1;
            // 
            // textBoxDay
            // 
            textBoxDay.Location = new Point(167, 101);
            textBoxDay.Name = "textBoxDay";
            textBoxDay.Size = new Size(100, 23);
            textBoxDay.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F);
            label2.Location = new Point(80, 102);
            label2.Name = "label2";
            label2.Size = new Size(33, 19);
            label2.TabIndex = 2;
            label2.Text = "Day";
            // 
            // textBoxYear
            // 
            textBoxYear.Location = new Point(167, 130);
            textBoxYear.Name = "textBoxYear";
            textBoxYear.Size = new Size(100, 23);
            textBoxYear.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10F);
            label3.Location = new Point(80, 131);
            label3.Name = "label3";
            label3.Size = new Size(59, 19);
            label3.TabIndex = 4;
            label3.Text = "YYYYear";
            // 
            // labelTheDAY
            // 
            labelTheDAY.AutoSize = true;
            labelTheDAY.Font = new Font("Segoe UI", 20F);
            labelTheDAY.Location = new Point(109, 311);
            labelTheDAY.Name = "labelTheDAY";
            labelTheDAY.Size = new Size(71, 37);
            labelTheDAY.TabIndex = 6;
            labelTheDAY.Text = "~~~";
            // 
            // buttonCalcualte
            // 
            buttonCalcualte.Font = new Font("Segoe UI", 59F);
            buttonCalcualte.Location = new Point(302, 73);
            buttonCalcualte.Name = "buttonCalcualte";
            buttonCalcualte.Size = new Size(458, 282);
            buttonCalcualte.TabIndex = 7;
            buttonCalcualte.Text = "Calculate";
            buttonCalcualte.UseVisualStyleBackColor = true;
            buttonCalcualte.Click += buttonCalcualte_Click;
            // 
            // buttonExit
            // 
            buttonExit.Location = new Point(514, 379);
            buttonExit.Name = "buttonExit";
            buttonExit.Size = new Size(102, 56);
            buttonExit.TabIndex = 8;
            buttonExit.Text = "exit";
            buttonExit.UseVisualStyleBackColor = true;
            buttonExit.Click += buttonExit_Click;
            // 
            // Form1
            // 
            AcceptButton = buttonCalcualte;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = buttonExit;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonExit);
            Controls.Add(buttonCalcualte);
            Controls.Add(labelTheDAY);
            Controls.Add(textBoxYear);
            Controls.Add(label3);
            Controls.Add(textBoxDay);
            Controls.Add(label2);
            Controls.Add(textBoxMonth);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Zeller Day of Week Calculator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBoxMonth;
        private TextBox textBoxDay;
        private Label label2;
        private TextBox textBoxYear;
        private Label label3;
        private Label labelTheDAY;
        private Button buttonCalcualte;
        private Button buttonExit;
    }
}
