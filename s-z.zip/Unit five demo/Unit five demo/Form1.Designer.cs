﻿namespace Unit_five_demo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            openToolStripMenuItem = new ToolStripMenuItem();
            saveToolStripMenuItem = new ToolStripMenuItem();
            saveasToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem1 = new ToolStripSeparator();
            exitToolStripMenuItem = new ToolStripMenuItem();
            editToolStripMenuItem = new ToolStripMenuItem();
            fontDialougeToolStripMenuItem = new ToolStripMenuItem();
            colourDialougueToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem2 = new ToolStripSeparator();
            isTroubleToolStripMenuItem = new ToolStripMenuItem();
            calcPythagToolStripMenuItem = new ToolStripMenuItem();
            calcGradeToolStripMenuItem = new ToolStripMenuItem();
            colorDialog1 = new ColorDialog();
            fontDialog1 = new FontDialog();
            label1 = new Label();
            openFileDialog1 = new OpenFileDialog();
            label2 = new Label();
            label3 = new Label();
            saveFileDialog1 = new SaveFileDialog();
            label4 = new Label();
            textBoxscore = new TextBox();
            label5 = new Label();
            label6 = new Label();
            checkBox1 = new CheckBox();
            checkBox2 = new CheckBox();
            label7 = new Label();
            label8 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label9 = new Label();
            textBox3 = new TextBox();
            label10 = new Label();
            textBox4 = new TextBox();
            label11 = new Label();
            checkBox3 = new CheckBox();
            label12 = new Label();
            squirrelelPlayingToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem, editToolStripMenuItem, calcGradeToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { openToolStripMenuItem, saveToolStripMenuItem, saveasToolStripMenuItem, toolStripMenuItem1, exitToolStripMenuItem });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(35, 20);
            fileToolStripMenuItem.Text = "&file";
            // 
            // openToolStripMenuItem
            // 
            openToolStripMenuItem.Name = "openToolStripMenuItem";
            openToolStripMenuItem.Size = new Size(111, 22);
            openToolStripMenuItem.Text = "&open";
            openToolStripMenuItem.Click += openToolStripMenuItem_Click;
            // 
            // saveToolStripMenuItem
            // 
            saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            saveToolStripMenuItem.Size = new Size(111, 22);
            saveToolStripMenuItem.Text = "&save";
            saveToolStripMenuItem.Click += saveToolStripMenuItem_Click;
            // 
            // saveasToolStripMenuItem
            // 
            saveasToolStripMenuItem.Name = "saveasToolStripMenuItem";
            saveasToolStripMenuItem.Size = new Size(111, 22);
            saveasToolStripMenuItem.Text = "save &as";
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(108, 6);
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(111, 22);
            exitToolStripMenuItem.Text = "e&xit";
            exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;
            // 
            // editToolStripMenuItem
            // 
            editToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { fontDialougeToolStripMenuItem, colourDialougueToolStripMenuItem, toolStripMenuItem2, isTroubleToolStripMenuItem, calcPythagToolStripMenuItem, squirrelelPlayingToolStripMenuItem });
            editToolStripMenuItem.Name = "editToolStripMenuItem";
            editToolStripMenuItem.Size = new Size(39, 20);
            editToolStripMenuItem.Text = "&edit";
            // 
            // fontDialougeToolStripMenuItem
            // 
            fontDialougeToolStripMenuItem.Name = "fontDialougeToolStripMenuItem";
            fontDialougeToolStripMenuItem.Size = new Size(180, 22);
            fontDialougeToolStripMenuItem.Text = "font dialouge...";
            fontDialougeToolStripMenuItem.Click += fontDialougeToolStripMenuItem_Click;
            // 
            // colourDialougueToolStripMenuItem
            // 
            colourDialougueToolStripMenuItem.Name = "colourDialougueToolStripMenuItem";
            colourDialougueToolStripMenuItem.Size = new Size(180, 22);
            colourDialougueToolStripMenuItem.Text = "colour dialougue...";
            colourDialougueToolStripMenuItem.Click += colourDialougueToolStripMenuItem_Click;
            // 
            // toolStripMenuItem2
            // 
            toolStripMenuItem2.Name = "toolStripMenuItem2";
            toolStripMenuItem2.Size = new Size(177, 6);
            // 
            // isTroubleToolStripMenuItem
            // 
            isTroubleToolStripMenuItem.Name = "isTroubleToolStripMenuItem";
            isTroubleToolStripMenuItem.Size = new Size(180, 22);
            isTroubleToolStripMenuItem.Text = "is trouble";
            isTroubleToolStripMenuItem.Click += isTroubleToolStripMenuItem_Click;
            // 
            // calcPythagToolStripMenuItem
            // 
            calcPythagToolStripMenuItem.Name = "calcPythagToolStripMenuItem";
            calcPythagToolStripMenuItem.Size = new Size(180, 22);
            calcPythagToolStripMenuItem.Text = "calc pythag";
            calcPythagToolStripMenuItem.Click += calcPythagToolStripMenuItem_Click;
            // 
            // calcGradeToolStripMenuItem
            // 
            calcGradeToolStripMenuItem.Name = "calcGradeToolStripMenuItem";
            calcGradeToolStripMenuItem.Size = new Size(73, 20);
            calcGradeToolStripMenuItem.Text = "calc grade";
            calcGradeToolStripMenuItem.Click += calcGradeToolStripMenuItem_Click;
            // 
            // fontDialog1
            // 
            fontDialog1.Apply += fontDialog1_Apply;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15F);
            label1.Location = new Point(324, 220);
            label1.Name = "label1";
            label1.Size = new Size(37, 28);
            label1.TabIndex = 1;
            label1.Text = "<3";
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            openFileDialog1.FileOk += openFileDialog1_FileOk;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(314, 351);
            label2.Name = "label2";
            label2.Size = new Size(57, 15);
            label2.TabIndex = 2;
            label2.Text = "pankaaak";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(436, 391);
            label3.Name = "label3";
            label3.Size = new Size(35, 15);
            label3.TabIndex = 3;
            label3.Text = "joose";
            // 
            // saveFileDialog1
            // 
            saveFileDialog1.FileOk += saveFileDialog1_FileOk;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(500, 190);
            label4.Name = "label4";
            label4.Size = new Size(35, 15);
            label4.TabIndex = 4;
            label4.Text = "score";
            // 
            // textBoxscore
            // 
            textBoxscore.Location = new Point(561, 187);
            textBoxscore.Name = "textBoxscore";
            textBoxscore.Size = new Size(100, 23);
            textBoxscore.TabIndex = 5;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(500, 245);
            label5.Name = "label5";
            label5.Size = new Size(37, 15);
            label5.TabIndex = 6;
            label5.Text = "grade";
            label5.TextAlign = ContentAlignment.TopCenter;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(574, 251);
            label6.Name = "label6";
            label6.Size = new Size(12, 15);
            label6.TabIndex = 7;
            label6.Text = "z";
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(60, 251);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(74, 19);
            checkBox1.TabIndex = 8;
            checkBox1.Text = "smiling 1";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(60, 276);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(74, 19);
            checkBox2.TabIndex = 9;
            checkBox2.Text = "smiling 2";
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(60, 318);
            label7.Name = "label7";
            label7.Size = new Size(32, 15);
            label7.TabIndex = 10;
            label7.Text = "trubl";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(274, 70);
            label8.Name = "label8";
            label8.Size = new Size(39, 15);
            label8.TabIndex = 11;
            label8.Text = "side A";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(348, 70);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 12;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(348, 99);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(100, 23);
            textBox2.TabIndex = 14;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(274, 99);
            label9.Name = "label9";
            label9.Size = new Size(38, 15);
            label9.TabIndex = 13;
            label9.Text = "side B";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(348, 128);
            textBox3.Name = "textBox3";
            textBox3.ReadOnly = true;
            textBox3.Size = new Size(100, 23);
            textBox3.TabIndex = 16;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(274, 128);
            label10.Name = "label10";
            label10.Size = new Size(39, 15);
            label10.TabIndex = 15;
            label10.Text = "side C";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(635, 46);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(100, 23);
            textBox4.TabIndex = 18;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(561, 46);
            label11.Name = "label11";
            label11.Size = new Size(35, 15);
            label11.TabIndex = 17;
            label11.Text = "temp";
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Location = new Point(574, 84);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(81, 19);
            checkBox3.TabIndex = 19;
            checkBox3.Text = "is summer";
            checkBox3.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(661, 102);
            label12.Name = "label12";
            label12.Size = new Size(53, 15);
            label12.TabIndex = 20;
            label12.Text = "squiurrel";
            // 
            // squirrelelPlayingToolStripMenuItem
            // 
            squirrelelPlayingToolStripMenuItem.Name = "squirrelelPlayingToolStripMenuItem";
            squirrelelPlayingToolStripMenuItem.Size = new Size(180, 22);
            squirrelelPlayingToolStripMenuItem.Text = "squirrelel playing";
            squirrelelPlayingToolStripMenuItem.Click += squirrelelPlayingToolStripMenuItem_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label12);
            Controls.Add(checkBox3);
            Controls.Add(textBox4);
            Controls.Add(label11);
            Controls.Add(textBox3);
            Controls.Add(label10);
            Controls.Add(textBox2);
            Controls.Add(label9);
            Controls.Add(textBox1);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(checkBox2);
            Controls.Add(checkBox1);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(textBoxscore);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "demoe";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem openToolStripMenuItem;
        private ToolStripMenuItem saveToolStripMenuItem;
        private ToolStripMenuItem saveasToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem1;
        private ToolStripMenuItem exitToolStripMenuItem;
        private ToolStripMenuItem editToolStripMenuItem;
        private ToolStripMenuItem fontDialougeToolStripMenuItem;
        private ToolStripMenuItem colourDialougueToolStripMenuItem;
        private ColorDialog colorDialog1;
        private FontDialog fontDialog1;
        private Label label1;
        private OpenFileDialog openFileDialog1;
        private Label label2;
        private Label label3;
        private SaveFileDialog saveFileDialog1;
        private Label label4;
        private TextBox textBoxscore;
        private Label label5;
        private Label label6;
        private ToolStripMenuItem calcGradeToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem2;
        private ToolStripMenuItem isTroubleToolStripMenuItem;
        private CheckBox checkBox1;
        private CheckBox checkBox2;
        private Label label7;
        private Label label8;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label9;
        private TextBox textBox3;
        private Label label10;
        private ToolStripMenuItem calcPythagToolStripMenuItem;
        private ToolStripMenuItem squirrelelPlayingToolStripMenuItem;
        private TextBox textBox4;
        private Label label11;
        private CheckBox checkBox3;
        private Label label12;
    }
}
