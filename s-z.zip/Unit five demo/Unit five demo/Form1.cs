using System.Diagnostics.Eventing.Reader;

namespace Unit_five_demo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //snaasofuaoiwf
        //use private, or public,              retern type: void, bool, int, double, string, 
        //need a method name, (), can hve perams, myust be sperated by a ,   body '{}',  keyword return w/ datatype if not 'void'


        private void Helliwarld()
        {
            MessageBox.Show("hai warerld!!");
        }




        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void fontDialog1_Apply(object sender, EventArgs e)
        {

        }

        private void fontDialougeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //call dialoughes
            fontDialog1.ShowDialog();
            Font currentFont = fontDialog1.Font;
            label1.Font = currentFont;

        }

        private void colourDialougueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            Color currentColor = colorDialog1.Color;
            label1.ForeColor = currentColor;

            label2.BackColor = currentColor;
            label3.ForeColor = currentColor;
        }

        private void openFileDialog1_FileOk(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            string filename = openFileDialog1.FileName;
            label2.Text = filename;
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //call
            Helliwarld();


        }

        private void saveFileDialog1_FileOk(object sender, System.ComponentModel.CancelEventArgs e)
        {
            saveFileDialog1.ShowDialog();
            string saveFilename = saveFileDialog1.FileName;
            label3.Text = saveFilename;
        }

        private string Calccgrad(int s)
        {
            string grade = "";

            if (s >= 90) grade = "A";
            else if (s >= 80) grade = "B";
            else if (s >= 70) grade = "C";
            else if (s >= 60) grade = "D";
            else grade = "E";

            return grade;
        }
        private void calcGradeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //get score from ui 
            int scoreer = int.Parse(textBoxscore.Text);
            //fidng rade
            string ccg = Calccgrad(scoreer);

            label5.Text = ccg;


        }

        private bool truble(bool sSmiling, bool aSmiling)
        {
            return sSmiling == aSmiling;
        }

        private void isTroubleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool donnellyhastr = truble(checkBox1.Checked, checkBox2.Checked);
            if (donnellyhastr)
            {
                label7.Text = "Donnelly has trouble";
            }

            else label7.Text = "Donnelly is good";
        }

        private double pytahgcalcmethodzz(double aa, double bb)
        {
            double c = Math.Sqrt(Math.Pow(aa, 2) + Math.Pow(bb, 2));
            return c;
        }


        private void calcPythagToolStripMenuItem_Click(object sender, EventArgs e)
        {
            double a, b, c;

            a = double.Parse(textBox1.Text);
            b = double.Parse(textBox2.Text);

            c = pytahgcalcmethodzz(a, b);
            textBox3.Text = c.ToString("N2");


        }

        
        
        private bool squirlplaying(int t, bool issummer)
        {
            if (issummer)
            {
                if (t >= 60 && t <= 100) return true;
                else return false;

            }
            else
            {
                if (t >= 60 && t < 90) return true;
                else return false;
            }
        }

        private void squirrelelPlayingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int temp = int.Parse(textBox4.Text);

            if (squirlplaying(temp, checkBox3.Checked))
            {
                label12.Text = "squirrels asre playing.";
            }
            else label12.Text = "squirls not playing";

        }
    }
}
