﻿namespace Ticket_Sales_Quiz_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            summaryToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem1 = new ToolStripSeparator();
            exitToolStripMenuItem = new ToolStripMenuItem();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            counterAdult = new NumericUpDown();
            counterVisitngnonasb = new NumericUpDown();
            counterk8 = new NumericUpDown();
            buttonCheckout = new Button();
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)counterAdult).BeginInit();
            ((System.ComponentModel.ISupportInitialize)counterVisitngnonasb).BeginInit();
            ((System.ComponentModel.ISupportInitialize)counterk8).BeginInit();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(382, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { summaryToolStripMenuItem, toolStripMenuItem1, exitToolStripMenuItem });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(37, 20);
            fileToolStripMenuItem.Text = "&File";
            // 
            // summaryToolStripMenuItem
            // 
            summaryToolStripMenuItem.Name = "summaryToolStripMenuItem";
            summaryToolStripMenuItem.Size = new Size(180, 22);
            summaryToolStripMenuItem.Text = "&Summary";
            summaryToolStripMenuItem.Click += summaryToolStripMenuItem_Click;
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(177, 6);
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(180, 22);
            exitToolStripMenuItem.Text = "E&xit";
            exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F);
            label1.Location = new Point(12, 55);
            label1.Name = "label1";
            label1.Size = new Size(205, 21);
            label1.TabIndex = 1;
            label1.Text = "Adult/Non-ASB student - $9";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F);
            label2.Location = new Point(12, 84);
            label2.Name = "label2";
            label2.Size = new Size(184, 21);
            label2.TabIndex = 2;
            label2.Text = "Visiting/ASB student - $5";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F);
            label3.Location = new Point(12, 113);
            label3.Name = "label3";
            label3.Size = new Size(122, 21);
            label3.TabIndex = 3;
            label3.Text = "K-8 student - $5";
            // 
            // counterAdult
            // 
            counterAdult.Location = new Point(243, 53);
            counterAdult.Name = "counterAdult";
            counterAdult.Size = new Size(120, 23);
            counterAdult.TabIndex = 4;
            // 
            // counterVisitngnonasb
            // 
            counterVisitngnonasb.Location = new Point(243, 82);
            counterVisitngnonasb.Name = "counterVisitngnonasb";
            counterVisitngnonasb.Size = new Size(120, 23);
            counterVisitngnonasb.TabIndex = 5;
            // 
            // counterk8
            // 
            counterk8.Location = new Point(243, 111);
            counterk8.Name = "counterk8";
            counterk8.Size = new Size(120, 23);
            counterk8.TabIndex = 6;
            // 
            // buttonCheckout
            // 
            buttonCheckout.Location = new Point(12, 156);
            buttonCheckout.Name = "buttonCheckout";
            buttonCheckout.Size = new Size(351, 96);
            buttonCheckout.TabIndex = 7;
            buttonCheckout.Text = "Checkout";
            buttonCheckout.UseVisualStyleBackColor = true;
            buttonCheckout.Click += buttonCheckout_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(382, 272);
            Controls.Add(buttonCheckout);
            Controls.Add(counterk8);
            Controls.Add(counterVisitngnonasb);
            Controls.Add(counterAdult);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Ticket Sales";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)counterAdult).EndInit();
            ((System.ComponentModel.ISupportInitialize)counterVisitngnonasb).EndInit();
            ((System.ComponentModel.ISupportInitialize)counterk8).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem summaryToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem1;
        private ToolStripMenuItem exitToolStripMenuItem;
        private Label label1;
        private Label label2;
        private Label label3;
        private NumericUpDown counterAdult;
        private NumericUpDown counterVisitngnonasb;
        private NumericUpDown counterk8;
        private Button buttonCheckout;
    }
}
