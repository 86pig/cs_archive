﻿namespace Ticket_Sales_Quiz_Derek_E7
{
    partial class Checkout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            labelAdult = new Label();
            labelVisiting = new Label();
            labelK8 = new Label();
            labelTotal = new Label();
            buttonOK = new Button();
            timerThingy = new System.Windows.Forms.Timer(components);
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F);
            label1.Location = new Point(32, 32);
            label1.Name = "label1";
            label1.Size = new Size(42, 19);
            label1.TabIndex = 0;
            label1.Text = "Adult";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F);
            label2.Location = new Point(32, 62);
            label2.Name = "label2";
            label2.Size = new Size(54, 19);
            label2.TabIndex = 1;
            label2.Text = "Visiting";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10F);
            label3.Location = new Point(32, 92);
            label3.Name = "label3";
            label3.Size = new Size(31, 19);
            label3.TabIndex = 2;
            label3.Text = "K-8";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10F);
            label4.Location = new Point(32, 150);
            label4.Name = "label4";
            label4.Size = new Size(38, 19);
            label4.TabIndex = 3;
            label4.Text = "Total";
            // 
            // labelAdult
            // 
            labelAdult.AutoSize = true;
            labelAdult.Font = new Font("Segoe UI", 10F);
            labelAdult.Location = new Point(130, 32);
            labelAdult.Name = "labelAdult";
            labelAdult.Size = new Size(45, 19);
            labelAdult.TabIndex = 4;
            labelAdult.Text = "label5";
            // 
            // labelVisiting
            // 
            labelVisiting.AutoSize = true;
            labelVisiting.Font = new Font("Segoe UI", 10F);
            labelVisiting.Location = new Point(130, 62);
            labelVisiting.Name = "labelVisiting";
            labelVisiting.Size = new Size(45, 19);
            labelVisiting.TabIndex = 5;
            labelVisiting.Text = "label6";
            // 
            // labelK8
            // 
            labelK8.AutoSize = true;
            labelK8.Font = new Font("Segoe UI", 10F);
            labelK8.Location = new Point(130, 92);
            labelK8.Name = "labelK8";
            labelK8.Size = new Size(45, 19);
            labelK8.TabIndex = 6;
            labelK8.Text = "label7";
            // 
            // labelTotal
            // 
            labelTotal.AutoSize = true;
            labelTotal.Font = new Font("Segoe UI", 10F);
            labelTotal.Location = new Point(130, 150);
            labelTotal.Name = "labelTotal";
            labelTotal.Size = new Size(45, 19);
            labelTotal.TabIndex = 7;
            labelTotal.Text = "label8";
            // 
            // buttonOK
            // 
            buttonOK.Location = new Point(32, 194);
            buttonOK.Name = "buttonOK";
            buttonOK.Size = new Size(143, 53);
            buttonOK.TabIndex = 8;
            buttonOK.Text = "OK";
            buttonOK.UseVisualStyleBackColor = true;
            buttonOK.Click += buttonOK_Click;
            // 
            // timerThingy
            // 
            timerThingy.Enabled = true;
            timerThingy.Interval = 2;
            timerThingy.Tick += timerThingy_Tick;
            // 
            // Checkout
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(214, 278);
            Controls.Add(buttonOK);
            Controls.Add(labelTotal);
            Controls.Add(labelK8);
            Controls.Add(labelVisiting);
            Controls.Add(labelAdult);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "Checkout";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Checkout";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label labelAdult;
        private Label labelVisiting;
        private Label labelK8;
        private Label labelTotal;
        private Button buttonOK;
        private System.Windows.Forms.Timer timerThingy;
    }
}