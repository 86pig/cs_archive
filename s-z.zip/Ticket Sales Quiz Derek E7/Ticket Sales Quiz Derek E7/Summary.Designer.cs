﻿namespace Ticket_Sales_Quiz_Derek_E7
{
    partial class Summary
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            textBoxAdultSales = new TextBox();
            textBoxAdultTicket = new TextBox();
            textBoxVisitingTicket = new TextBox();
            textBoxVisitingSales = new TextBox();
            label2 = new Label();
            textBoxK8Tickets = new TextBox();
            textBoxK8Sales = new TextBox();
            label3 = new Label();
            textBoxTotalTickets = new TextBox();
            textBoxTotalSales = new TextBox();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            buttonoka = new Button();
            timerrandomomer = new System.Windows.Forms.Timer(components);
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F);
            label1.Location = new Point(28, 55);
            label1.Name = "label1";
            label1.Size = new Size(48, 19);
            label1.TabIndex = 0;
            label1.Text = "Adults";
            // 
            // textBoxAdultSales
            // 
            textBoxAdultSales.Location = new Point(272, 55);
            textBoxAdultSales.Name = "textBoxAdultSales";
            textBoxAdultSales.ReadOnly = true;
            textBoxAdultSales.Size = new Size(100, 23);
            textBoxAdultSales.TabIndex = 1;
            // 
            // textBoxAdultTicket
            // 
            textBoxAdultTicket.Location = new Point(124, 55);
            textBoxAdultTicket.Name = "textBoxAdultTicket";
            textBoxAdultTicket.ReadOnly = true;
            textBoxAdultTicket.Size = new Size(100, 23);
            textBoxAdultTicket.TabIndex = 2;
            // 
            // textBoxVisitingTicket
            // 
            textBoxVisitingTicket.Location = new Point(124, 84);
            textBoxVisitingTicket.Name = "textBoxVisitingTicket";
            textBoxVisitingTicket.ReadOnly = true;
            textBoxVisitingTicket.Size = new Size(100, 23);
            textBoxVisitingTicket.TabIndex = 5;
            // 
            // textBoxVisitingSales
            // 
            textBoxVisitingSales.Location = new Point(272, 84);
            textBoxVisitingSales.Name = "textBoxVisitingSales";
            textBoxVisitingSales.ReadOnly = true;
            textBoxVisitingSales.Size = new Size(100, 23);
            textBoxVisitingSales.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F);
            label2.Location = new Point(28, 84);
            label2.Name = "label2";
            label2.Size = new Size(54, 19);
            label2.TabIndex = 3;
            label2.Text = "Visiting";
            // 
            // textBoxK8Tickets
            // 
            textBoxK8Tickets.Location = new Point(124, 113);
            textBoxK8Tickets.Name = "textBoxK8Tickets";
            textBoxK8Tickets.ReadOnly = true;
            textBoxK8Tickets.Size = new Size(100, 23);
            textBoxK8Tickets.TabIndex = 8;
            // 
            // textBoxK8Sales
            // 
            textBoxK8Sales.Location = new Point(272, 113);
            textBoxK8Sales.Name = "textBoxK8Sales";
            textBoxK8Sales.ReadOnly = true;
            textBoxK8Sales.Size = new Size(100, 23);
            textBoxK8Sales.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10F);
            label3.Location = new Point(28, 113);
            label3.Name = "label3";
            label3.Size = new Size(31, 19);
            label3.TabIndex = 6;
            label3.Text = "K-8";
            // 
            // textBoxTotalTickets
            // 
            textBoxTotalTickets.Location = new Point(124, 142);
            textBoxTotalTickets.Name = "textBoxTotalTickets";
            textBoxTotalTickets.ReadOnly = true;
            textBoxTotalTickets.Size = new Size(100, 23);
            textBoxTotalTickets.TabIndex = 11;
            // 
            // textBoxTotalSales
            // 
            textBoxTotalSales.Location = new Point(272, 142);
            textBoxTotalSales.Name = "textBoxTotalSales";
            textBoxTotalSales.ReadOnly = true;
            textBoxTotalSales.Size = new Size(100, 23);
            textBoxTotalSales.TabIndex = 10;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10F);
            label4.Location = new Point(28, 142);
            label4.Name = "label4";
            label4.Size = new Size(44, 19);
            label4.TabIndex = 9;
            label4.Text = "Totals";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10F);
            label5.Location = new Point(134, 22);
            label5.Name = "label5";
            label5.Size = new Size(81, 19);
            label5.TabIndex = 12;
            label5.Text = "Total tickets";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 10F);
            label6.Location = new Point(286, 22);
            label6.Name = "label6";
            label6.Size = new Size(71, 19);
            label6.TabIndex = 13;
            label6.Text = "Total sales";
            // 
            // buttonoka
            // 
            buttonoka.Font = new Font("Segoe UI", 19F);
            buttonoka.Location = new Point(28, 192);
            buttonoka.Name = "buttonoka";
            buttonoka.Size = new Size(344, 235);
            buttonoka.TabIndex = 14;
            buttonoka.Text = "OKAY!";
            buttonoka.UseVisualStyleBackColor = true;
            buttonoka.Click += button1_Click;
            // 
            // timerrandomomer
            // 
            timerrandomomer.Enabled = true;
            timerrandomomer.Interval = 2;
            timerrandomomer.Tick += timerrandomomer_Tick;
            // 
            // Summary
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(398, 450);
            Controls.Add(buttonoka);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(textBoxTotalTickets);
            Controls.Add(textBoxTotalSales);
            Controls.Add(label4);
            Controls.Add(textBoxK8Tickets);
            Controls.Add(textBoxK8Sales);
            Controls.Add(label3);
            Controls.Add(textBoxVisitingTicket);
            Controls.Add(textBoxVisitingSales);
            Controls.Add(label2);
            Controls.Add(textBoxAdultTicket);
            Controls.Add(textBoxAdultSales);
            Controls.Add(label1);
            Name = "Summary";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Summary";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBoxAdultSales;
        private TextBox textBoxAdultTicket;
        private TextBox textBoxVisitingTicket;
        private TextBox textBoxVisitingSales;
        private Label label2;
        private TextBox textBoxK8Tickets;
        private TextBox textBoxK8Sales;
        private Label label3;
        private TextBox textBoxTotalTickets;
        private TextBox textBoxTotalSales;
        private Label label4;
        private Label label5;
        private Label label6;
        private Button buttonoka;
        private System.Windows.Forms.Timer timerrandomomer;
    }
}