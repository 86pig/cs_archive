using System.Diagnostics.CodeAnalysis;

namespace Ticket_Sales_Quiz_Derek_E7
{
    public partial class Form1 : Form
    {
        //define const vars and other random important things
        const double ADNASB = 9.00;
        const double ASBK = 5.00;

        double numAdult = 0;
        double numVisiting = 0;
        double numk8 = 0;

        double adultPrice = 0;
        double visitingPrice = 0;
        double k8Price = 0;

        double totalPrice = 0;


        public Form1()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //code the exit toolstip button
            this.Close();
        }

        private void buttonCheckout_Click(object sender, EventArgs e)
        {
            //get info from ui and do calculations
            double adult = (double)counterAdult.Value;
            double visitingnasb = (double)counterVisitngnonasb.Value;
            double k8 = (double)counterk8.Value;

            double adultprice = adult * ADNASB;
            double visitingnasbprice = visitingnasb * ASBK;
            double k8price = k8 * ASBK;

            double totalofthis = adultprice + visitingnasbprice + k8price;

            //add to vars
            totalPrice += totalofthis;
            adultPrice += adultprice;
            visitingPrice += visitingnasbprice;
            k8Price += k8price;

            numAdult += adult;
            numVisiting += visitingnasb;
            numk8 += k8;

            //make messagebox showing number of people attending and total price for that round.
            MessageBox.Show("Adults: " + adult + "\n" + "Visiting: " + visitingnasb + "\n" + "K-8: " + k8 + "\n" + "----------" + "\n" + totalofthis.ToString("C"));


            //yes i am dumb and i did not remember the directions. sorry,.. advert your eyes.
            /*
            Checkout checkoutDlg = new Checkout();

            checkoutDlg.TotalnumofAdults = numAdult;
            checkoutDlg.TotalnumofVisiting = numVisiting;
            checkoutDlg.TotalnumofK8 = numk8;
            checkoutDlg.TotalPriceCheckouted = totalPrice;

            checkoutDlg.ShowDialog();

            */

            //reset ui
            counterAdult.Value = 0;
            counterVisitngnonasb.Value = 0;
            counterk8.Value = 0;

        }

        private void summaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Summary summaryDlg = new Summary();

            summaryDlg.TotalnumofVisiting = numVisiting;
            summaryDlg.TotalnumofAdults = numAdult;
            summaryDlg.TotalnumofK8 = numk8;
            summaryDlg.AdultPrice = adultPrice;
            summaryDlg.VisitorPrice = visitingPrice;
            summaryDlg.K8Price = k8Price;

            summaryDlg.ShowDialog();
        }
    }
}
