﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ticket_Sales_Quiz_Derek_E7
{
    public partial class Checkout : Form
    {
        //giant thing var global 
        public double TotalnumofAdults { get; set; }
        public double TotalnumofVisiting { get; set; }
        public double TotalnumofK8 { get; set; }
        public double TotalPriceCheckouted { get; set; }



        public Checkout()
        {
            InitializeComponent();
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            //close the checkout window]

            this.Close();
        }

        private void timerThingy_Tick(object sender, EventArgs e)
        {
            //put the vars into the boxes. i guess no calculations here too bad for me.
            labelAdult.Text = TotalnumofAdults.ToString();
            labelVisiting.Text = TotalnumofVisiting.ToString();
            labelK8.Text = TotalnumofK8.ToString();

            labelTotal.Text = TotalPriceCheckouted.ToString("C");
        }
    }
}
