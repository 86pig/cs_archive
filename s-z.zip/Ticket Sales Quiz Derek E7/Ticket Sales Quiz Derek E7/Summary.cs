﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ticket_Sales_Quiz_Derek_E7
{
    public partial class Summary : Form
    {
        //six global props
        public double TotalnumofAdults { get; set; }
        public double TotalnumofVisiting { get; set; }
        public double TotalnumofK8 { get; set; }

        public double AdultPrice { get; set; }
        public double VisitorPrice { get; set; }
        public double K8Price { get; set; }




        public Summary()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //close the summary. Oops, i forgot to name the button before i clicked it. i reanamed it though.
            this.Close();
        }

        private void timerrandomomer_Tick(object sender, EventArgs e)
        {
            //put the numbers from vars into textboxes
            textBoxAdultTicket.Text = TotalnumofAdults.ToString();
            textBoxVisitingTicket.Text = TotalnumofVisiting.ToString();
            textBoxK8Tickets.Text = TotalnumofK8.ToString();

            textBoxAdultSales.Text = AdultPrice.ToString("C");
            textBoxVisitingSales.Text = VisitorPrice.ToString("C");
            textBoxK8Sales.Text = K8Price.ToString("C");

            //do the total calculations and put them into the ui
            double totaltickets = TotalnumofAdults + TotalnumofVisiting + TotalnumofK8;
            double totalsales = AdultPrice + VisitorPrice + K8Price;

            textBoxTotalTickets.Text = totaltickets.ToString();
            textBoxTotalSales.Text = totalsales.ToString("C");

        }
    }
}
