﻿namespace Sporting_1117489_Derek_E_p7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            radioButtonDefault = new RadioButton();
            Tornado = new RadioButton();
            Lightning = new RadioButton();
            Hailrain = new RadioButton();
            Shark = new RadioButton();
            label1 = new Label();
            pictureboxweather = new PictureBox();
            label2 = new Label();
            exit = new Button();
            textBoxname = new TextBox();
            messageBox = new RichTextBox();
            button1 = new Button();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureboxweather).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(radioButtonDefault);
            groupBox1.Controls.Add(Tornado);
            groupBox1.Controls.Add(Lightning);
            groupBox1.Controls.Add(Hailrain);
            groupBox1.Controls.Add(Shark);
            groupBox1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(26, 92);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(176, 201);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Weather Conditions";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // radioButtonDefault
            // 
            radioButtonDefault.AutoSize = true;
            radioButtonDefault.Checked = true;
            radioButtonDefault.Location = new Point(96, 156);
            radioButtonDefault.Name = "radioButtonDefault";
            radioButtonDefault.Size = new Size(119, 25);
            radioButtonDefault.TabIndex = 4;
            radioButtonDefault.TabStop = true;
            radioButtonDefault.Text = "radioButton1";
            radioButtonDefault.UseVisualStyleBackColor = true;
            radioButtonDefault.Visible = false;
            // 
            // Tornado
            // 
            Tornado.AutoSize = true;
            Tornado.Location = new Point(6, 137);
            Tornado.Name = "Tornado";
            Tornado.Size = new Size(84, 25);
            Tornado.TabIndex = 3;
            Tornado.Text = "Tornado";
            Tornado.UseVisualStyleBackColor = true;
            Tornado.CheckedChanged += Tornado_CheckedChanged;
            // 
            // Lightning
            // 
            Lightning.AutoSize = true;
            Lightning.Location = new Point(6, 75);
            Lightning.Name = "Lightning";
            Lightning.Size = new Size(94, 25);
            Lightning.TabIndex = 1;
            Lightning.Text = "Lightning";
            Lightning.UseVisualStyleBackColor = true;
            Lightning.CheckedChanged += Lightning_CheckedChanged;
            // 
            // Hailrain
            // 
            Hailrain.AutoSize = true;
            Hailrain.Location = new Point(6, 106);
            Hailrain.Name = "Hailrain";
            Hailrain.Size = new Size(98, 25);
            Hailrain.TabIndex = 2;
            Hailrain.Text = "Light Rain";
            Hailrain.UseVisualStyleBackColor = true;
            Hailrain.CheckedChanged += Hailrain_CheckedChanged;
            // 
            // Shark
            // 
            Shark.AutoSize = true;
            Shark.Location = new Point(6, 44);
            Shark.Name = "Shark";
            Shark.Size = new Size(103, 25);
            Shark.TabIndex = 0;
            Shark.Text = "Sharknami";
            Shark.UseVisualStyleBackColor = true;
            Shark.CheckedChanged += Shark_CheckedChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(271, 92);
            label1.Name = "label1";
            label1.Size = new Size(46, 17);
            label1.TabIndex = 1;
            label1.Text = "Name:";
            // 
            // pictureboxweather
            // 
            pictureboxweather.Location = new Point(271, 143);
            pictureboxweather.Name = "pictureboxweather";
            pictureboxweather.Size = new Size(236, 150);
            pictureboxweather.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureboxweather.TabIndex = 2;
            pictureboxweather.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(461, 409);
            label2.Name = "label2";
            label2.Size = new Size(46, 15);
            label2.TabIndex = 4;
            label2.Text = "Derek E";
            // 
            // exit
            // 
            exit.Location = new Point(235, 376);
            exit.Name = "exit";
            exit.Size = new Size(176, 48);
            exit.TabIndex = 5;
            exit.Text = "Exit";
            exit.UseVisualStyleBackColor = true;
            exit.Click += exit_Click;
            // 
            // textBoxname
            // 
            textBoxname.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBoxname.Location = new Point(323, 89);
            textBoxname.Name = "textBoxname";
            textBoxname.Size = new Size(184, 25);
            textBoxname.TabIndex = 6;
            // 
            // messageBox
            // 
            messageBox.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            messageBox.Location = new Point(26, 320);
            messageBox.Name = "messageBox";
            messageBox.Size = new Size(481, 37);
            messageBox.TabIndex = 8;
            messageBox.Text = "";
            // 
            // button1
            // 
            button1.Location = new Point(26, 376);
            button1.Name = "button1";
            button1.Size = new Size(176, 48);
            button1.TabIndex = 9;
            button1.Text = "Clear";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(messageBox);
            Controls.Add(textBoxname);
            Controls.Add(exit);
            Controls.Add(label2);
            Controls.Add(pictureboxweather);
            Controls.Add(label1);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Sporting Goods Store";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureboxweather).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private RadioButton Tornado;
        private RadioButton Lightning;
        private RadioButton Hailrain;
        private RadioButton Shark;
        private Label label1;
        private PictureBox pictureboxweather;
        private Label label2;
        private Button exit;
        private TextBox textBoxname;
        private RichTextBox messageBox;
        private RadioButton radioButtonDefault;
        private Button button1;
    }
}
