namespace Sporting_1117489_Derek_E_p7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Shark_CheckedChanged(object sender, EventArgs e)
        {
            string name = textBoxname.Text;
            pictureboxweather.Image = Properties.Resources.sharknami;
            messageBox.Text = "Grab something to protect you. This sharknami doesn't look good for your safety, " + name + ".";
        }

        private void Lightning_CheckedChanged(object sender, EventArgs e)
        {
            string name = textBoxname.Text;
            pictureboxweather.Image = Properties.Resources.lightning;
            messageBox.Text = "Don't be up high or you will get zapped, " + name + ".";
        }

        private void Hailrain_CheckedChanged(object sender, EventArgs e)
        {
            string name = textBoxname.Text;
            pictureboxweather.Image = Properties.Resources.hailrain;
            messageBox.Text = "It's either rain or hail. Perhaps wear a hard hat, " + name + ".";
        }

        private void Tornado_CheckedChanged(object sender, EventArgs e)
        {
            string name = textBoxname.Text;
            pictureboxweather.Image = Properties.Resources.tornado;
            messageBox.Text = "Yikes, that will pull you up into the stratosphere. Tie yourself to a fence, " + name + ".";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            radioButtonDefault.Checked = true;
            pictureboxweather.Image = null;
            textBoxname.Clear();
            textBoxname.Focus();
        }
    }
}
