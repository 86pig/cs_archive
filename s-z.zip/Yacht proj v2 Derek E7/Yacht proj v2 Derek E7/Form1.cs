﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Yacht_proj_v2_Derek_E7
{
    public partial class Form1 : Form
    {
        double totalcoster123 = 0;
        // create a list and include a data type
        List<double> sectionprices = new List<double>();

        //regualr array
        double[] totalsectionsales = new double[7];
        public Form1()
        {
            InitializeComponent();

            //use add mehtod
            sectionprices.Add(95);
            sectionprices.Add(137);
            sectionprices.Add(160);
            sectionprices.Add(192);
            sectionprices.Add(250);
            sectionprices.Add(400);
            sectionprices.Add(550);
            //this adds new entries

        }

        private void addYachtToolStripMenuItem_Click(object sender, EventArgs e)
        {

            bool inlist = false;

            string iamfrickingtired = textBoxName.Text;

            if (iamfrickingtired == "") MessageBox.Show("Enter a naem");
            else
            {
                // add lope to compare names to the student in the lsit 
                foreach (string inlistedbagel in comboBoxType.Items)
                {
                    //check if names mathc
                    if (iamfrickingtired.ToLower() == inlistedbagel.ToLower())
                    {
                        //if match: AYAY but DONT adsd to list !!    
                        inlist = true;
                        break; //break from loop euh duh 

                    }

                }



                textBoxName.Clear();
                //fi student not in list: add them bruh
                if (!inlist)
                {
                    comboBoxType.Items.Add(iamfrickingtired);
                }
            }

        }

        private void removeYachtToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (comboBoxType.SelectedIndex != -1)
            {
                //remove
                comboBoxType.Items.RemoveAt(comboBoxType.SelectedIndex);

                textBoxName.Clear();
            }
            else
            {
                MessageBox.Show("Seelct a gyacht type first");
            }
        }

        private void displaynumberOfTypesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int a = 0;
            foreach (string shuiththehsefhioIFOSJIHESIFUHSFHSHFIUSFMENUEFNUSEFUFNUESNFISUHFIUSHFKDSHFUHIUEYGAYETujOIJFOIJLIEJUNEOIUHSFISFIUSHFEYFSYFGEWHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATNOYOUDIDNTSEETHATUHEFUHSIUHFUSFHUEFHHSFIUSHFISUHFUFHSUEHFUEHUSHFIUHHFHAIHFIUEHFOHWTHINTHEOWROLDIDTHATHEVERHAPPENOATALLORYOURMOIEUSEIDONTREALYCAREIDIOTNWKNOIAICJUSTCAHTHITEHSPACEBAR in comboBoxType.Items)
            {
                a += 1;
                    
            }
            MessageBox.Show("u have....: " + a.ToString() + " gyachts in th elist");
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxName.Clear();
            textBoxCost.Clear();
            textBoxHours.Clear();
            textBoxName.Focus();
            comboBoxType.SelectedIndex = -1;
            comboBoxSize.SelectedIndex = -1;
            totalcoster123 = 0;
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBoxName.Clear();
            textBoxCost.Clear();
            textBoxHours.Clear();
            textBoxName.Focus();
            comboBoxType.SelectedIndex = -1;
            comboBoxSize.SelectedIndex = -1;
            totalcoster123 = 0;
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            //check to see if something is selected in the comobooxooxowowowowowowowowoowuwuwuwuuwuwuwwuwuwuwumewo
            if (comboBoxSize.SelectedIndex != -1)
            {
                try
                {
                    int index = comboBoxSize.SelectedIndex;
                    double price = sectionprices[index];
                    double hours = double.Parse(textBoxHours.Text);
                    double cost = price * hours;

                    //ip[date secopitms sales
                    totalsectionsales[index] += cost;
                    totalcoster123 += cost;
                    textBoxCost.Text = cost.ToString("C");
                }

                catch
                {
                    MessageBox.Show("Enter a valid value!!", "ALERT!!!!");
                }
            }
        }

        private void printPreviewDialogYACHT_Load(object sender, EventArgs e)
        {

        }

        private void printDocumentGYSAHGT_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {


            Font printFont = new Font("Arial", 12);
            Font headingFont = new Font("Arial", 24, FontStyle.Bold);
            float verticalPrintPositionFloat = e.MarginBounds.Top;
            float horizontalPrintPositionFloat = e.MarginBounds.Left;
            float lineHeightFloat = printFont.GetHeight();

            // Print heading.
            e.Graphics.DrawString("Your charter information: ",
            headingFont,
            Brushes.SaddleBrown, horizontalPrintPositionFloat,
            verticalPrintPositionFloat);

            verticalPrintPositionFloat += 2 * lineHeightFloat;

            e.Graphics.DrawString("Renter: " + textBoxName.Text, printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);
            verticalPrintPositionFloat += 2 * lineHeightFloat;
            e.Graphics.DrawString("Hours chartered: " + textBoxHours.Text, printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);
            verticalPrintPositionFloat += 2 * lineHeightFloat;
            e.Graphics.DrawString("Yacht type: " + comboBoxType.Text, printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);
            verticalPrintPositionFloat += 2 * lineHeightFloat;
            e.Graphics.DrawString("Yacht size:" + comboBoxSize.Text, printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);
            verticalPrintPositionFloat += 2 * lineHeightFloat;
            e.Graphics.DrawString("Total cost: " + totalcoster123.ToString("C"), printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);


        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }

        private void printSummaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocumentGYSAHGT;
            printPreviewDialog1.ShowDialog();
        }

        private void printDocumentgyachtlist_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Font printFont = new Font("Arial", 12);
            Font headingFont = new Font("Arial", 24, FontStyle.Bold);
            float verticalPrintPositionFloat = e.MarginBounds.Top;
            float horizontalPrintPositionFloat = e.MarginBounds.Left;
            float lineHeightFloat = printFont.GetHeight();

            // Print heading.
            e.Graphics.DrawString("List of yacht  types: ",
            headingFont,
            Brushes.SaddleBrown, horizontalPrintPositionFloat,
            verticalPrintPositionFloat);

            verticalPrintPositionFloat += 2 * lineHeightFloat;

            foreach (String student in comboBoxType.Items)
            {
                e.Graphics.DrawString(student, printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);

                verticalPrintPositionFloat += 2 * lineHeightFloat;


            }
        }

        private void printYachtTimesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printPreviewDialog2.Document = printDocumentgyachtlist;
            printPreviewDialog2.ShowDialog();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox1 aboutDlg = new AboutBox1();
            MessageBox.Show("I'm not sure what happned. maybe i somehow accidentally clicked the .NET framework upon project creation, however my properties window is white and not what i was used to.");
            aboutDlg.ShowDialog();
        }
    }//fix
}