﻿namespace Team_Project_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBoxName = new TextBox();
            textBoxCoach = new TextBox();
            label2 = new Label();
            textBoxWins = new TextBox();
            label3 = new Label();
            textBoxLosses = new TextBox();
            label4 = new Label();
            textBoxties = new TextBox();
            label5 = new Label();
            textBoxGoals = new TextBox();
            label6 = new Label();
            textBoxGamesPlayed = new TextBox();
            label7 = new Label();
            textBoxwlr = new TextBox();
            label8 = new Label();
            textBoxggr = new TextBox();
            label9 = new Label();
            listBoxTeams = new ListBox();
            buttonAdd = new Button();
            buttonupdtae = new Button();
            buttonClear = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(50, 46);
            label1.Name = "label1";
            label1.Size = new Size(39, 15);
            label1.TabIndex = 0;
            label1.Text = "Name";
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(148, 43);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(100, 23);
            textBoxName.TabIndex = 1;
            // 
            // textBoxCoach
            // 
            textBoxCoach.Location = new Point(148, 72);
            textBoxCoach.Name = "textBoxCoach";
            textBoxCoach.Size = new Size(100, 23);
            textBoxCoach.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(50, 75);
            label2.Name = "label2";
            label2.Size = new Size(41, 15);
            label2.TabIndex = 2;
            label2.Text = "Coach";
            // 
            // textBoxWins
            // 
            textBoxWins.Location = new Point(148, 101);
            textBoxWins.Name = "textBoxWins";
            textBoxWins.Size = new Size(100, 23);
            textBoxWins.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(50, 104);
            label3.Name = "label3";
            label3.Size = new Size(33, 15);
            label3.TabIndex = 4;
            label3.Text = "Wins";
            // 
            // textBoxLosses
            // 
            textBoxLosses.Location = new Point(148, 130);
            textBoxLosses.Name = "textBoxLosses";
            textBoxLosses.Size = new Size(100, 23);
            textBoxLosses.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(50, 133);
            label4.Name = "label4";
            label4.Size = new Size(41, 15);
            label4.TabIndex = 6;
            label4.Text = "Losses";
            // 
            // textBoxties
            // 
            textBoxties.Location = new Point(148, 159);
            textBoxties.Name = "textBoxties";
            textBoxties.Size = new Size(100, 23);
            textBoxties.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(50, 162);
            label5.Name = "label5";
            label5.Size = new Size(27, 15);
            label5.TabIndex = 8;
            label5.Text = "Ties";
            // 
            // textBoxGoals
            // 
            textBoxGoals.Location = new Point(148, 188);
            textBoxGoals.Name = "textBoxGoals";
            textBoxGoals.Size = new Size(100, 23);
            textBoxGoals.TabIndex = 11;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(50, 191);
            label6.Name = "label6";
            label6.Size = new Size(36, 15);
            label6.TabIndex = 10;
            label6.Text = "Goals";
            // 
            // textBoxGamesPlayed
            // 
            textBoxGamesPlayed.Location = new Point(148, 217);
            textBoxGamesPlayed.Name = "textBoxGamesPlayed";
            textBoxGamesPlayed.ReadOnly = true;
            textBoxGamesPlayed.Size = new Size(100, 23);
            textBoxGamesPlayed.TabIndex = 13;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(50, 220);
            label7.Name = "label7";
            label7.Size = new Size(81, 15);
            label7.TabIndex = 12;
            label7.Text = "Games played";
            // 
            // textBoxwlr
            // 
            textBoxwlr.Location = new Point(148, 246);
            textBoxwlr.Name = "textBoxwlr";
            textBoxwlr.ReadOnly = true;
            textBoxwlr.Size = new Size(100, 23);
            textBoxwlr.TabIndex = 15;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(50, 249);
            label8.Name = "label8";
            label8.Size = new Size(44, 15);
            label8.TabIndex = 14;
            label8.Text = "Win  %";
            // 
            // textBoxggr
            // 
            textBoxggr.Location = new Point(148, 275);
            textBoxggr.Name = "textBoxggr";
            textBoxggr.ReadOnly = true;
            textBoxggr.Size = new Size(100, 23);
            textBoxggr.TabIndex = 17;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(50, 278);
            label9.Name = "label9";
            label9.Size = new Size(30, 15);
            label9.TabIndex = 16;
            label9.Text = "GGR";
            // 
            // listBoxTeams
            // 
            listBoxTeams.FormattingEnabled = true;
            listBoxTeams.ItemHeight = 15;
            listBoxTeams.Location = new Point(290, 174);
            listBoxTeams.Name = "listBoxTeams";
            listBoxTeams.Size = new Size(198, 124);
            listBoxTeams.TabIndex = 18;
            listBoxTeams.SelectedIndexChanged += listBoxTeams_SelectedIndexChanged;
            // 
            // buttonAdd
            // 
            buttonAdd.Location = new Point(290, 46);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(198, 56);
            buttonAdd.TabIndex = 19;
            buttonAdd.Text = "add new team";
            buttonAdd.UseVisualStyleBackColor = true;
            buttonAdd.Click += buttonAdd_Click;
            // 
            // buttonupdtae
            // 
            buttonupdtae.Location = new Point(290, 108);
            buttonupdtae.Name = "buttonupdtae";
            buttonupdtae.Size = new Size(198, 56);
            buttonupdtae.TabIndex = 20;
            buttonupdtae.Text = "update team info";
            buttonupdtae.UseVisualStyleBackColor = true;
            buttonupdtae.Click += buttonupdtae_Click;
            // 
            // buttonClear
            // 
            buttonClear.Location = new Point(263, 43);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(21, 255);
            buttonClear.TabIndex = 21;
            buttonClear.Text = "clear";
            buttonClear.UseVisualStyleBackColor = true;
            buttonClear.Click += buttonClear_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(538, 336);
            Controls.Add(buttonClear);
            Controls.Add(buttonupdtae);
            Controls.Add(buttonAdd);
            Controls.Add(listBoxTeams);
            Controls.Add(textBoxggr);
            Controls.Add(label9);
            Controls.Add(textBoxwlr);
            Controls.Add(label8);
            Controls.Add(textBoxGamesPlayed);
            Controls.Add(label7);
            Controls.Add(textBoxGoals);
            Controls.Add(label6);
            Controls.Add(textBoxties);
            Controls.Add(label5);
            Controls.Add(textBoxLosses);
            Controls.Add(label4);
            Controls.Add(textBoxWins);
            Controls.Add(label3);
            Controls.Add(textBoxCoach);
            Controls.Add(label2);
            Controls.Add(textBoxName);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Teams class object gyaifuhuodfIRJKECIOTIINGINEG";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBoxName;
        private TextBox textBoxCoach;
        private Label label2;
        private TextBox textBoxWins;
        private Label label3;
        private TextBox textBoxLosses;
        private Label label4;
        private TextBox textBoxties;
        private Label label5;
        private TextBox textBoxGoals;
        private Label label6;
        private TextBox textBoxGamesPlayed;
        private Label label7;
        private TextBox textBoxwlr;
        private Label label8;
        private TextBox textBoxggr;
        private Label label9;
        private ListBox listBoxTeams;
        private Button buttonAdd;
        private Button buttonupdtae;
        private Button buttonClear;
    }
}
