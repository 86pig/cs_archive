﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Team_Project_Derek_E7
{
    public class Team
    {
        public Team()
        {
            TeamName = string.Empty;
        }
        public Team(string n, string c, int w, int l, int t, int g)
        {
            TeamName = n;
            Coach = c;
            Wins = w;
            Losses = l;
            Ties = t;
            Goals = g;
        }
        public string TeamName { get; set; }
        public string Coach { get; set; }
        public int Wins { get; set; }   
        public int Losses { get; set; }
        public int Ties { get; set; }
        public int Goals { get; set; }

        public int TotalGames
        {
            get
            {
                return GetTotalGames();
            }
        }
        public double WLR
        {
            get
            {
                return GetWLR();
            }
        }
        public double GGR
        {
            get
            {
                return GetGGR();
            }
        }

        public int GetTotalGames()
        {
            return Wins + Losses + Ties;
        }
        public double GetWLR()
        {
            return Wins / (double)GetTotalGames();
        }
        public double GetGGR()
        {
            return Goals / (double)GetTotalGames();
        }













    }
}
