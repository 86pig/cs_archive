namespace Team_Project_Derek_E7
{
    public partial class Form1 : Form
    {
        List<Team> teams = new List<Team>();

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            Team team;
            try
            {
                team = new Team(textBoxName.Text, textBoxCoach.Text, int.Parse(textBoxWins.Text), int.Parse(textBoxLosses.Text), int.Parse(textBoxties.Text), int.Parse(textBoxGoals.Text));
            }
            catch
            {
                MessageBox.Show("proof reading my message box? well heres your message. you inputed something wrong. BUT ON PURPOSE! I KNOW! IM IN THE WALL BEHIND YOU! AAAAAAAAAAAAAAAAAAHHHHHHHHHHHHHHHHH!");
                return;
            }
            textBoxGamesPlayed.Text = team.TotalGames.ToString();
            textBoxwlr.Text = team.WLR.ToString("n3");
            textBoxggr.Text = team.GGR.ToString("n3");

            teams.Add(team);
            listBoxTeams.Items.Add(team.TeamName);

        }

        private void listBoxTeams_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxTeams.SelectedIndex == -1) return;

            int index = listBoxTeams.SelectedIndex;
            textBoxName.Text = teams[index].TeamName;
            textBoxCoach.Text = teams[index].Coach;
            textBoxWins.Text = teams[index].Wins.ToString();
            textBoxLosses.Text = teams[index].Losses.ToString();
            textBoxties.Text = teams[index].Ties.ToString();
            textBoxGoals.Text = teams[index].Goals.ToString();
            textBoxGamesPlayed.Text = teams[index].TotalGames.ToString();
            textBoxwlr.Text = teams[index].WLR.ToString("n3");
            textBoxggr.Text = teams[index].GGR.ToString("n3");
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxName.Clear();
            textBoxCoach.Clear();
            textBoxWins.Clear();
            textBoxLosses.Clear();
            textBoxGoals.Clear();
            textBoxGamesPlayed.Clear();
            textBoxties.Clear();
            textBoxwlr.Clear();
            textBoxggr.Clear();
            textBoxName.Focus();
        }

        private void buttonupdtae_Click(object sender, EventArgs e)
        {
            if (listBoxTeams.SelectedIndex == -1) return;
            int i = listBoxTeams.SelectedIndex;
            try
            {
                teams[i].TeamName = textBoxName.Text;
                teams[i].Coach = textBoxCoach.Text;
                teams[i].Wins = int.Parse(textBoxWins.Text);
                teams[i].Losses = int.Parse(textBoxLosses.Text);
                teams[i].Ties = int.Parse(textBoxties.Text);
                teams[i].Goals = int.Parse(textBoxGoals.Text);
            }
            catch
            {
                MessageBox.Show("how did yo umess up this baldy.! invalide input!!! OHWOAH");
            }

            textBoxGamesPlayed.Text = teams[i].TotalGames.ToString();
            textBoxwlr.Text = teams[i].WLR.ToString();
            textBoxggr.Text = teams[i].GGR.ToString();

        }
    }
}
