﻿namespace unit_8_demo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            label1 = new Label();
            textBoxName = new TextBox();
            textBoxAge = new TextBox();
            label2 = new Label();
            textBoxGPA = new TextBox();
            label3 = new Label();
            buttonAdd = new Button();
            listBoxStudents = new ListBox();
            buttonPRINTstudents = new Button();
            buttonPrintALL = new Button();
            printPreviewDialogAll = new PrintPreviewDialog();
            printDocumentAll = new System.Drawing.Printing.PrintDocument();
            printDocumentIQ = new System.Drawing.Printing.PrintDocument();
            printPreviewDialogIQ = new PrintPreviewDialog();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F);
            label1.Location = new Point(42, 49);
            label1.Name = "label1";
            label1.Size = new Size(49, 20);
            label1.TabIndex = 0;
            label1.Text = "Name";
            // 
            // textBoxName
            // 
            textBoxName.Font = new Font("Segoe UI", 11.25F);
            textBoxName.Location = new Point(127, 46);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(100, 27);
            textBoxName.TabIndex = 1;
            // 
            // textBoxAge
            // 
            textBoxAge.Font = new Font("Segoe UI", 11.25F);
            textBoxAge.Location = new Point(147, 100);
            textBoxAge.Name = "textBoxAge";
            textBoxAge.Size = new Size(100, 27);
            textBoxAge.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11.25F);
            label2.Location = new Point(62, 103);
            label2.Name = "label2";
            label2.Size = new Size(36, 20);
            label2.TabIndex = 2;
            label2.Text = "Age";
            // 
            // textBoxGPA
            // 
            textBoxGPA.Font = new Font("Segoe UI", 11.25F);
            textBoxGPA.Location = new Point(127, 150);
            textBoxGPA.Name = "textBoxGPA";
            textBoxGPA.Size = new Size(100, 27);
            textBoxGPA.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11.25F);
            label3.Location = new Point(42, 153);
            label3.Name = "label3";
            label3.Size = new Size(36, 20);
            label3.TabIndex = 4;
            label3.Text = "GPA";
            // 
            // buttonAdd
            // 
            buttonAdd.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonAdd.Location = new Point(42, 224);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(235, 141);
            buttonAdd.TabIndex = 6;
            buttonAdd.Text = "Add student";
            buttonAdd.UseVisualStyleBackColor = true;
            buttonAdd.Click += buttonAdd_Click;
            // 
            // listBoxStudents
            // 
            listBoxStudents.Font = new Font("Segoe UI", 12F);
            listBoxStudents.FormattingEnabled = true;
            listBoxStudents.ItemHeight = 21;
            listBoxStudents.Location = new Point(347, 45);
            listBoxStudents.Name = "listBoxStudents";
            listBoxStudents.Size = new Size(340, 235);
            listBoxStudents.TabIndex = 7;
            listBoxStudents.SelectedIndexChanged += listBoxStudents_SelectedIndexChanged;
            // 
            // buttonPRINTstudents
            // 
            buttonPRINTstudents.Location = new Point(127, 400);
            buttonPRINTstudents.Name = "buttonPRINTstudents";
            buttonPRINTstudents.Size = new Size(166, 38);
            buttonPRINTstudents.TabIndex = 8;
            buttonPRINTstudents.Text = "print iq ppl";
            buttonPRINTstudents.UseVisualStyleBackColor = true;
            buttonPRINTstudents.Click += buttonPRINTstudents_Click;
            // 
            // buttonPrintALL
            // 
            buttonPrintALL.Location = new Point(303, 350);
            buttonPrintALL.Name = "buttonPrintALL";
            buttonPrintALL.Size = new Size(166, 38);
            buttonPrintALL.TabIndex = 9;
            buttonPrintALL.Text = "Print all";
            buttonPrintALL.UseVisualStyleBackColor = true;
            buttonPrintALL.Click += buttonPrintALL_Click;
            // 
            // printPreviewDialogAll
            // 
            printPreviewDialogAll.AutoScrollMargin = new Size(0, 0);
            printPreviewDialogAll.AutoScrollMinSize = new Size(0, 0);
            printPreviewDialogAll.ClientSize = new Size(400, 300);
            printPreviewDialogAll.Enabled = true;
            printPreviewDialogAll.Icon = (Icon)resources.GetObject("printPreviewDialogAll.Icon");
            printPreviewDialogAll.Name = "printPreviewDialogAll";
            printPreviewDialogAll.Visible = false;
            // 
            // printDocumentAll
            // 
            printDocumentAll.PrintPage += printDocumentAll_PrintPage;
            // 
            // printDocumentIQ
            // 
            printDocumentIQ.PrintPage += printDocumentIQ_PrintPage;
            // 
            // printPreviewDialogIQ
            // 
            printPreviewDialogIQ.AutoScrollMargin = new Size(0, 0);
            printPreviewDialogIQ.AutoScrollMinSize = new Size(0, 0);
            printPreviewDialogIQ.ClientSize = new Size(400, 300);
            printPreviewDialogIQ.Enabled = true;
            printPreviewDialogIQ.Icon = (Icon)resources.GetObject("printPreviewDialogIQ.Icon");
            printPreviewDialogIQ.Name = "printPreviewDialogIQ";
            printPreviewDialogIQ.Visible = false;
            // 
            // Form1
            // 
            AcceptButton = buttonAdd;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonPrintALL);
            Controls.Add(buttonPRINTstudents);
            Controls.Add(listBoxStudents);
            Controls.Add(buttonAdd);
            Controls.Add(textBoxGPA);
            Controls.Add(label3);
            Controls.Add(textBoxAge);
            Controls.Add(label2);
            Controls.Add(textBoxName);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBoxName;
        private TextBox textBoxAge;
        private Label label2;
        private TextBox textBoxGPA;
        private Label label3;
        private Button buttonAdd;
        private ListBox listBoxStudents;
        private Button buttonPRINTstudents;
        private Button buttonPrintALL;
        private PrintPreviewDialog printPreviewDialogAll;
        private System.Drawing.Printing.PrintDocument printDocumentAll;
        private System.Drawing.Printing.PrintDocument printDocumentIQ;
        private PrintPreviewDialog printPreviewDialogIQ;
    }
}
