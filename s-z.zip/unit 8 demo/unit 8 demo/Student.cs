﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace unit_8_demo
{
    public class Student //change internal to public
    {// create properties for class objects 
        public string StudentName { get; set; }
        public int Age { get; set; }
        public double GPA { get; set; }

        //create constructor to pass in values to the student object

        public Student(string sn, int a, double gpa)
        {
            //assign param values 2 the object properties
            StudentName = sn;
            Age = a;
            GPA = gpa;

        }
        


    }
}
