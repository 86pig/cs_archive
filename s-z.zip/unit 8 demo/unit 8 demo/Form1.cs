namespace unit_8_demo
{
    public partial class Form1 : Form
    {
        //create a student 1d array

        Student[] students = new Student[10];
        //add index var
        int index = 0;


        public Form1()
        {
            InitializeComponent();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            //get ui info

            string name = textBoxName.Text;
            int age = int.Parse(textBoxAge.Text);
            double gpa = double.Parse(textBoxGPA.Text);

            //create new instance of a student

            Student pog = new Student(name, age, gpa);
            //add new instgance to array
            students[index] = pog;
            //increment the index
            index++;
            //check to make only valid index is used
            if (index >= students.Length)
            {
                index = 0;

            }
            listBoxStudents.Items.Add(name);

            textBoxName.Clear();
            textBoxAge.Clear();
            textBoxGPA.Clear();

        }

        private void listBoxStudents_SelectedIndexChanged(object sender, EventArgs e)
        {
            int listindex = listBoxStudents.SelectedIndex;
            if (listindex != -1)
            {
                //retreive instance form array
                Student pog = students[listindex];

                // display info  back to ui
                textBoxName.Text = pog.StudentName;
                textBoxAge.Text = pog.Age.ToString();
                textBoxGPA.Text = pog.GPA.ToString();


            }
        }

        private void printDocumentAll_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Font printFont = new Font("Arial", 12);
            Font headingFont = new Font("Arial", 24, FontStyle.Bold);
            float verticalPrintPositionFloat = e.MarginBounds.Top;
            float horizontalPrintPositionFloat = e.MarginBounds.Left;
            float lineHeightFloat = printFont.GetHeight();

            float[] cols =
            {
                horizontalPrintPositionFloat,
                horizontalPrintPositionFloat + 200,
                horizontalPrintPositionFloat + 400,
            };
            // Print heading.
            e.Graphics.DrawString("Name: ",
            headingFont,
            Brushes.SaddleBrown, cols[0],
            verticalPrintPositionFloat);



            // Print heading.
            e.Graphics.DrawString("Age: ",
            headingFont,
            Brushes.SaddleBrown, cols[1],
            verticalPrintPositionFloat);


            // Print heading.
            e.Graphics.DrawString("GPA: ",
            headingFont,
            Brushes.SaddleBrown, cols[2],
            verticalPrintPositionFloat);

            verticalPrintPositionFloat += 2 * lineHeightFloat;

            for (int i = 0; i < students.Length; i++)
            {
                if (students[i] == null)
                {
                    break;
                }
                else
                {
                    // Print heading.
                    e.Graphics.DrawString(students[i].StudentName,
                    printFont,
                    Brushes.SaddleBrown, cols[0],
                    verticalPrintPositionFloat);


                    // Print heading.
                    e.Graphics.DrawString(students[i].Age.ToString(),
                    printFont,
                    Brushes.SaddleBrown, cols[1],
                    verticalPrintPositionFloat);


                    // Print heading.
                    e.Graphics.DrawString(students[i].GPA.ToString(),
                    printFont,
                    Brushes.SaddleBrown, cols[2],
                    verticalPrintPositionFloat);

                    verticalPrintPositionFloat += 2 * lineHeightFloat;
                }


            }



            //foreach (String student in listBoxStudents.Items)
            //{
            //    e.Graphics.DrawString(student, printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);

            //    verticalPrintPositionFloat += 2 * lineHeightFloat;


            //}
        }

        private void buttonPrintALL_Click(object sender, EventArgs e)
        {
            printPreviewDialogAll.Document = printDocumentAll;
            printPreviewDialogAll.ShowDialog();
        }

        private void printDocumentIQ_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Font printFont = new Font("Arial", 12);
            Font headingFont = new Font("Arial", 24, FontStyle.Bold);
            float verticalPrintPositionFloat = e.MarginBounds.Top;
            float horizontalPrintPositionFloat = e.MarginBounds.Left;
            float lineHeightFloat = printFont.GetHeight();

            float[] cols =
            {
                horizontalPrintPositionFloat,
                horizontalPrintPositionFloat + 200,
                horizontalPrintPositionFloat + 400,
            };
            // Print heading.
            e.Graphics.DrawString("Name: ",
            headingFont,
            Brushes.SaddleBrown, cols[0],
            verticalPrintPositionFloat);



            // Print heading.
            e.Graphics.DrawString("Age: ",
            headingFont,
            Brushes.SaddleBrown, cols[1],
            verticalPrintPositionFloat);


            // Print heading.
            e.Graphics.DrawString("GPA: ",
            headingFont,
            Brushes.SaddleBrown, cols[2],
            verticalPrintPositionFloat);

            verticalPrintPositionFloat += 2 * lineHeightFloat;

            for (int i = 0; i < students.Length; i++)
            {
                if (students[i] == null)
                {
                    break;
                }
                if (students[i].GPA >= 3.8f)
                {
                    // Print heading.
                    e.Graphics.DrawString(students[i].StudentName,
                    printFont,
                    Brushes.SaddleBrown, cols[0],
                    verticalPrintPositionFloat);


                    // Print heading.
                    e.Graphics.DrawString(students[i].Age.ToString(),
                    printFont,
                    Brushes.SaddleBrown, cols[1],
                    verticalPrintPositionFloat);


                    // Print heading.
                    e.Graphics.DrawString(students[i].GPA.ToString(),
                    printFont,
                    Brushes.SaddleBrown, cols[2],
                    verticalPrintPositionFloat);

                    verticalPrintPositionFloat += 2 * lineHeightFloat;
                }
            }
        }
        private void buttonPRINTstudents_Click(object sender, EventArgs e)
        {
            printPreviewDialogIQ.Document = printDocumentIQ;
            printPreviewDialogIQ.ShowDialog();
        }
    }
}
