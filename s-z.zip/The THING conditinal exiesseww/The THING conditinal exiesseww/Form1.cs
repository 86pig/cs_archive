namespace The_THING_conditinal_exiesseww
{
    public partial class Form1 : Form
    {
        //come up with random numberse
        Random rnd = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCompare_Click(object sender, EventArgs e)
        {
            /*
             * relational operators <, <=, >, >=, ==, !=
             * if statement wil always have () with a conditin inside of it
             * for example: if(a>b); 
             * 
             * examples on fomratiting:
             * if(a>b) x = 12;
             * if (a>b)
             *     x = 22;
             * if a>b)
             * {
             *      x = 32;
             * }
             */

            int num1 = int.Parse(textboxfirstnumber.Text);
            int num2 = int.Parse(textBoxsecondnubmer.Text);
            string output = "";

            //use if statement to determine output

            if (num1 > num2) output += "num1 is greater than num2\n";
            if (num2 >= num1)
                output += "num1 is less than or equal to num2\n";
            if (num1 < num2)
            {
                output += "num1 is less than num2\n";
            }
            if (num2 <= num1)
                output += "num1 is less than or equal to  num2\n";
            if (num1 == num2)
                output += "num1 is euql to num2\n";
            if (num1 != num2)
                output += "num1 is not the same as num2\n";


            richTextBoxoafiuahfiuah.Text = output;







        }

        private void button1exx_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttontosscoin_Click(object sender, EventArgs e)
        {
            int rndValue = rnd.Next(0, 2);
            //display h/t to user. 1=h 2=t

            if (rndValue == 0)
                labeltossss.Text = "heads";
            else labeltossss.Text = "Tails";

        }

        private void bottongetgrade_Click(object sender, EventArgs e)
        {
            int score = int.Parse(textBoxSCORE.Text);
            String grade = "";

            //ib grades go from 7-0

            if (score >= 55) grade = "7";
            else if (score >= 48) grade = "6";
            else if (score >= 40) grade = "5";
            else if (score >= 32) grade = "4";
            else if (score >= 27) grade = "3";
            else if (score >= 18) grade = "2";
            else if (score >= 10) grade = "1";
            else grade = "0";

            // didsoplay grade to hte ui

            textBoxGrade.Text = grade;



        }
    }
}



