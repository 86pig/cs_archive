﻿namespace The_THING_conditinal_exiesseww
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            richTextBoxoafiuahfiuah = new RichTextBox();
            buttonCompare = new Button();
            textboxfirstnumber = new TextBox();
            textBoxsecondnubmer = new TextBox();
            button1exx = new Button();
            buttontosscoin = new Button();
            labeltossss = new Label();
            textBoxSCORE = new TextBox();
            label3 = new Label();
            label4 = new Label();
            textBoxGrade = new TextBox();
            bottongetgrade = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F);
            label1.Location = new Point(32, 38);
            label1.Name = "label1";
            label1.Size = new Size(84, 19);
            label1.TabIndex = 0;
            label1.Text = "numbre one";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F);
            label2.Location = new Point(32, 100);
            label2.Name = "label2";
            label2.Size = new Size(110, 19);
            label2.TabIndex = 1;
            label2.Text = "tsosociinoin coin";
            // 
            // richTextBoxoafiuahfiuah
            // 
            richTextBoxoafiuahfiuah.Location = new Point(30, 181);
            richTextBoxoafiuahfiuah.Name = "richTextBoxoafiuahfiuah";
            richTextBoxoafiuahfiuah.Size = new Size(306, 160);
            richTextBoxoafiuahfiuah.TabIndex = 2;
            richTextBoxoafiuahfiuah.Text = "";
            // 
            // buttonCompare
            // 
            buttonCompare.Location = new Point(32, 347);
            buttonCompare.Name = "buttonCompare";
            buttonCompare.Size = new Size(215, 69);
            buttonCompare.TabIndex = 3;
            buttonCompare.Text = "Compare NUmbers";
            buttonCompare.UseVisualStyleBackColor = true;
            buttonCompare.Click += buttonCompare_Click;
            // 
            // textboxfirstnumber
            // 
            textboxfirstnumber.Location = new Point(133, 37);
            textboxfirstnumber.Name = "textboxfirstnumber";
            textboxfirstnumber.Size = new Size(100, 23);
            textboxfirstnumber.TabIndex = 4;
            // 
            // textBoxsecondnubmer
            // 
            textBoxsecondnubmer.Location = new Point(133, 99);
            textBoxsecondnubmer.Name = "textBoxsecondnubmer";
            textBoxsecondnubmer.Size = new Size(100, 23);
            textBoxsecondnubmer.TabIndex = 5;
            // 
            // button1exx
            // 
            button1exx.Location = new Point(535, 319);
            button1exx.Name = "button1exx";
            button1exx.Size = new Size(215, 69);
            button1exx.TabIndex = 6;
            button1exx.Text = "exixtotww\\";
            button1exx.UseVisualStyleBackColor = true;
            button1exx.Click += button1exx_Click;
            // 
            // buttontosscoin
            // 
            buttontosscoin.Location = new Point(388, 34);
            buttontosscoin.Name = "buttontosscoin";
            buttontosscoin.Size = new Size(195, 95);
            buttontosscoin.TabIndex = 7;
            buttontosscoin.Text = "tosscoin";
            buttontosscoin.UseVisualStyleBackColor = true;
            buttontosscoin.Click += buttontosscoin_Click;
            // 
            // labeltossss
            // 
            labeltossss.AutoSize = true;
            labeltossss.Font = new Font("Segoe UI", 10F);
            labeltossss.Location = new Point(460, 146);
            labeltossss.Name = "labeltossss";
            labeltossss.Size = new Size(92, 19);
            labeltossss.TabIndex = 8;
            labeltossss.Text = "second numb";
            // 
            // textBoxSCORE
            // 
            textBoxSCORE.Location = new Point(494, 202);
            textBoxSCORE.Name = "textBoxSCORE";
            textBoxSCORE.Size = new Size(100, 23);
            textBoxSCORE.TabIndex = 9;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10F);
            label3.Location = new Point(388, 206);
            label3.Name = "label3";
            label3.Size = new Size(65, 19);
            label3.TabIndex = 10;
            label3.Text = "ib sCORE";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10F);
            label4.Location = new Point(388, 246);
            label4.Name = "label4";
            label4.Size = new Size(44, 19);
            label4.TabIndex = 12;
            label4.Text = "grade";
            // 
            // textBoxGrade
            // 
            textBoxGrade.Location = new Point(494, 242);
            textBoxGrade.Name = "textBoxGrade";
            textBoxGrade.ReadOnly = true;
            textBoxGrade.Size = new Size(100, 23);
            textBoxGrade.TabIndex = 11;
            // 
            // bottongetgrade
            // 
            bottongetgrade.Location = new Point(623, 181);
            bottongetgrade.Name = "bottongetgrade";
            bottongetgrade.Size = new Size(109, 103);
            bottongetgrade.TabIndex = 13;
            bottongetgrade.Text = "get ib grade";
            bottongetgrade.UseVisualStyleBackColor = true;
            bottongetgrade.Click += bottongetgrade_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(bottongetgrade);
            Controls.Add(label4);
            Controls.Add(textBoxGrade);
            Controls.Add(label3);
            Controls.Add(textBoxSCORE);
            Controls.Add(labeltossss);
            Controls.Add(buttontosscoin);
            Controls.Add(button1exx);
            Controls.Add(textBoxsecondnubmer);
            Controls.Add(textboxfirstnumber);
            Controls.Add(buttonCompare);
            Controls.Add(richTextBoxoafiuahfiuah);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "unuit 4 dmemowo";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private RichTextBox richTextBoxoafiuahfiuah;
        private Button buttonCompare;
        private TextBox textboxfirstnumber;
        private TextBox textBoxsecondnubmer;
        private Button button1exx;
        private Button buttontosscoin;
        private Label labeltossss;
        private TextBox textBoxSCORE;
        private Label label3;
        private Label label4;
        private TextBox textBoxGrade;
        private Button bottongetgrade;
    }
}
