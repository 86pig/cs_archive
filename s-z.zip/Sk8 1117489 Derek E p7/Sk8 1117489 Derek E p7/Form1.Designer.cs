﻿namespace Sk8_1117489_Derek_E_p7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            cowLOGO = new PictureBox();
            labelTITLe = new Label();
            label2 = new Label();
            labelSLOGAn = new Label();
            groupBox1 = new GroupBox();
            magenta = new RadioButton();
            blue = new RadioButton();
            green = new RadioButton();
            red = new RadioButton();
            Showname = new CheckBox();
            showSlogan = new CheckBox();
            ShowLogo = new CheckBox();
            exit = new Button();
            toolTip1 = new ToolTip(components);
            toolTip2 = new ToolTip(components);
            toolTip3 = new ToolTip(components);
            ((System.ComponentModel.ISupportInitialize)cowLOGO).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // cowLOGO
            // 
            cowLOGO.Image = Properties.Resources.cowSk8A;
            cowLOGO.Location = new Point(12, 12);
            cowLOGO.Name = "cowLOGO";
            cowLOGO.Size = new Size(254, 163);
            cowLOGO.SizeMode = PictureBoxSizeMode.StretchImage;
            cowLOGO.TabIndex = 0;
            cowLOGO.TabStop = false;
            toolTip2.SetToolTip(cowLOGO, "Our logo");
            // 
            // labelTITLe
            // 
            labelTITLe.AutoSize = true;
            labelTITLe.Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelTITLe.Location = new Point(330, 44);
            labelTITLe.Name = "labelTITLe";
            labelTITLe.Size = new Size(322, 32);
            labelTITLe.TabIndex = 1;
            labelTITLe.Text = "Cow on a Sk8 BoArD Boards";
            toolTip1.SetToolTip(labelTITLe, "Our company name");
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(576, 382);
            label2.Name = "label2";
            label2.Size = new Size(76, 25);
            label2.TabIndex = 2;
            label2.Text = "Derek E";
            // 
            // labelSLOGAn
            // 
            labelSLOGAn.AutoSize = true;
            labelSLOGAn.Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelSLOGAn.Location = new Point(241, 196);
            labelSLOGAn.Name = "labelSLOGAn";
            labelSLOGAn.Size = new Size(547, 32);
            labelSLOGAn.TabIndex = 3;
            labelSLOGAn.Text = "\"Skate boarding is so easy, even a cow can do it\"";
            toolTip3.SetToolTip(labelSLOGAn, "Our slogan");
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(magenta);
            groupBox1.Controls.Add(blue);
            groupBox1.Controls.Add(green);
            groupBox1.Controls.Add(red);
            groupBox1.Location = new Point(12, 240);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(152, 145);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            groupBox1.Text = "Slogan Text Colour";
            // 
            // magenta
            // 
            magenta.AutoSize = true;
            magenta.Location = new Point(6, 97);
            magenta.Name = "magenta";
            magenta.Size = new Size(72, 19);
            magenta.TabIndex = 3;
            magenta.TabStop = true;
            magenta.Text = "Magenta";
            magenta.UseVisualStyleBackColor = true;
            magenta.CheckedChanged += magenta_CheckedChanged;
            // 
            // blue
            // 
            blue.AutoSize = true;
            blue.Location = new Point(6, 72);
            blue.Name = "blue";
            blue.Size = new Size(48, 19);
            blue.TabIndex = 2;
            blue.TabStop = true;
            blue.Text = "Blue";
            blue.UseVisualStyleBackColor = true;
            blue.CheckedChanged += blue_CheckedChanged;
            // 
            // green
            // 
            green.AutoSize = true;
            green.Location = new Point(6, 47);
            green.Name = "green";
            green.Size = new Size(56, 19);
            green.TabIndex = 1;
            green.TabStop = true;
            green.Text = "Green";
            green.UseVisualStyleBackColor = true;
            green.CheckedChanged += green_CheckedChanged;
            // 
            // red
            // 
            red.AutoSize = true;
            red.Location = new Point(6, 22);
            red.Name = "red";
            red.Size = new Size(45, 19);
            red.TabIndex = 0;
            red.TabStop = true;
            red.Text = "Red";
            red.UseVisualStyleBackColor = true;
            red.CheckedChanged += red_CheckedChanged;
            // 
            // Showname
            // 
            Showname.AutoSize = true;
            Showname.Checked = true;
            Showname.CheckState = CheckState.Checked;
            Showname.Location = new Point(183, 338);
            Showname.Name = "Showname";
            Showname.Size = new Size(145, 19);
            Showname.TabIndex = 4;
            Showname.Text = "Show Company Name";
            Showname.UseVisualStyleBackColor = true;
            Showname.CheckedChanged += Showname_CheckedChanged;
            // 
            // showSlogan
            // 
            showSlogan.AutoSize = true;
            showSlogan.Checked = true;
            showSlogan.CheckState = CheckState.Checked;
            showSlogan.Location = new Point(183, 363);
            showSlogan.Name = "showSlogan";
            showSlogan.Size = new Size(94, 19);
            showSlogan.TabIndex = 5;
            showSlogan.Text = "Show Slogan";
            showSlogan.UseVisualStyleBackColor = true;
            showSlogan.CheckedChanged += showSlogan_CheckedChanged;
            // 
            // ShowLogo
            // 
            ShowLogo.AutoSize = true;
            ShowLogo.Checked = true;
            ShowLogo.CheckState = CheckState.Checked;
            ShowLogo.Location = new Point(183, 388);
            ShowLogo.Name = "ShowLogo";
            ShowLogo.Size = new Size(85, 19);
            ShowLogo.TabIndex = 6;
            ShowLogo.Text = "Show Logo";
            ShowLogo.UseVisualStyleBackColor = true;
            ShowLogo.CheckedChanged += ShowLogo_CheckedChanged;
            // 
            // exit
            // 
            exit.Location = new Point(489, 297);
            exit.Name = "exit";
            exit.Size = new Size(163, 59);
            exit.TabIndex = 7;
            exit.Text = "&Exit";
            exit.UseVisualStyleBackColor = true;
            exit.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = exit;
            ClientSize = new Size(800, 450);
            Controls.Add(exit);
            Controls.Add(ShowLogo);
            Controls.Add(showSlogan);
            Controls.Add(Showname);
            Controls.Add(groupBox1);
            Controls.Add(labelSLOGAn);
            Controls.Add(label2);
            Controls.Add(labelTITLe);
            Controls.Add(cowLOGO);
            Name = "Form1";
            Text = "Cool Boards!";
            ((System.ComponentModel.ISupportInitialize)cowLOGO).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox cowLOGO;
        private Label labelTITLe;
        private Label label2;
        private Label labelSLOGAn;
        private GroupBox groupBox1;
        private RadioButton magenta;
        private RadioButton blue;
        private RadioButton green;
        private RadioButton red;
        private CheckBox Showname;
        private CheckBox showSlogan;
        private CheckBox ShowLogo;
        private Button exit;
        private ToolTip toolTip1;
        private ToolTip toolTip2;
        private ToolTip toolTip3;
    }
}
