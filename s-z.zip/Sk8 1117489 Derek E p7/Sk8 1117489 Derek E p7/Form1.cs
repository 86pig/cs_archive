namespace Sk8_1117489_Derek_E_p7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        //i forgot to change the button exit name before double clicking but i did after... esc key can be used to close form 
        {
            this.Close();
        }

        private void red_CheckedChanged(object sender, EventArgs e)
        {
            labelSLOGAn.ForeColor = Color.Red;
        }

        private void green_CheckedChanged(object sender, EventArgs e)
        {
            labelSLOGAn.ForeColor = Color.Green;
        }

        private void blue_CheckedChanged(object sender, EventArgs e)
        {
            labelSLOGAn.ForeColor = Color.Blue;
        }

        private void magenta_CheckedChanged(object sender, EventArgs e)
        {
            labelSLOGAn.ForeColor = Color.Magenta;
        }

        private void Showname_CheckedChanged(object sender, EventArgs e)
        {
            labelTITLe.Visible = !labelTITLe.Visible;
        }

        private void showSlogan_CheckedChanged(object sender, EventArgs e)
        {
            labelSLOGAn.Visible = !labelSLOGAn.Visible;
        }

        private void ShowLogo_CheckedChanged(object sender, EventArgs e)
        {
            cowLOGO.Visible = !cowLOGO.Visible;
        }
    }
}
