namespace Unit_10_demo
{
    public partial class Form1 : Form
    {
        List<Team> teams = new List<Team>();
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonaddteam_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox1teamanaem.Text) && !string.IsNullOrWhiteSpace(textBoxcoahch.Text))
            {
                string name = textBox1teamanaem.Text;
                string coach = textBoxcoahch.Text;
                teams.Add(new Team(name, coach));
                listBoxteams.Items.Add(name);
            }
            else
            {
                MessageBox.Show("you are an immense fialure you are bad becauseyou di dnot enter the team dataa how coudl you ever make tihs mistake? its almost like the mistake you made when you bought that house because that house you bought knda sucked so now youre just stuck with it with your family. there is no offense to your family just an offense to your decision of buyingh that house because now you have to live with it for most likely the rest of your life unless you folow the american dream of living in florida witht the great pres. trump !!!! no im just kidding but seriously polease ent ehr the team data?? why else would you not? are yuou testing me> well this message box represents this so call it good that i have created an error message. (also that house is not cool.)");
                return;
            }
            textBox1teamanaem.Clear();
            textBoxcoahch.Clear();
        }

        private void buttonaddplayer_Click(object sender, EventArgs e)
        {
            if (textBoxplayername.Text.Length > 0 && comboBoxpos.SelectedIndex > -1 && comboBoxyear.SelectedIndex > -1 && listBoxteams.SelectedIndex > -1)
            {
                Player player = new Player(textBoxplayername.Text, comboBoxpos.Text, comboBoxyear.Text);
                int teamindex = listBoxteams.SelectedIndex;
                teams[teamindex].AddPlayerAgain(player);
                textBoxplayername.Clear();
                comboBoxpos.SelectedIndex = -1;
                comboBoxyear.SelectedIndex = -1;
                listBoxplayres.Items.Add(player);
            }
            else
            {
                MessageBox.Show("TESTING MY CODE AGAIN HUH????? what did you expect to see huh? a litttle error message saying yo uahv to enter data? WRONG you re seeing this because you know why? BECAUSE I WROTE THIS! why did i write this becayse im in class and when im in class im not outside. now, now, neither are you because youre reading t his. unless you took your computer outside but i dont think that is possible because then you would have to move everytihng outside which is difficult. now, as you mostm likely mknow, i have talked about your horrible descision of buyihgn that house. oh nono no, you were about to comfort yourself that you made a finacnially rcorrect decision but even when u feel better, its always at the back of your mind. i wonder why. is it because you have to go back there to sleep every day? hmm. ok anyway. maybe you should invest in a car or a boat or even a private jet because if our society doesntn care about the climate then neither should you because yoiu know what you only live once. feeling inspired? if you are then stop. it is snack time. eat a snack. yum");
                return;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("is your house really that bad? if it isnt then good for you.", "the messages are a joke dude chill i didnt know you were that insecure");
        }

        private void listBoxteams_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxteams.SelectedIndex > -1)
            {
                listBoxplayres.Items.Clear();
                foreach (Player player in teams[listBoxteams.SelectedIndex].players)
                {
                    listBoxplayres.Items.Add(player);
                }
            }
        }
    }
}
