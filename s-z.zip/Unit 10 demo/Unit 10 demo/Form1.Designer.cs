﻿namespace Unit_10_demo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBox1teamanaem = new TextBox();
            textBoxcoahch = new TextBox();
            label2 = new Label();
            listBoxteams = new ListBox();
            label3 = new Label();
            label4 = new Label();
            comboBoxpos = new ComboBox();
            textBoxplayername = new TextBox();
            comboBoxyear = new ComboBox();
            label5 = new Label();
            listBoxplayres = new ListBox();
            buttonaddteam = new Button();
            buttonaddplayer = new Button();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(64, 73);
            label1.Name = "label1";
            label1.Size = new Size(67, 15);
            label1.TabIndex = 0;
            label1.Text = "team name";
            // 
            // textBox1teamanaem
            // 
            textBox1teamanaem.Location = new Point(192, 70);
            textBox1teamanaem.Name = "textBox1teamanaem";
            textBox1teamanaem.Size = new Size(100, 23);
            textBox1teamanaem.TabIndex = 1;
            // 
            // textBoxcoahch
            // 
            textBoxcoahch.Location = new Point(192, 99);
            textBoxcoahch.Name = "textBoxcoahch";
            textBoxcoahch.Size = new Size(100, 23);
            textBoxcoahch.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(64, 102);
            label2.Name = "label2";
            label2.Size = new Size(39, 15);
            label2.TabIndex = 2;
            label2.Text = "coach";
            // 
            // listBoxteams
            // 
            listBoxteams.FormattingEnabled = true;
            listBoxteams.ItemHeight = 15;
            listBoxteams.Location = new Point(12, 134);
            listBoxteams.Name = "listBoxteams";
            listBoxteams.Size = new Size(142, 124);
            listBoxteams.TabIndex = 4;
            listBoxteams.SelectedIndexChanged += listBoxteams_SelectedIndexChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(352, 105);
            label3.Name = "label3";
            label3.Size = new Size(26, 15);
            label3.TabIndex = 7;
            label3.Text = "pos";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(352, 76);
            label4.Name = "label4";
            label4.Size = new Size(72, 15);
            label4.TabIndex = 5;
            label4.Text = "player name";
            // 
            // comboBoxpos
            // 
            comboBoxpos.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxpos.FormattingEnabled = true;
            comboBoxpos.Items.AddRange(new object[] { "one", "two", "three", "four", "five", "six idk what" });
            comboBoxpos.Location = new Point(470, 102);
            comboBoxpos.Name = "comboBoxpos";
            comboBoxpos.Size = new Size(121, 23);
            comboBoxpos.TabIndex = 9;
            // 
            // textBoxplayername
            // 
            textBoxplayername.Location = new Point(470, 73);
            textBoxplayername.Name = "textBoxplayername";
            textBoxplayername.Size = new Size(100, 23);
            textBoxplayername.TabIndex = 8;
            // 
            // comboBoxyear
            // 
            comboBoxyear.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxyear.FormattingEnabled = true;
            comboBoxyear.Items.AddRange(new object[] { "9", "10", "11", "12" });
            comboBoxyear.Location = new Point(470, 131);
            comboBoxyear.Name = "comboBoxyear";
            comboBoxyear.Size = new Size(121, 23);
            comboBoxyear.TabIndex = 11;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(352, 134);
            label5.Name = "label5";
            label5.Size = new Size(29, 15);
            label5.TabIndex = 10;
            label5.Text = "year";
            // 
            // listBoxplayres
            // 
            listBoxplayres.FormattingEnabled = true;
            listBoxplayres.ItemHeight = 15;
            listBoxplayres.Location = new Point(352, 200);
            listBoxplayres.Name = "listBoxplayres";
            listBoxplayres.Size = new Size(138, 154);
            listBoxplayres.TabIndex = 12;
            // 
            // buttonaddteam
            // 
            buttonaddteam.Location = new Point(118, 264);
            buttonaddteam.Name = "buttonaddteam";
            buttonaddteam.Size = new Size(174, 153);
            buttonaddteam.TabIndex = 13;
            buttonaddteam.Text = "add tema";
            buttonaddteam.UseVisualStyleBackColor = true;
            buttonaddteam.Click += buttonaddteam_Click;
            // 
            // buttonaddplayer
            // 
            buttonaddplayer.Location = new Point(526, 200);
            buttonaddplayer.Name = "buttonaddplayer";
            buttonaddplayer.Size = new Size(204, 217);
            buttonaddplayer.TabIndex = 14;
            buttonaddplayer.Text = "add player";
            buttonaddplayer.UseVisualStyleBackColor = true;
            buttonaddplayer.Click += buttonaddplayer_Click;
            // 
            // button1
            // 
            button1.Location = new Point(664, 43);
            button1.Name = "button1";
            button1.Size = new Size(88, 88);
            button1.TabIndex = 15;
            button1.Text = "note!";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(buttonaddplayer);
            Controls.Add(buttonaddteam);
            Controls.Add(listBoxplayres);
            Controls.Add(comboBoxyear);
            Controls.Add(label5);
            Controls.Add(comboBoxpos);
            Controls.Add(textBoxplayername);
            Controls.Add(label3);
            Controls.Add(label4);
            Controls.Add(listBoxteams);
            Controls.Add(textBoxcoahch);
            Controls.Add(label2);
            Controls.Add(textBox1teamanaem);
            Controls.Add(label1);
            Name = "Form1";
            Text = "k";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBox1teamanaem;
        private TextBox textBoxcoahch;
        private Label label2;
        private ListBox listBoxteams;
        private Label label3;
        private Label label4;
        private ComboBox comboBoxpos;
        private TextBox textBoxplayername;
        private ComboBox comboBoxyear;
        private Label label5;
        private ListBox listBoxplayres;
        private Button buttonaddteam;
        private Button buttonaddplayer;
        private Button button1;
    }
}
