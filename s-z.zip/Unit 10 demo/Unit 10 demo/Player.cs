﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Unit_10_demo
{
    public class Player
    {
        public string PlayerName { get; set; }
        public string Position { get; set; }
        public string Year { get; set; }
        public Player(string n, string p, string y)
        {
            PlayerName = n;
            Position = p;
            Year = y;
        }
        public override string ToString()
        {
            return "name: " + PlayerName + "\n pos: " + Position + "\n year: " + Year;
        }

    }
}