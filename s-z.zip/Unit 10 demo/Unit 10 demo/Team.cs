﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Unit_10_demo
{
    public class Team
    {
        public string TeamName { get; set; }
        public string Coach { get; set; }
        public List<Player> players { get;}
        public Team(string n, string c)
        {
            players = new List<Player>();
            TeamName = n;
            Coach = c;
        }
        public void AddPlayer(string n, string p, string y)
        {
            players.Add(new Player(n, p, y));
        }
        public void AddPlayerAgain(Player player)
        {
            players.Add(player);
        }
        public Player GetPlayer(int i)
        {
            return players[i];
        }
        public void RemovePlayer(int i)
        {
            players.RemoveAt(i);
        }
        public List<Player> GetAll()
        {
            return players;
        }
        public void Read()
        {
            throw new NotImplementedException(); 
        }
        public void Write()
        {
            throw new NotImplementedException();
        }
        public override string ToString()
        {
            string what = "name: " + TeamName + "\n coach: " + Coach;
            foreach (Player player in players)
            {
                what += player.ToString() + "\n";
            }        
            return what;
        }

    }
}
