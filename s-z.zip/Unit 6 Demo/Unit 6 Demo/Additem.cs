﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Unit_6_Demo
{
    public partial class Additem : Form
    {

        //add a properee3e3eee
        public string ItemName { get; set; }
        public int Quantity { get; set; }
        public double Price { get; set; }
        public bool PressedOK { get; set; }
      





        public Additem()
        {
            InitializeComponent();
        }

        private void buttoncancel_Click(object sender, EventArgs e)
        {
            PressedOK = false;
            this.Close();

        }

        private void buttonok_Click(object sender, EventArgs e)
        {
            try
            {
                ItemName = textBoxItem.Text;
                Quantity = int.Parse(textBoxQuantity.Text);
                Price = double.Parse(textBoxPrice.Text);
                PressedOK = true;
                this.Close();

            }
            catch
            {
                PressedOK = false;
                this.Close();
            }

        }
    }
}
