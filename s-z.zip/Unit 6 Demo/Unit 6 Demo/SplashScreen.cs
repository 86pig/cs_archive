﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Unit_6_Demo
{
    public partial class SplashScreen : Form
    {
        int red, green, blue;
        Random rand = new Random();



        public SplashScreen()
        {
            InitializeComponent();

            red = rand.Next(0, 255);
            green = rand.Next(0, 255);
            blue = rand.Next(0, 255);

            this.BackColor = Color.FromArgb(red, green, blue);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.Close();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            int counter = int.Parse(labelytimewr.Text);
            counter--;
            labelytimewr.Text = counter.ToString();

            //c
            red += rand.Next(5, 25);
            green += rand.Next(5, 25);
            blue += rand.Next(5, 25);

            if (red > 255) red = red - 255;
            if (green > 255) green = green - 255;
            if (blue > 255) blue = blue - 255;

            this.BackColor = Color.FromArgb(red, green, blue);

        }
    }
}
