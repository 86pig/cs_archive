﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Unit_6_Demo
{
    public partial class Summary : Form
    {
        public int NumberOfItem { get; set; }
        public double TotalSales { get; set; }


        public Summary()
        {
            InitializeComponent();
        }

        private void buttonDone_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Summary_Activated(object sender, EventArgs e)
        {
            textBoxNumberofitems.Text = NumberOfItem.ToString();
            textBoxTotalsales.Text = TotalSales.ToString("C");
        }
    }
}
