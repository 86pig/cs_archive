namespace Unit_6_Demo
{
    public partial class Form1 : Form
    {
        //global vars
        int numberofitems = 0;
        double totalSales = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalc_Click(object sender, EventArgs e)
        {
            int quantity = int.Parse(textBoxQuantity.Text);
            double price = double.Parse(textBoxPrice.Text);

            double total = quantity * price;
            textBoxTotal.Text = total.ToString("C");

            numberofitems += quantity;
            totalSales += total;


        }

        private void buttonSummary_Click(object sender, EventArgs e)
        {
            Summary summaryDlg = new Summary();

            summaryDlg.NumberOfItem = numberofitems;
            summaryDlg.TotalSales = totalSales;

            summaryDlg.ShowDialog();

            MessageBox.Show("done with summary");
        }

        private void buttonAbout_Click(object sender, EventArgs e)
        {
            // create instance
            About aboutDlg = new About();
            //display instance
            aboutDlg.ShowDialog();
        }

        private void buttonadditem_Click(object sender, EventArgs e)
        {
            Additem itemDlg = new Additem();
            itemDlg.ShowDialog();

            //put inputs back into og form ui
            if (itemDlg.PressedOK)
            {
                textBoxItem.Text = itemDlg.ItemName;
                textBoxQuantity.Text = itemDlg.Quantity.ToString();
                textBoxPrice.Text = itemDlg.Price.ToString();

            }
            else
            {
                textBoxItem.Clear();
                textBoxQuantity.Clear();
                textBoxPrice.Clear();
                textBoxTotal.Clear();
            }

        }
    }
}
