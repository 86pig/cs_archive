namespace Unit_6_Demo
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();

            //create instance of splash screen form AAAA
            SplashScreen splashDlg = new SplashScreen();
            //display splashscreen
            splashDlg.ShowDialog();




            Application.Run(new Form1());
        }
    }
}