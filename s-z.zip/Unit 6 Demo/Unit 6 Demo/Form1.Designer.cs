﻿namespace Unit_6_Demo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBoxItem = new TextBox();
            textBoxQuantity = new TextBox();
            label2 = new Label();
            textBoxPrice = new TextBox();
            label3 = new Label();
            textBoxTotal = new TextBox();
            label4 = new Label();
            buttonCalc = new Button();
            buttonSummary = new Button();
            buttonAbout = new Button();
            buttonadditem = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(55, 79);
            label1.Name = "label1";
            label1.Size = new Size(36, 15);
            label1.TabIndex = 0;
            label1.Text = "Item\\";
            // 
            // textBoxItem
            // 
            textBoxItem.Location = new Point(135, 76);
            textBoxItem.Name = "textBoxItem";
            textBoxItem.ReadOnly = true;
            textBoxItem.Size = new Size(100, 23);
            textBoxItem.TabIndex = 1;
            // 
            // textBoxQuantity
            // 
            textBoxQuantity.Location = new Point(135, 105);
            textBoxQuantity.Name = "textBoxQuantity";
            textBoxQuantity.ReadOnly = true;
            textBoxQuantity.Size = new Size(100, 23);
            textBoxQuantity.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(55, 108);
            label2.Name = "label2";
            label2.Size = new Size(53, 15);
            label2.TabIndex = 2;
            label2.Text = "Quantity";
            // 
            // textBoxPrice
            // 
            textBoxPrice.Location = new Point(135, 134);
            textBoxPrice.Name = "textBoxPrice";
            textBoxPrice.ReadOnly = true;
            textBoxPrice.Size = new Size(100, 23);
            textBoxPrice.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(55, 137);
            label3.Name = "label3";
            label3.Size = new Size(33, 15);
            label3.TabIndex = 4;
            label3.Text = "Price";
            // 
            // textBoxTotal
            // 
            textBoxTotal.Location = new Point(135, 174);
            textBoxTotal.Name = "textBoxTotal";
            textBoxTotal.ReadOnly = true;
            textBoxTotal.Size = new Size(100, 23);
            textBoxTotal.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(55, 177);
            label4.Name = "label4";
            label4.Size = new Size(32, 15);
            label4.TabIndex = 6;
            label4.Text = "Total";
            // 
            // buttonCalc
            // 
            buttonCalc.Location = new Point(55, 217);
            buttonCalc.Name = "buttonCalc";
            buttonCalc.Size = new Size(75, 39);
            buttonCalc.TabIndex = 8;
            buttonCalc.Text = "Calc T";
            buttonCalc.UseVisualStyleBackColor = true;
            buttonCalc.Click += buttonCalc_Click;
            // 
            // buttonSummary
            // 
            buttonSummary.Location = new Point(160, 217);
            buttonSummary.Name = "buttonSummary";
            buttonSummary.Size = new Size(75, 39);
            buttonSummary.TabIndex = 9;
            buttonSummary.Text = "Summary info";
            buttonSummary.UseVisualStyleBackColor = true;
            buttonSummary.Click += buttonSummary_Click;
            // 
            // buttonAbout
            // 
            buttonAbout.Location = new Point(55, 279);
            buttonAbout.Name = "buttonAbout";
            buttonAbout.Size = new Size(180, 58);
            buttonAbout.TabIndex = 10;
            buttonAbout.Text = "About";
            buttonAbout.UseVisualStyleBackColor = true;
            buttonAbout.Click += buttonAbout_Click;
            // 
            // buttonadditem
            // 
            buttonadditem.Location = new Point(283, 78);
            buttonadditem.Name = "buttonadditem";
            buttonadditem.Size = new Size(112, 162);
            buttonadditem.TabIndex = 11;
            buttonadditem.Text = "add ittem";
            buttonadditem.UseVisualStyleBackColor = true;
            buttonadditem.Click += buttonadditem_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonadditem);
            Controls.Add(buttonAbout);
            Controls.Add(buttonSummary);
            Controls.Add(buttonCalc);
            Controls.Add(textBoxTotal);
            Controls.Add(label4);
            Controls.Add(textBoxPrice);
            Controls.Add(label3);
            Controls.Add(textBoxQuantity);
            Controls.Add(label2);
            Controls.Add(textBoxItem);
            Controls.Add(label1);
            Name = "Form1";
            Text = "unit 6 demo";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBoxItem;
        private TextBox textBoxQuantity;
        private Label label2;
        private TextBox textBoxPrice;
        private Label label3;
        private TextBox textBoxTotal;
        private Label label4;
        private Button buttonCalc;
        private Button buttonSummary;
        private Button buttonAbout;
        private Button buttonadditem;
    }
}
