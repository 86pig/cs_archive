﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WumpusUpgrades
{
    public class Upgrades
    {
        List<Upgrades> upgrades = new List<Upgrades>();
        public Upgrades()
        {
            
        }


    }
}
