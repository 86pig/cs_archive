namespace WumpusUpgrades
{
    public partial class wumpusUpgradesForm : Form
    {
        public wumpusUpgradesForm()
        {
            InitializeComponent();
        }
    }
}
