# Hunt the Wumpus 2025

Microsoft's "Hunt the Wumpus" game created in visual studio C# by nerds
