﻿namespace State_Lookup_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            radioButtonState = new RadioButton();
            radioButtonAbbr = new RadioButton();
            textBoxState = new TextBox();
            textBoxAbbr = new TextBox();
            buttonLookup = new Button();
            buttonxxx = new Button();
            SuspendLayout();
            // 
            // radioButtonState
            // 
            radioButtonState.AutoSize = true;
            radioButtonState.Location = new Point(37, 24);
            radioButtonState.Name = "radioButtonState";
            radioButtonState.Size = new Size(99, 19);
            radioButtonState.TabIndex = 0;
            radioButtonState.TabStop = true;
            radioButtonState.Text = "State/Territory";
            radioButtonState.UseVisualStyleBackColor = true;
            radioButtonState.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // radioButtonAbbr
            // 
            radioButtonAbbr.AutoSize = true;
            radioButtonAbbr.Location = new Point(201, 24);
            radioButtonAbbr.Name = "radioButtonAbbr";
            radioButtonAbbr.RightToLeft = RightToLeft.Yes;
            radioButtonAbbr.Size = new Size(93, 19);
            radioButtonAbbr.TabIndex = 1;
            radioButtonAbbr.TabStop = true;
            radioButtonAbbr.Text = "Abbreviation";
            radioButtonAbbr.UseVisualStyleBackColor = true;
            radioButtonAbbr.CheckedChanged += radioButtonAbbr_CheckedChanged;
            // 
            // textBoxState
            // 
            textBoxState.Location = new Point(37, 64);
            textBoxState.Name = "textBoxState";
            textBoxState.Size = new Size(120, 23);
            textBoxState.TabIndex = 2;
            textBoxState.TextChanged += textBoxState_TextChanged;
            // 
            // textBoxAbbr
            // 
            textBoxAbbr.Location = new Point(175, 64);
            textBoxAbbr.Name = "textBoxAbbr";
            textBoxAbbr.Size = new Size(120, 23);
            textBoxAbbr.TabIndex = 3;
            // 
            // buttonLookup
            // 
            buttonLookup.Location = new Point(37, 102);
            buttonLookup.Name = "buttonLookup";
            buttonLookup.Size = new Size(128, 98);
            buttonLookup.TabIndex = 4;
            buttonLookup.Text = "Lookup";
            buttonLookup.UseVisualStyleBackColor = true;
            buttonLookup.Click += buttonLookup_Click;
            // 
            // buttonxxx
            // 
            buttonxxx.Location = new Point(37, 206);
            buttonxxx.Name = "buttonxxx";
            buttonxxx.Size = new Size(128, 35);
            buttonxxx.TabIndex = 6;
            buttonxxx.Text = "Exit";
            buttonxxx.UseVisualStyleBackColor = true;
            buttonxxx.Click += buttonxxx_Click;
            // 
            // Form1
            // 
            AcceptButton = buttonLookup;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = buttonxxx;
            ClientSize = new Size(404, 250);
            Controls.Add(buttonxxx);
            Controls.Add(buttonLookup);
            Controls.Add(textBoxAbbr);
            Controls.Add(textBoxState);
            Controls.Add(radioButtonAbbr);
            Controls.Add(radioButtonState);
            Name = "Form1";
            Text = "US State Lookup";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RadioButton radioButtonState;
        private RadioButton radioButtonAbbr;
        private TextBox textBoxState;
        private TextBox textBoxAbbr;
        private Button buttonLookup;
        private Button buttonxxx;
    }
}
