﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
namespace State_Lookup_Derek_E7
{
    public class States
    {
        public string State { get; set; }
        public string Abbr { get; set; }


        public States(string s, string a)
        {
            State = s; 
            Abbr = a;

        }
    }
}
