using static System.Windows.Forms.AxHost;


namespace State_Lookup_Derek_E7
{
    public partial class Form1 : Form
    {
        States[] states = new States[]
        {
            new States("Alabama", "AL"),
            new States("Alaska", "AK"),
            new States("Arizona", "AZ"),
            new States("Arkansas", "AR"),
            new States("California", "CA"),
            new States("Colorado", "CO"),
            new States("Connecticut", "CT"),
            new States("Delaware", "DE"),
            new States("District of Columbia", "DC"),
            new States("Florida", "FL"),
            new States("Georgia", "GA"),
            new States("Hawaii", "HI"),
            new States("Idaho", "ID"),
            new States("Illinois", "IL"),
            new States("Indiana", "IN"),
            new States("Iowa", "IA"),
            new States("Kansas", "KS"),
            new States("Kentucky", "KY"),
            new States("Louisiana", "LA"),
            new States("Maine", "ME"),
            new States("Maryland", "MD"),
            new States("Massachusetts", "MA"),
            new States("Michigan", "MI"),
            new States("Minnesota", "MN"),
            new States("Mississippi", "MS"),
            new States("Missouri", "MO"),
            new States("Montana", "MT"),
            new States("Nebraska", "NE"),
            new States("Nevada", "NV"),
            new States("New Hampshire", "NH"),
            new States("New Jersey", "NJ"),
            new States("New Mexico", "NM"),
            new States("New York", "NY"),
            new States("North Carolina", "NC"),
            new States("North Dakota", "ND"),
            new States("Ohio", "OH"),
            new States("Oklahoma", "OK"),
            new States("Oregon", "OR"),
            new States("Pennsylvania", "PA"),
            new States("Rhode Island", "RI"),
            new States("South Carolina", "SC"),
            new States("South Dakota", "SD"),
            new States("Tennessee", "TN"),
            new States("Texas", "TX"),
            new States("Trusted Territories", "TT"),
            new States("Utah", "UT"),
            new States("Vermont", "VT"),
            new States("Virginia", "VA"),
            new States("Washington", "WA"),
            new States("West Virginia", "WV"),
            new States("Wisconsin", "WI"),
            new States("Wyoming", "WY"),
            new States("American Samoa", "AS"),
            new States("Guam", "GU"),
            new States("Northern Mariana Islands", "MP"),
            new States("Puerto Rico", "PR"),
            new States("U.S. Virgin Islands", "VI")
        };

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonxxx_Click(object sender, EventArgs e)
        {
            this
                .
                Close
                (
                )
                ;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonState.Checked == true)
            {
                textBoxState.ReadOnly = false;
                textBoxAbbr.ReadOnly = true;
                textBoxState.Focus();
            }
        }

        private void radioButtonAbbr_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonAbbr.Checked == true)
            {
                textBoxState.ReadOnly = true;
                textBoxAbbr.ReadOnly = false;
                textBoxAbbr.Focus();
            }
        }

        private void buttonLookup_Click(object sender, EventArgs e)
        {
            bool pog = false;
            if (radioButtonState.Checked == true)
            {
                for (int i = 0; i < 57; i++)
                {
                    if (textBoxState.Text.ToLower() == states[i].State.ToString().ToLower())
                    {
                        textBoxAbbr.Text = states[i].Abbr;
                        pog = true;

                    }
                }
                if (!pog)
                {
                    MessageBox.Show("State not found. Try again.", "Womop womop");
                    textBoxAbbr.Clear();
                    textBoxState.Clear();
                    if (radioButtonState.Checked == true) textBoxState.Focus();
                    if (radioButtonAbbr.Checked == true) textBoxAbbr.Focus();
                }
                
            }
            else if (radioButtonAbbr.Checked == true)
            {
                for (int i = 0; i < 57; i++)
                {
                    if (textBoxAbbr.Text.ToLower() == states[i].Abbr.ToString().ToLower()) //g
                    {
                        textBoxState.Text = states[i].State;
                        pog = true;

                    }
                }
                if (!pog)
                {
                    MessageBox.Show("State not found. Try again.", "Womop womop");
                    textBoxAbbr.Clear();
                    textBoxState.Clear();
                    if (radioButtonState.Checked == true) textBoxState.Focus();
                    if (radioButtonAbbr.Checked == true) textBoxAbbr.Focus();
                }

            }
        }

        private void textBoxState_TextChanged(object sender, EventArgs e)
        {



        }
    }
}
