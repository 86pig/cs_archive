﻿namespace Stocks_Classes_Derek_E7;

using System.Drawing.Imaging;
using Newtonsoft.Json;

public partial class Form1 : Form
{
    bool isDirty = false;
    private List<Stock> stocks = new List<Stock>();
    const string DATA_FILE = "Stocks.json";
    public Form1()
    {
        InitializeComponent();
        FileInfo fi = new FileInfo(DATA_FILE);
        if (fi.Exists)
        {
            stocks = Utility.ReadFromFile(fi.FullName).ToList();

            //listBoxPortolio.Items.AddRange(Utility.ReadFromFile(fi.FullName));
        }
        foreach (Stock stock in stocks)
        {
            listBoxPortolio.Items.Add(stock.StockName);
        }
    }


    private void buttonBuy_Click(object sender, EventArgs e)
    {
        Stock stock;
        try
        {
            stock = new Stock(textBoxName.Text, textBoxSymbol.Text, int.Parse(textBoxQuantity.Text),
                double.Parse(textBoxPrice.Text), double.Parse(textBoxPrice.Text));
        }
        catch
        {
            MessageBox.Show("WRONGGGGGGGG!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! invalid input try again.");
            return;
        }
        textBoxValue.Text = stock.MarketValue.ToString("c");
        textBoxProfit.Text = stock.Profit.ToString("C");
        textBoxProfitPercent.Text = stock.PrecentProfit.ToString("p2");
        textBoxPrice.Text = stock.Price.ToString("c");
        //textBoxlastPrice.Text = stock.LastPrice.ToString("c");

        stocks.Add(stock);
        listBoxPortolio.Items.Add(stock.StockName);
        //WriteToFile("Stocks.json", stocks);
        if (listBoxPortolio.SelectedIndex != -1)
        {
            textBoxlastPrice.ReadOnly = false;
        }
    }

    private void buttonU8pdate_Click(object sender, EventArgs e)
    {// issue: cant parse $

        if (listBoxPortolio.SelectedIndex == -1) return;
        int i = listBoxPortolio.SelectedIndex;
        try
        {
            stocks[i].StockName = textBoxName.Text;
            stocks[i].Symbol = textBoxSymbol.Text;
            stocks[i].Quantity = int.Parse(textBoxQuantity.Text);
            //  stocks[i].Price = double.Parse(textBoxPrice.Text);
            stocks[i].LastPrice = double.Parse(textBoxlastPrice.Text);
        }
        catch
        {
            MessageBox.Show("invalid input. do not include a dollar sign");
        }
        textBoxValue.Text = stocks[i].MarketValue.ToString("C");
        textBoxProfit.Text = stocks[i].Profit.ToString("C");
        textBoxProfitPercent.Text = stocks[i].PrecentProfit.ToString("p2");
        WriteToFile("Stocks.json", stocks);
        if (listBoxPortolio.SelectedIndex != -1)
        {
            textBoxlastPrice.ReadOnly = false;
        }
        else { textBoxlastPrice.ReadOnly = true; }
    }
    private void listBoxPortolio_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (listBoxPortolio.SelectedIndex == -1) return;

        int index = listBoxPortolio.SelectedIndex;
        //Stock stock = (Stock)listBoxPortolio.SelectedItem;
        textBoxName.Text = stocks[index].StockName;
        textBoxSymbol.Text = stocks[index].Symbol;
        textBoxQuantity.Text = stocks[index].Quantity.ToString();
        textBoxPrice.Text = stocks[index].Price.ToString("C");
        textBoxlastPrice.Text = stocks[index].LastPrice.ToString("C");
        textBoxValue.Text = stocks[index].MarketValue.ToString("C");
        textBoxProfit.Text = stocks[index].Profit.ToString("C");
        textBoxProfitPercent.Text = stocks[index].PrecentProfit.ToString("p2");
        textBoxlastPrice.ReadOnly = false;
        if (listBoxPortolio.SelectedIndex != -1)
        {
            textBoxlastPrice.ReadOnly = false;
        }
        else { textBoxlastPrice.ReadOnly = true; }

    }
    public static void WriteToFile(string dataFile, List<Stock> stocks)
    {
        //if (!File.Exists(dataFile)) return;
        StreamWriter writer = new StreamWriter(dataFile, false);
        JsonSerializer serializer = new JsonSerializer();
        serializer.Formatting = Formatting.Indented;
        serializer.Serialize(writer, stocks, typeof(List<Stock>));
        writer.Flush();
        writer.Close();

    }
    public static List<Stock> ReadFromFile(string dataFile)
    {
        StreamReader reader = new StreamReader(dataFile);
        JsonSerializer serializer = new JsonSerializer();
        var list = (List<Stock>)serializer.Deserialize(reader, typeof(List<Stock>));
        reader.Close();
        return list;
    }

    private void Form1_Load(object sender, EventArgs e)
    {
        stocks = ReadFromFile("Stocks.json");
        foreach (Stock stock in stocks)
        {
            listBoxPortolio.Items.Add(stock.StockName);
        }
        listBoxPortolio.SelectedIndex = -1;
    }

    private void buttonsave_Click(object sender, EventArgs e)
    {
        if (isDirty == true)
        {
            WriteToFile(DATA_FILE, stocks);
            isDirty = false;
        }
    }

    private void Form1_FormClosing(object sender, FormClosingEventArgs e)
    {
        if (isDirty == true)
        {
            DialogResult yesno = MessageBox.Show("You have unsaved changes! Do you want to save?", "Alert", MessageBoxButtons.YesNo);
            if (yesno == DialogResult.Yes)
            {
                WriteToFile(DATA_FILE, stocks);
                isDirty = false;
            }

        }
    }
}