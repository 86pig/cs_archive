﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;


namespace Stocks_Classes_Derek_E7
{
    public class Stock
    {
        public Stock()
        {
            StockName = string.Empty;
        }

        public Stock(string n, string s, int q, double p, double lp)
        {
            StockName = n;
            Symbol = s;
            Quantity = q;
            Price = p;
            LastPrice = lp;
        }
        public string StockName { get; set; }
        public string Symbol { get; set; }
        public int Quantity { get; set; }
        public double Price { get; set; }
        public double LastPrice { get; set; }

        public double MarketValue
        {
            get
            {
                return GetMarketValue();
            }
        }
        public double Profit
        {
            get
            {
                return GetProfit();
            }
        }
        public double PrecentProfit
        {
            get
            {
                return GetPercentProfit();
            }
        }

        public double GetMarketValue()
        {
            return Quantity * LastPrice;
        }
        public double GetProfit()
        {
            return (Quantity * LastPrice) - (Quantity * Price);
        }
        public double GetPercentProfit()
        {
            return ((Quantity * LastPrice) - (Quantity * Price)) / (Quantity * Price);
        }
        //brok









    }
}
