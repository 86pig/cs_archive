﻿namespace Stocks_Classes_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBoxName = new TextBox();
            textBoxSymbol = new TextBox();
            label2 = new Label();
            textBoxQuantity = new TextBox();
            label3 = new Label();
            textBoxPrice = new TextBox();
            label4 = new Label();
            textBoxlastPrice = new TextBox();
            label5 = new Label();
            textBoxValue = new TextBox();
            label6 = new Label();
            textBoxProfit = new TextBox();
            label7 = new Label();
            textBoxProfitPercent = new TextBox();
            label8 = new Label();
            listBoxPortolio = new ListBox();
            buttonBuy = new Button();
            buttonU8pdate = new Button();
            label9 = new Label();
            buttonsave = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(28, 56);
            label1.Name = "label1";
            label1.Size = new Size(59, 15);
            label1.TabIndex = 0;
            label1.Text = "Company";
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(125, 53);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(100, 23);
            textBoxName.TabIndex = 1;
            // 
            // textBoxSymbol
            // 
            textBoxSymbol.Location = new Point(125, 82);
            textBoxSymbol.Name = "textBoxSymbol";
            textBoxSymbol.Size = new Size(100, 23);
            textBoxSymbol.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(28, 85);
            label2.Name = "label2";
            label2.Size = new Size(47, 15);
            label2.TabIndex = 2;
            label2.Text = "Symbol";
            // 
            // textBoxQuantity
            // 
            textBoxQuantity.Location = new Point(125, 111);
            textBoxQuantity.Name = "textBoxQuantity";
            textBoxQuantity.Size = new Size(100, 23);
            textBoxQuantity.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(28, 114);
            label3.Name = "label3";
            label3.Size = new Size(53, 15);
            label3.TabIndex = 4;
            label3.Text = "Quantity";
            // 
            // textBoxPrice
            // 
            textBoxPrice.Location = new Point(125, 140);
            textBoxPrice.Name = "textBoxPrice";
            textBoxPrice.Size = new Size(100, 23);
            textBoxPrice.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(28, 143);
            label4.Name = "label4";
            label4.Size = new Size(33, 15);
            label4.TabIndex = 6;
            label4.Text = "Price";
            // 
            // textBoxlastPrice
            // 
            textBoxlastPrice.Location = new Point(125, 169);
            textBoxlastPrice.Name = "textBoxlastPrice";
            textBoxlastPrice.ReadOnly = true;
            textBoxlastPrice.Size = new Size(100, 23);
            textBoxlastPrice.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(28, 172);
            label5.Name = "label5";
            label5.Size = new Size(57, 15);
            label5.TabIndex = 8;
            label5.Text = "Last price";
            // 
            // textBoxValue
            // 
            textBoxValue.Location = new Point(125, 220);
            textBoxValue.Name = "textBoxValue";
            textBoxValue.ReadOnly = true;
            textBoxValue.Size = new Size(100, 23);
            textBoxValue.TabIndex = 11;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(28, 223);
            label6.Name = "label6";
            label6.Size = new Size(35, 15);
            label6.TabIndex = 10;
            label6.Text = "Value";
            // 
            // textBoxProfit
            // 
            textBoxProfit.Location = new Point(125, 249);
            textBoxProfit.Name = "textBoxProfit";
            textBoxProfit.ReadOnly = true;
            textBoxProfit.Size = new Size(100, 23);
            textBoxProfit.TabIndex = 13;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(28, 252);
            label7.Name = "label7";
            label7.Size = new Size(36, 15);
            label7.TabIndex = 12;
            label7.Text = "Profit";
            // 
            // textBoxProfitPercent
            // 
            textBoxProfitPercent.Location = new Point(125, 278);
            textBoxProfitPercent.Name = "textBoxProfitPercent";
            textBoxProfitPercent.ReadOnly = true;
            textBoxProfitPercent.Size = new Size(100, 23);
            textBoxProfitPercent.TabIndex = 15;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(28, 281);
            label8.Name = "label8";
            label8.Size = new Size(49, 15);
            label8.TabIndex = 14;
            label8.Text = "Profit %";
            // 
            // listBoxPortolio
            // 
            listBoxPortolio.FormattingEnabled = true;
            listBoxPortolio.ItemHeight = 15;
            listBoxPortolio.Location = new Point(275, 177);
            listBoxPortolio.Name = "listBoxPortolio";
            listBoxPortolio.Size = new Size(228, 124);
            listBoxPortolio.TabIndex = 16;
            listBoxPortolio.SelectedIndexChanged += listBoxPortolio_SelectedIndexChanged;
            // 
            // buttonBuy
            // 
            buttonBuy.Location = new Point(275, 56);
            buttonBuy.Name = "buttonBuy";
            buttonBuy.Size = new Size(228, 49);
            buttonBuy.TabIndex = 17;
            buttonBuy.Text = "Buy stock";
            buttonBuy.UseVisualStyleBackColor = true;
            buttonBuy.Click += buttonBuy_Click;
            // 
            // buttonU8pdate
            // 
            buttonU8pdate.Location = new Point(275, 109);
            buttonU8pdate.Name = "buttonU8pdate";
            buttonU8pdate.Size = new Size(228, 49);
            buttonU8pdate.TabIndex = 18;
            buttonU8pdate.Text = "Update stock value";
            buttonU8pdate.UseVisualStyleBackColor = true;
            buttonU8pdate.Click += buttonU8pdate_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 19F);
            label9.Location = new Point(28, 9);
            label9.Name = "label9";
            label9.Size = new Size(598, 36);
            label9.TabIndex = 19;
            label9.Text = "auuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu";
            // 
            // buttonsave
            // 
            buttonsave.Location = new Point(275, 307);
            buttonsave.Name = "buttonsave";
            buttonsave.Size = new Size(228, 28);
            buttonsave.TabIndex = 20;
            buttonsave.Text = "save";
            buttonsave.UseVisualStyleBackColor = true;
            buttonsave.Click += buttonsave_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(536, 367);
            Controls.Add(buttonsave);
            Controls.Add(label9);
            Controls.Add(buttonU8pdate);
            Controls.Add(buttonBuy);
            Controls.Add(listBoxPortolio);
            Controls.Add(textBoxProfitPercent);
            Controls.Add(label8);
            Controls.Add(textBoxProfit);
            Controls.Add(label7);
            Controls.Add(textBoxValue);
            Controls.Add(label6);
            Controls.Add(textBoxlastPrice);
            Controls.Add(label5);
            Controls.Add(textBoxPrice);
            Controls.Add(label4);
            Controls.Add(textBoxQuantity);
            Controls.Add(label3);
            Controls.Add(textBoxSymbol);
            Controls.Add(label2);
            Controls.Add(textBoxName);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Stocks";
            FormClosing += Form1_FormClosing;
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBoxName;
        private TextBox textBoxSymbol;
        private Label label2;
        private TextBox textBoxQuantity;
        private Label label3;
        private TextBox textBoxPrice;
        private Label label4;
        private TextBox textBoxlastPrice;
        private Label label5;
        private TextBox textBoxValue;
        private Label label6;
        private TextBox textBoxProfit;
        private Label label7;
        private TextBox textBoxProfitPercent;
        private Label label8;
        private ListBox listBoxPortolio;
        private Button buttonBuy;
        private Button buttonU8pdate;
        private Label label9;
        private Button buttonsave;
    }
}
