﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Stocks_Classes_Derek_E7
{
    internal class Utility
    {
        //public bool IsDirty { get; set; }


        private static JsonSerializer serializer = new JsonSerializer();
        public static void WriteToFile(Stock[] stocks, string filename)
        {
            JsonSerializer serializer = new JsonSerializer();
            StreamWriter sr = new StreamWriter(filename);
            serializer.Serialize(sr, stocks, typeof(Stock[]));
            sr.Flush();
            sr.Close();

}// this is the return  v
        public static Stock[] ReadFromFile(string filename)
        {
            StreamReader sr = new StreamReader(filename);
            var stocks = (Stock[])serializer.Deserialize(sr, typeof(Stock[]));
            sr.Close ();
            if (stocks == null)
            {
                return new Stock[10];
            }
            Stock[] stock = (Stock[])stocks;
            return stock;
        }
    }
}
