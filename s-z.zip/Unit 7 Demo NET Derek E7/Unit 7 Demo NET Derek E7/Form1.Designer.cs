﻿namespace Unit_7_Demo_NET_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.listBoxStudents = new System.Windows.Forms.ListBox();
            this.labelStudent = new System.Windows.Forms.Label();
            this.labelIndex = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.buttonpoof = new System.Windows.Forms.Button();
            this.buttonpRIng = new System.Windows.Forms.Button();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.comboBoxschools = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonshcllls = new System.Windows.Forms.Button();
            this.printDocument2 = new System.Drawing.Printing.PrintDocument();
            this.buttonocmbo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(61, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Students";
            // 
            // listBoxStudents
            // 
            this.listBoxStudents.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.listBoxStudents.FormattingEnabled = true;
            this.listBoxStudents.ItemHeight = 25;
            this.listBoxStudents.Items.AddRange(new object[] {
            "Student one",
            "Student two",
            "Student three",
            "Student four",
            "Student five",
            "Student six",
            "Student seven",
            "Student eight"});
            this.listBoxStudents.Location = new System.Drawing.Point(66, 107);
            this.listBoxStudents.Name = "listBoxStudents";
            this.listBoxStudents.Size = new System.Drawing.Size(162, 129);
            this.listBoxStudents.TabIndex = 2;
            this.listBoxStudents.SelectedIndexChanged += new System.EventHandler(this.listBoxStudents_SelectedIndexChanged);
            // 
            // labelStudent
            // 
            this.labelStudent.AutoSize = true;
            this.labelStudent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStudent.Location = new System.Drawing.Point(234, 93);
            this.labelStudent.Name = "labelStudent";
            this.labelStudent.Size = new System.Drawing.Size(66, 20);
            this.labelStudent.TabIndex = 3;
            this.labelStudent.Text = "Student";
            // 
            // labelIndex
            // 
            this.labelIndex.AutoSize = true;
            this.labelIndex.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIndex.Location = new System.Drawing.Point(234, 137);
            this.labelIndex.Name = "labelIndex";
            this.labelIndex.Size = new System.Drawing.Size(48, 20);
            this.labelIndex.TabIndex = 4;
            this.labelIndex.Text = "Index";
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName.Location = new System.Drawing.Point(61, 277);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(68, 25);
            this.labelName.TabIndex = 5;
            this.labelName.Text = "Name";
            // 
            // textBoxName
            // 
            this.textBoxName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.textBoxName.Location = new System.Drawing.Point(174, 275);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(158, 29);
            this.textBoxName.TabIndex = 6;
            // 
            // buttonAdd
            // 
            this.buttonAdd.Location = new System.Drawing.Point(75, 349);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(288, 74);
            this.buttonAdd.TabIndex = 7;
            this.buttonAdd.Text = "ADd to lsit";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // buttonpoof
            // 
            this.buttonpoof.Location = new System.Drawing.Point(379, 285);
            this.buttonpoof.Name = "buttonpoof";
            this.buttonpoof.Size = new System.Drawing.Size(80, 137);
            this.buttonpoof.TabIndex = 8;
            this.buttonpoof.Text = "remove sleected itme";
            this.buttonpoof.UseVisualStyleBackColor = true;
            this.buttonpoof.Click += new System.EventHandler(this.buttonpoof_Click);
            // 
            // buttonpRIng
            // 
            this.buttonpRIng.Location = new System.Drawing.Point(325, 156);
            this.buttonpRIng.Name = "buttonpRIng";
            this.buttonpRIng.Size = new System.Drawing.Size(148, 77);
            this.buttonpRIng.TabIndex = 9;
            this.buttonpRIng.Text = "Print student list";
            this.buttonpRIng.UseVisualStyleBackColor = true;
            this.buttonpRIng.Click += new System.EventHandler(this.buttonpRIng_Click);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // comboBoxschools
            // 
            this.comboBoxschools.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxschools.FormattingEnabled = true;
            this.comboBoxschools.Items.AddRange(new object[] {
            "SCool one",
            "U of T",
            "UCLA",
            "MIT",
            "STANFORD",
            "USC",
            "CU",
            "UW",
            "PU",
            "ACHJO",
            "kk"});
            this.comboBoxschools.Location = new System.Drawing.Point(324, 27);
            this.comboBoxschools.Name = "comboBoxschools";
            this.comboBoxschools.Size = new System.Drawing.Size(148, 24);
            this.comboBoxschools.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(189, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 25);
            this.label2.TabIndex = 11;
            this.label2.Text = "shcosoosls";
            // 
            // buttonshcllls
            // 
            this.buttonshcllls.Location = new System.Drawing.Point(324, 73);
            this.buttonshcllls.Name = "buttonshcllls";
            this.buttonshcllls.Size = new System.Drawing.Size(148, 77);
            this.buttonshcllls.TabIndex = 12;
            this.buttonshcllls.Text = "print shcoollist";
            this.buttonshcllls.UseVisualStyleBackColor = true;
            this.buttonshcllls.Click += new System.EventHandler(this.buttonshcllls_Click);
            // 
            // printDocument2
            // 
            this.printDocument2.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument2_PrintPage);
            // 
            // buttonocmbo
            // 
            this.buttonocmbo.Location = new System.Drawing.Point(347, 247);
            this.buttonocmbo.Name = "buttonocmbo";
            this.buttonocmbo.Size = new System.Drawing.Size(111, 18);
            this.buttonocmbo.TabIndex = 13;
            this.buttonocmbo.Text = "Add to ocmobo";
            this.buttonocmbo.UseVisualStyleBackColor = true;
            this.buttonocmbo.Click += new System.EventHandler(this.buttonocmbo_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(498, 450);
            this.Controls.Add(this.buttonocmbo);
            this.Controls.Add(this.buttonshcllls);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBoxschools);
            this.Controls.Add(this.buttonpRIng);
            this.Controls.Add(this.buttonpoof);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.textBoxName);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.labelIndex);
            this.Controls.Add(this.labelStudent);
            this.Controls.Add(this.listBoxStudents);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Demo: sutdnerts";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBoxStudents;
        private System.Windows.Forms.Label labelStudent;
        private System.Windows.Forms.Label labelIndex;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button buttonpoof;
        private System.Windows.Forms.Button buttonpRIng;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.ComboBox comboBoxschools;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonshcllls;
        private System.Drawing.Printing.PrintDocument printDocument2;
        private System.Windows.Forms.Button buttonocmbo;
    }
}

