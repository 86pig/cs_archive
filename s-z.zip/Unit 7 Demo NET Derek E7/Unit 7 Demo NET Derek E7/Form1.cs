﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Unit_7_Demo_NET_Derek_E7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBoxStudents_SelectedIndexChanged(object sender, EventArgs e)
        {
            //get selected index value
            int index = listBoxStudents.SelectedIndex;

            if (index != -1)
            {
                //display indxe vlaue
                labelIndex.Text = index.ToString();

                //get name from list
                //use square bracketsr to find elememntn
                labelStudent.Text = listBoxStudents.Items[index].ToString();




            }

            //that stuff in the if statement was here befroe, however ther eas an errror with the remove functiuon



        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            //bool var to check if student is int he list
            bool inlist = false;

            string name = textBoxName.Text;

            // add lope to compare names to the student in the lsit 
            foreach(string student in listBoxStudents.Items)
            {
                //check if names mathc
                if (name.ToLower() == student.ToLower())
                {
                    //if match: AYAY but DONT adsd to list !!    
                    inlist = true;
                    break; //break from loop euh duh 
                    
                }



            }
            textBoxName.Clear();
            //fi student not in list: add them bruh
            if (!inlist)
            {
                listBoxStudents.Items.Add(name);



            }
           // add new student to the lsitbox
            //the ting in the most reccetn if block was her ebefore, however the check msesses it up !! achoo!!

        }

        private void buttonpoof_Click(object sender, EventArgs e)
        {
            if (listBoxStudents.SelectedIndex != -1)
            {
                //remove
                listBoxStudents.Items.RemoveAt(listBoxStudents.SelectedIndex);

                //clear label
                labelIndex.Text = "Index";
                labelStudent.Text = "Student";

            }
           else
            {
                MessageBox.Show("select studnt furst gya");
            }
        }

        private void buttonpRIng_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            // Print a list of all current courses.
            Font printFont = new Font("Arial", 10);
            Font headingFont = new Font("Arial", 14, FontStyle.Bold);
            float verticalPrintPositionFloat = e.MarginBounds.Top;
            float horizontalPrintPositionFloat = e.MarginBounds.Left;
            float lineHeightFloat = printFont.GetHeight();

            // Print heading.
            e.Graphics.DrawString("curresnst studen tlist: ",
            headingFont,
            Brushes.SaddleBrown, horizontalPrintPositionFloat,
            verticalPrintPositionFloat);

            verticalPrintPositionFloat += 2 * lineHeightFloat;

            foreach(String student in listBoxStudents.Items)
            {
                e.Graphics.DrawString(student, printFont, Brushes.DarkGoldenrod, horizontalPrintPositionFloat, verticalPrintPositionFloat);

                verticalPrintPositionFloat += 2 * lineHeightFloat;


            }




        }

        private void buttonshcllls_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void printDocument2_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            // Print a list of all current courses.
            Font printFont = new Font("Arial", 10);
            Font headingFont = new Font("Arial", 14, FontStyle.Bold);
            float verticalPrintPositionFloat = e.MarginBounds.Top;
            float horizontalPrintPositionFloat = e.MarginBounds.Left;
            float lineHeightFloat = printFont.GetHeight();

            // Print heading.
            e.Graphics.DrawString("shcool sitlsit lsitt: ",
            headingFont,
            Brushes.DarkGoldenrod, horizontalPrintPositionFloat,
            verticalPrintPositionFloat);

            verticalPrintPositionFloat += 2 * lineHeightFloat;

            foreach (String school in comboBoxschools.Items)
            {
                e.Graphics.DrawString(school, printFont, Brushes.DarkGoldenrod, horizontalPrintPositionFloat, verticalPrintPositionFloat);

                verticalPrintPositionFloat += 2 * lineHeightFloat;


            }

            foreach (String school in comboBoxschools.Items)
            {
                // Print heading.
                e.Graphics.DrawString("school lsit: ",
                headingFont,
                Brushes.OliveDrab, horizontalPrintPositionFloat,
                verticalPrintPositionFloat);

                verticalPrintPositionFloat += 2 * lineHeightFloat;

            }



        }

        private void buttonocmbo_Click(object sender, EventArgs e)
        {
            //bool var to check if student is int he list
            bool inlist = false;

            string name = comboBoxschools.Text;

            // add lope to compare names to the student in the lsit 
            foreach (string school in comboBoxschools.Items)
            {
                //check if names mathc
                if (name.ToLower() == school.ToLower())
                {
                    //if match: AYAY but DONT adsd to list !!    
                    inlist = true;
                    break; //break from loop euh duh 

                }



            }
            textBoxName.Clear();
            //fi student not in list: add them bruh
            if (!inlist)
            {
                comboBoxschools.Items.Add(name);



            }
            // add new student to the lsitbox
            //the ting in the most reccetn if bloc


            comboBoxschools.Text = "";
        }
    }
}
