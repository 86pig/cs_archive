﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;

namespace Repair_Job_Derek_E7
{
    public partial class Splashscreen : Form
    {
        int red, green, blue;
        Random rand = new Random();

        const int numbare = 1;
        int s = 0;
        public Splashscreen()
        {
            InitializeComponent();
            

            
            
        }

        private void Splashscreen_Load(object sender, EventArgs e)
        {

            
        }

        private void timerSplash_Tick(object sender, EventArgs e)
        {
            s++;
            red += rand.Next(5, 25);
            green += rand.Next(5, 25);
            blue += rand.Next(5, 25);

            if (red > 255) red = red - 255;
            if (green > 255) green = green - 255;
            if (blue > 255) blue = blue - 255;

            progressBar1.ForeColor = Color.FromArgb(red, green, blue);


            progressBar1.Maximum = 10000;
            progressBar1.Step = 2;
            progressBar1.PerformStep();
            //if (progressBar1.Value == 50) progressBar1.Value = 31;

           // if (progressBar1.Value > 100) 
            this.Close();

            //I gave up on the progress bar D:
        }
    }
}
