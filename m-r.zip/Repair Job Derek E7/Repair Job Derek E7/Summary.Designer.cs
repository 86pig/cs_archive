﻿namespace Repair_Job_Derek_E7
{
    partial class Summary
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBoxTotalpartscost = new TextBox();
            textBoxTotallabourcost = new TextBox();
            label2 = new Label();
            textBoxTotalsalestax = new TextBox();
            label3 = new Label();
            textBoxTotalsales = new TextBox();
            label4 = new Label();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F);
            label1.Location = new Point(30, 36);
            label1.Name = "label1";
            label1.Size = new Size(113, 21);
            label1.TabIndex = 0;
            label1.Text = "Total parts cost";
            // 
            // textBoxTotalpartscost
            // 
            textBoxTotalpartscost.Location = new Point(178, 38);
            textBoxTotalpartscost.Name = "textBoxTotalpartscost";
            textBoxTotalpartscost.ReadOnly = true;
            textBoxTotalpartscost.Size = new Size(128, 23);
            textBoxTotalpartscost.TabIndex = 1;
            // 
            // textBoxTotallabourcost
            // 
            textBoxTotallabourcost.Location = new Point(178, 67);
            textBoxTotallabourcost.Name = "textBoxTotallabourcost";
            textBoxTotallabourcost.ReadOnly = true;
            textBoxTotallabourcost.Size = new Size(128, 23);
            textBoxTotallabourcost.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F);
            label2.Location = new Point(30, 65);
            label2.Name = "label2";
            label2.Size = new Size(123, 21);
            label2.TabIndex = 2;
            label2.Text = "Total labour cost";
            // 
            // textBoxTotalsalestax
            // 
            textBoxTotalsalestax.Location = new Point(178, 96);
            textBoxTotalsalestax.Name = "textBoxTotalsalestax";
            textBoxTotalsalestax.ReadOnly = true;
            textBoxTotalsalestax.Size = new Size(128, 23);
            textBoxTotalsalestax.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F);
            label3.Location = new Point(30, 94);
            label3.Name = "label3";
            label3.Size = new Size(104, 21);
            label3.TabIndex = 4;
            label3.Text = "Total sales tax";
            // 
            // textBoxTotalsales
            // 
            textBoxTotalsales.Location = new Point(178, 125);
            textBoxTotalsales.Name = "textBoxTotalsales";
            textBoxTotalsales.ReadOnly = true;
            textBoxTotalsales.Size = new Size(128, 23);
            textBoxTotalsales.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F);
            label4.Location = new Point(30, 123);
            label4.Name = "label4";
            label4.Size = new Size(80, 21);
            label4.TabIndex = 6;
            label4.Text = "Total sales";
            // 
            // button1
            // 
            button1.Location = new Point(338, 36);
            button1.Name = "button1";
            button1.Size = new Size(154, 112);
            button1.TabIndex = 8;
            button1.Text = "Done";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Summary
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(524, 184);
            ControlBox = false;
            Controls.Add(button1);
            Controls.Add(textBoxTotalsales);
            Controls.Add(label4);
            Controls.Add(textBoxTotalsalestax);
            Controls.Add(label3);
            Controls.Add(textBoxTotallabourcost);
            Controls.Add(label2);
            Controls.Add(textBoxTotalpartscost);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "Summary";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Summary";
            Load += Summary_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBoxTotalpartscost;
        private TextBox textBoxTotallabourcost;
        private Label label2;
        private TextBox textBoxTotalsalestax;
        private Label label3;
        private TextBox textBoxTotalsales;
        private Label label4;
        private Button button1;
    }
}