﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Repair_Job_Derek_E7
{
    public partial class Summary : Form
    {
        public double PartTotal { get; set; }
        public double LabourTotal { get; set; }
        public double TaxTotal { get; set; }
        public double SalesTotal { get; set; }




        public Summary()
        {
            InitializeComponent();

            textBoxTotalpartscost.Text = PartTotal.ToString("C");
            textBoxTotallabourcost.Text = LabourTotal.ToString("C");
            textBoxTotalsalestax.Text = TaxTotal.ToString("C");
            textBoxTotalsales.Text = SalesTotal.ToString("C");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Summary_Load(object sender, EventArgs e)
        {
            textBoxTotalpartscost.Text = PartTotal.ToString("C");
            textBoxTotallabourcost.Text = LabourTotal.ToString("C");
            textBoxTotalsalestax.Text = TaxTotal.ToString("C");
            textBoxTotalsales.Text = SalesTotal.ToString("C");
        }
    }
}
