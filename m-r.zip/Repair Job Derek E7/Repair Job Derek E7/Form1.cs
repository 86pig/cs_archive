namespace Repair_Job_Derek_E7
{
    public partial class Form1 : Form
    {
        const double HOURLYWAGE = 50;
        const double TAXRATE = 0.08;

        double partTotal;
        double labourTotal;
        double taxTotal;
        double salesTotal;



        public Form1()
        {
            InitializeComponent();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBOx aboutDlg = new AboutBOx();
            aboutDlg.ShowDialog();
        }

        private void clarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBoxPartsCost.Clear();
            textBoxLabourhours.Clear();
            textBoxSubtotal.Clear();
            textBoxsalestax.Clear();
            textBoxTotaldue.Clear();
            textBoxPartsCost.Focus();
        }

        private void calculateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                double total = 0;
                double parts = double.Parse(textBoxPartsCost.Text);
                double labour = double.Parse(textBoxLabourhours.Text);

                total += parts;
                total += labour * HOURLYWAGE;
                double tax = parts * TAXRATE;
                total += tax;
                double subtotal = total - tax;

                partTotal += parts;
                labourTotal += labour * HOURLYWAGE;
                taxTotal += tax;
                salesTotal += total;

                textBoxsalestax.Text = tax.ToString("C");
                textBoxSubtotal.Text = subtotal.ToString("C");
                textBoxTotaldue.Text = total.ToString("C");
            }

            catch
            {
                MessageBox.Show("Invalid input. Try again.");
            }

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void summaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Summary summaryDlg = new Summary();

            summaryDlg.PartTotal = partTotal;
            summaryDlg.LabourTotal = labourTotal;
            summaryDlg.TaxTotal = taxTotal;
            summaryDlg.SalesTotal = salesTotal;
            summaryDlg.ShowDialog();


        }
    }
}
