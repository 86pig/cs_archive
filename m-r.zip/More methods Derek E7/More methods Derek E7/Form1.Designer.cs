﻿namespace More_methods_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            parrotsToolStripMenuItem = new ToolStripMenuItem();
            intsBigToolStripMenuItem = new ToolStripMenuItem();
            intsToolStripMenuItem = new ToolStripMenuItem();
            stringToolStripMenuItem = new ToolStripMenuItem();
            strings2ToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem1 = new ToolStripSeparator();
            exitToolStripMenuItem = new ToolStripMenuItem();
            helpToolStripMenuItem = new ToolStripMenuItem();
            aboutToolStripMenuItem = new ToolStripMenuItem();
            groupBox1 = new GroupBox();
            textBoxTrouble = new TextBox();
            label2 = new Label();
            textBoxHourODay = new TextBox();
            label1 = new Label();
            groupBox2 = new GroupBox();
            textBoxInrange = new TextBox();
            label9 = new Label();
            textBoxOtherSecondInt = new TextBox();
            label8 = new Label();
            textBoxOtherFirstInt = new TextBox();
            label7 = new Label();
            textBoxBiggestint = new TextBox();
            label6 = new Label();
            textBoxThirdint = new TextBox();
            label5 = new Label();
            textBoxSecondint = new TextBox();
            label4 = new Label();
            textBoxFirstint = new TextBox();
            label3 = new Label();
            groupBox3 = new GroupBox();
            textBoxModdedstr = new TextBox();
            label11 = new Label();
            textBoxString = new TextBox();
            label10 = new Label();
            menuStrip1.SuspendLayout();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem, helpToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(286, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { parrotsToolStripMenuItem, intsBigToolStripMenuItem, intsToolStripMenuItem, stringToolStripMenuItem, strings2ToolStripMenuItem, toolStripMenuItem1, exitToolStripMenuItem });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(37, 20);
            fileToolStripMenuItem.Text = "&File";
            // 
            // parrotsToolStripMenuItem
            // 
            parrotsToolStripMenuItem.Name = "parrotsToolStripMenuItem";
            parrotsToolStripMenuItem.Size = new Size(180, 22);
            parrotsToolStripMenuItem.Text = "&Parrots";
            parrotsToolStripMenuItem.Click += parrotsToolStripMenuItem_Click;
            // 
            // intsBigToolStripMenuItem
            // 
            intsBigToolStripMenuItem.Name = "intsBigToolStripMenuItem";
            intsBigToolStripMenuItem.Size = new Size(180, 22);
            intsBigToolStripMenuItem.Text = "Ints &big";
            intsBigToolStripMenuItem.Click += intsBigToolStripMenuItem_Click;
            // 
            // intsToolStripMenuItem
            // 
            intsToolStripMenuItem.Name = "intsToolStripMenuItem";
            intsToolStripMenuItem.Size = new Size(180, 22);
            intsToolStripMenuItem.Text = "Ints &range";
            intsToolStripMenuItem.Click += intsToolStripMenuItem_Click;
            // 
            // stringToolStripMenuItem
            // 
            stringToolStripMenuItem.Name = "stringToolStripMenuItem";
            stringToolStripMenuItem.Size = new Size(180, 22);
            stringToolStripMenuItem.Text = "&Strings";
            stringToolStripMenuItem.Click += stringToolStripMenuItem_Click;
            // 
            // strings2ToolStripMenuItem
            // 
            strings2ToolStripMenuItem.Name = "strings2ToolStripMenuItem";
            strings2ToolStripMenuItem.Size = new Size(180, 22);
            strings2ToolStripMenuItem.Text = "Strings 2";
            strings2ToolStripMenuItem.Click += strings2ToolStripMenuItem_Click;
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(177, 6);
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(180, 22);
            exitToolStripMenuItem.Text = "E&xit";
            exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;
            // 
            // helpToolStripMenuItem
            // 
            helpToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { aboutToolStripMenuItem });
            helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            helpToolStripMenuItem.Size = new Size(44, 20);
            helpToolStripMenuItem.Text = "&Help";
            // 
            // aboutToolStripMenuItem
            // 
            aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            aboutToolStripMenuItem.Size = new Size(107, 22);
            aboutToolStripMenuItem.Text = "&About";
            aboutToolStripMenuItem.Click += aboutToolStripMenuItem_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBoxTrouble);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(textBoxHourODay);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(8, 49);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(250, 88);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Parrot";
            // 
            // textBoxTrouble
            // 
            textBoxTrouble.Location = new Point(123, 44);
            textBoxTrouble.Name = "textBoxTrouble";
            textBoxTrouble.Size = new Size(100, 23);
            textBoxTrouble.TabIndex = 6;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F);
            label2.Location = new Point(4, 48);
            label2.Name = "label2";
            label2.Size = new Size(60, 19);
            label2.TabIndex = 5;
            label2.Text = "Trouble?";
            // 
            // textBoxHourODay
            // 
            textBoxHourODay.Location = new Point(123, 15);
            textBoxHourODay.Name = "textBoxHourODay";
            textBoxHourODay.Size = new Size(100, 23);
            textBoxHourODay.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F);
            label1.Location = new Point(4, 19);
            label1.Name = "label1";
            label1.Size = new Size(84, 19);
            label1.TabIndex = 3;
            label1.Text = "Hour o' day:";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(textBoxInrange);
            groupBox2.Controls.Add(label9);
            groupBox2.Controls.Add(textBoxOtherSecondInt);
            groupBox2.Controls.Add(label8);
            groupBox2.Controls.Add(textBoxOtherFirstInt);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(textBoxBiggestint);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(textBoxThirdint);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(textBoxSecondint);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(textBoxFirstint);
            groupBox2.Controls.Add(label3);
            groupBox2.Location = new Point(8, 143);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(250, 300);
            groupBox2.TabIndex = 2;
            groupBox2.TabStop = false;
            groupBox2.Text = "Ints";
            // 
            // textBoxInrange
            // 
            textBoxInrange.Location = new Point(125, 250);
            textBoxInrange.Name = "textBoxInrange";
            textBoxInrange.Size = new Size(100, 23);
            textBoxInrange.TabIndex = 20;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 10F);
            label9.Location = new Point(4, 251);
            label9.Name = "label9";
            label9.Size = new Size(66, 19);
            label9.TabIndex = 19;
            label9.Text = "In range?";
            // 
            // textBoxOtherSecondInt
            // 
            textBoxOtherSecondInt.Location = new Point(125, 200);
            textBoxOtherSecondInt.Name = "textBoxOtherSecondInt";
            textBoxOtherSecondInt.Size = new Size(100, 23);
            textBoxOtherSecondInt.TabIndex = 18;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 10F);
            label8.Location = new Point(6, 204);
            label8.Name = "label8";
            label8.Size = new Size(112, 19);
            label8.TabIndex = 17;
            label8.Text = "Other second int";
            // 
            // textBoxOtherFirstInt
            // 
            textBoxOtherFirstInt.Location = new Point(125, 171);
            textBoxOtherFirstInt.Name = "textBoxOtherFirstInt";
            textBoxOtherFirstInt.Size = new Size(100, 23);
            textBoxOtherFirstInt.TabIndex = 16;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 10F);
            label7.Location = new Point(6, 175);
            label7.Name = "label7";
            label7.Size = new Size(92, 19);
            label7.TabIndex = 15;
            label7.Text = "Other first int";
            // 
            // textBoxBiggestint
            // 
            textBoxBiggestint.Location = new Point(125, 123);
            textBoxBiggestint.Name = "textBoxBiggestint";
            textBoxBiggestint.Size = new Size(100, 23);
            textBoxBiggestint.TabIndex = 14;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 10F);
            label6.Location = new Point(4, 124);
            label6.Name = "label6";
            label6.Size = new Size(100, 19);
            label6.TabIndex = 13;
            label6.Text = "The biggest int";
            // 
            // textBoxThirdint
            // 
            textBoxThirdint.Location = new Point(125, 77);
            textBoxThirdint.Name = "textBoxThirdint";
            textBoxThirdint.Size = new Size(100, 23);
            textBoxThirdint.TabIndex = 12;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10F);
            label5.Location = new Point(6, 81);
            label5.Name = "label5";
            label5.Size = new Size(60, 19);
            label5.TabIndex = 11;
            label5.Text = "Third int";
            // 
            // textBoxSecondint
            // 
            textBoxSecondint.Location = new Point(125, 48);
            textBoxSecondint.Name = "textBoxSecondint";
            textBoxSecondint.Size = new Size(100, 23);
            textBoxSecondint.TabIndex = 10;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10F);
            label4.Location = new Point(6, 52);
            label4.Name = "label4";
            label4.Size = new Size(73, 19);
            label4.TabIndex = 9;
            label4.Text = "Second int";
            // 
            // textBoxFirstint
            // 
            textBoxFirstint.Location = new Point(125, 19);
            textBoxFirstint.Name = "textBoxFirstint";
            textBoxFirstint.Size = new Size(100, 23);
            textBoxFirstint.TabIndex = 8;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10F);
            label3.Location = new Point(6, 23);
            label3.Name = "label3";
            label3.Size = new Size(55, 19);
            label3.TabIndex = 7;
            label3.Text = "First int";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(textBoxModdedstr);
            groupBox3.Controls.Add(label11);
            groupBox3.Controls.Add(textBoxString);
            groupBox3.Controls.Add(label10);
            groupBox3.Location = new Point(8, 449);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(250, 98);
            groupBox3.TabIndex = 2;
            groupBox3.TabStop = false;
            groupBox3.Text = "Strings";
            // 
            // textBoxModdedstr
            // 
            textBoxModdedstr.Location = new Point(125, 64);
            textBoxModdedstr.Name = "textBoxModdedstr";
            textBoxModdedstr.Size = new Size(100, 23);
            textBoxModdedstr.TabIndex = 24;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 10F);
            label11.Location = new Point(10, 65);
            label11.Name = "label11";
            label11.Size = new Size(100, 19);
            label11.TabIndex = 23;
            label11.Text = "Modded string";
            // 
            // textBoxString
            // 
            textBoxString.Location = new Point(125, 22);
            textBoxString.Name = "textBoxString";
            textBoxString.Size = new Size(100, 23);
            textBoxString.TabIndex = 22;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 10F);
            label10.Location = new Point(10, 23);
            label10.Name = "label10";
            label10.Size = new Size(45, 19);
            label10.TabIndex = 21;
            label10.Text = "String";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(286, 573);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "More methods";
            Load += Form1_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem parrotsToolStripMenuItem;
        private ToolStripMenuItem intsToolStripMenuItem;
        private ToolStripMenuItem stringToolStripMenuItem;
        private GroupBox groupBox1;
        private Label label1;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
        private ToolStripMenuItem intsBigToolStripMenuItem;
        private TextBox textBoxTrouble;
        private Label label2;
        private TextBox textBoxHourODay;
        private TextBox textBoxInrange;
        private Label label9;
        private TextBox textBoxOtherSecondInt;
        private Label label8;
        private TextBox textBoxOtherFirstInt;
        private Label label7;
        private TextBox textBoxBiggestint;
        private Label label6;
        private TextBox textBoxThirdint;
        private Label label5;
        private TextBox textBoxSecondint;
        private Label label4;
        private TextBox textBoxFirstint;
        private Label label3;
        private ToolStripSeparator toolStripMenuItem1;
        private ToolStripMenuItem exitToolStripMenuItem;
        private ToolStripMenuItem helpToolStripMenuItem;
        private ToolStripMenuItem aboutToolStripMenuItem;
        private TextBox textBoxModdedstr;
        private Label label11;
        private TextBox textBoxString;
        private Label label10;
        private ToolStripMenuItem strings2ToolStripMenuItem;
    }
}
