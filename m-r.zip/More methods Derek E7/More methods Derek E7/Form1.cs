using System.Reflection.Metadata.Ecma335;

namespace More_methods_Derek_E7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("More methods - Derek E");
        }


        private int TalkingParot(int h)
        {
            int g = 0;
            if (h < 7) g = 1;
            else if (h > 20) g = 1;
            else g = 2;
            //1 = true,  2 = false
            return g;

        }


        private void parrotsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int time = int.Parse(textBoxHourODay.Text);
            int hastrouble = TalkingParot(time);

            if (hastrouble == 1) textBoxTrouble.Text = "We have trouble...";
            else if (hastrouble == 2) textBoxTrouble.Text = "There is no trouble around...";

        }


        private int BiggestInt(int a, int b, int c)
        {
            int one = 1, two = 2, three = 3, equal = 4, error = 5;


            if (a == b && a == c && b == c) return equal;
            if (a >= b && a >= c) return one;
            if (b >= a && b >= c) return two;
            if (c >= a && c >= b) return three;
            //failsafe
            else return error;

        }


        private void intsBigToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int first, second, third;
            first = int.Parse(textBoxFirstint.Text);
            second = int.Parse(textBoxSecondint.Text);
            third = int.Parse(textBoxThirdint.Text);

            int biggest = BiggestInt(first, second, third);

            if (biggest == 1) textBoxBiggestint.Text = "Int 1 is the biggest.";
            else if (biggest == 2) textBoxBiggestint.Text = "Int 2 is the biggest.";
            else if (biggest == 3) textBoxBiggestint.Text = "Int 3 is the biggest.";
            else if (biggest == 4) textBoxBiggestint.Text = "All three ints are equal.";
            else if (biggest == 5) textBoxBiggestint.Text = "Error...";

        }


        private bool NumRanges(int d, int e)
        {
            bool first = false, second = false;

            if (d >= 30 && d <= 40)
            {

                if (e >= 40 && e <= 50) return second = true;//return first == second; 
                return first = true;
            }
            //if (e >= 40 && e <= 50) return second = true;

            else if (d >= 40 && d <= 50)
            {
                if (e >= 30 && e <= 40) return second = true;
                return first == true;
            }

            else
            {
                return first != second;
            }


            //?
        }


        private void intsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int intrange1, intrange2;
            intrange1 = int.Parse(textBoxOtherFirstInt.Text);
            intrange2 = int.Parse(textBoxOtherSecondInt.Text);

            bool yay = NumRanges(intrange1, intrange2);
            if (yay == true)
            {
                textBoxInrange.Text = "True";
            }
            else textBoxInrange.Text = "False";


        }


        private string FrontBack(string u)
        {
            int length = u.Length;
            string a = u.Substring(0, 2);
            //string b = u.Substring(1);
            return a + u + a;


        }

        private void stringToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string strong = textBoxString.Text;
            string modded = FrontBack(strong);

            textBoxModdedstr.Text = modded;
        }


        private string BackAround(string b)
        {
            int length = b.Length;
            string a = b.Substring(length - 1);

            return a + b + a;
        }
        
        private void strings2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string ling = textBoxString.Text;
            string moed = BackAround(ling);

            textBoxModdedstr.Text = moed;
        }
    }
}
