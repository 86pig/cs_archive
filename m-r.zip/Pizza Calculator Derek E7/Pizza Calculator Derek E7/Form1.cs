using System.CodeDom;

namespace Pizza_Calculator_Derek_E7
{
    public partial class Form1 : Form
    {
        const double SMALLSIZE = 5.00;
        const double MEDIUMSIZE = 7.00;
        const double LARGESIZE = 10.00;
        const double EXTRALARGESIZE = 14.00;
        const double PEPPERS = 0.5;
        const double PEPPERONI = 1.00;
        const double SAUSAGE = 1.00;
        const double MUSHROOM = 0.5;
        const double VEGGIE = 0.75;
        const double HAWAIIAN = 1.50;

        const double SALESTAX = 0.082;
        double dailySales = 0.00;
        double asubtotal = 0.00;
        double bsubtotal = 0.00;
        double totaltaxed = 0.0;

        const double NOCOUP = 0.0;
        const double TENCOUP = 0.1;
        const double TWENTYCOUP = 0.2;
        double couponvaloff = 0.0;
        int numofpizzas = 0;


        public Form1()
        {
            InitializeComponent();
        }

        private void buttonExzit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonAddtoorder_Click(object sender, EventArgs e)
        {
            double topping = 0.0;
            double salestax = 0.0;
            double subtotal = 0.0;

            if (radioButtonSmallsize.Checked) subtotal += SMALLSIZE;
            else if (radioButtonMedsize.Checked) subtotal += MEDIUMSIZE;
            else if (radioButtonLargesize.Checked) subtotal += LARGESIZE;
            else if (radioButtonExtrtaLarge.Checked) subtotal += EXTRALARGESIZE;

            if (checkBoxpeppers.Checked) subtotal += PEPPERS;
            if (checkBoxMushroom.Checked) subtotal += MUSHROOM;
            if (checkBoxpepperoni.Checked) subtotal += PEPPERONI;
            if (checkBoxVeggie.Checked) subtotal += VEGGIE;
            if (checkBoxSausage.Checked) subtotal += SAUSAGE;
            if (checkBoxHawaiian.Checked) subtotal += HAWAIIAN;

            asubtotal += subtotal;
            salestax = subtotal * SALESTAX;
            bsubtotal = asubtotal - salestax;
            totaltaxed = totaltaxed += salestax;
            dailySales = asubtotal += totaltaxed;
            numofpizzas++;

            subtotallabel.Text = subtotal.ToString("C");
            salestaxlabel.Text = " - ";
            totalduesales.Text = " - ";



        }

        private void buttonOrdercomplete_Click(object sender, EventArgs e)
        {
            if (radioButton0percentcoupon.Checked) dailySales -= NOCOUP;
            else if (radioButton10percentcoupon.Checked) dailySales -= dailySales * TENCOUP;
            else if (radioButton20percentcoupon.Checked) dailySales -= dailySales * TWENTYCOUP;


            //totalduesales.Text = asubtotal.ToString("C");
            salestaxlabel.Text = totaltaxed.ToString("C");
            totalduesales.Text = dailySales.ToString("C");
            subtotallabel.Text = " - ";

        }

        private void buttonDailysales_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Daily sales: $" + dailySales);
        }
    }
}
//seek help
