﻿namespace Pizza_Calculator_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            radioButtonLargesize = new RadioButton();
            radioButtonMedsize = new RadioButton();
            radioButtonSmallsize = new RadioButton();
            radioButtonExtrtaLarge = new RadioButton();
            groupBox2 = new GroupBox();
            checkBoxHawaiian = new CheckBox();
            checkBoxSausage = new CheckBox();
            checkBoxVeggie = new CheckBox();
            checkBoxpepperoni = new CheckBox();
            checkBoxMushroom = new CheckBox();
            checkBoxpeppers = new CheckBox();
            groupBox3 = new GroupBox();
            radioButton20percentcoupon = new RadioButton();
            radioButton10percentcoupon = new RadioButton();
            radioButton0percentcoupon = new RadioButton();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            subtotallabel = new Label();
            salestaxlabel = new Label();
            totalduesales = new Label();
            buttonAddtoorder = new Button();
            buttonOrdercomplete = new Button();
            buttonDailysales = new Button();
            buttonExzit = new Button();
            label4 = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(radioButtonLargesize);
            groupBox1.Controls.Add(radioButtonMedsize);
            groupBox1.Controls.Add(radioButtonSmallsize);
            groupBox1.Location = new Point(32, 27);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(122, 130);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Size";
            // 
            // radioButtonLargesize
            // 
            radioButtonLargesize.AutoSize = true;
            radioButtonLargesize.Location = new Point(6, 72);
            radioButtonLargesize.Name = "radioButtonLargesize";
            radioButtonLargesize.Size = new Size(54, 19);
            radioButtonLargesize.TabIndex = 2;
            radioButtonLargesize.Text = "&Large";
            radioButtonLargesize.UseVisualStyleBackColor = true;
            // 
            // radioButtonMedsize
            // 
            radioButtonMedsize.AutoSize = true;
            radioButtonMedsize.Checked = true;
            radioButtonMedsize.Location = new Point(6, 47);
            radioButtonMedsize.Name = "radioButtonMedsize";
            radioButtonMedsize.Size = new Size(70, 19);
            radioButtonMedsize.TabIndex = 1;
            radioButtonMedsize.TabStop = true;
            radioButtonMedsize.Text = "&Medium";
            radioButtonMedsize.UseVisualStyleBackColor = true;
            // 
            // radioButtonSmallsize
            // 
            radioButtonSmallsize.AutoSize = true;
            radioButtonSmallsize.Location = new Point(6, 22);
            radioButtonSmallsize.Name = "radioButtonSmallsize";
            radioButtonSmallsize.Size = new Size(54, 19);
            radioButtonSmallsize.TabIndex = 0;
            radioButtonSmallsize.Text = "&Small";
            radioButtonSmallsize.UseVisualStyleBackColor = true;
            // 
            // radioButtonExtrtaLarge
            // 
            radioButtonExtrtaLarge.AutoSize = true;
            radioButtonExtrtaLarge.Location = new Point(38, 124);
            radioButtonExtrtaLarge.Name = "radioButtonExtrtaLarge";
            radioButtonExtrtaLarge.Size = new Size(83, 19);
            radioButtonExtrtaLarge.TabIndex = 3;
            radioButtonExtrtaLarge.TabStop = true;
            radioButtonExtrtaLarge.Text = "&Extra Large";
            radioButtonExtrtaLarge.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(checkBoxHawaiian);
            groupBox2.Controls.Add(checkBoxSausage);
            groupBox2.Controls.Add(checkBoxVeggie);
            groupBox2.Controls.Add(checkBoxpepperoni);
            groupBox2.Controls.Add(checkBoxMushroom);
            groupBox2.Controls.Add(checkBoxpeppers);
            groupBox2.Location = new Point(32, 163);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(122, 180);
            groupBox2.TabIndex = 4;
            groupBox2.TabStop = false;
            groupBox2.Text = "Toppings";
            // 
            // checkBoxHawaiian
            // 
            checkBoxHawaiian.AutoSize = true;
            checkBoxHawaiian.Location = new Point(6, 147);
            checkBoxHawaiian.Name = "checkBoxHawaiian";
            checkBoxHawaiian.Size = new Size(75, 19);
            checkBoxHawaiian.TabIndex = 6;
            checkBoxHawaiian.Text = "Hawaiian";
            checkBoxHawaiian.UseVisualStyleBackColor = true;
            // 
            // checkBoxSausage
            // 
            checkBoxSausage.AutoSize = true;
            checkBoxSausage.Location = new Point(6, 122);
            checkBoxSausage.Name = "checkBoxSausage";
            checkBoxSausage.Size = new Size(69, 19);
            checkBoxSausage.TabIndex = 5;
            checkBoxSausage.Text = "Sausage";
            checkBoxSausage.UseVisualStyleBackColor = true;
            // 
            // checkBoxVeggie
            // 
            checkBoxVeggie.AutoSize = true;
            checkBoxVeggie.Location = new Point(6, 97);
            checkBoxVeggie.Name = "checkBoxVeggie";
            checkBoxVeggie.Size = new Size(61, 19);
            checkBoxVeggie.TabIndex = 3;
            checkBoxVeggie.Text = "Veggie";
            checkBoxVeggie.UseVisualStyleBackColor = true;
            // 
            // checkBoxpepperoni
            // 
            checkBoxpepperoni.AutoSize = true;
            checkBoxpepperoni.Location = new Point(6, 72);
            checkBoxpepperoni.Name = "checkBoxpepperoni";
            checkBoxpepperoni.Size = new Size(80, 19);
            checkBoxpepperoni.TabIndex = 2;
            checkBoxpepperoni.Text = "Pepperoni";
            checkBoxpepperoni.UseVisualStyleBackColor = true;
            // 
            // checkBoxMushroom
            // 
            checkBoxMushroom.AutoSize = true;
            checkBoxMushroom.Location = new Point(6, 47);
            checkBoxMushroom.Name = "checkBoxMushroom";
            checkBoxMushroom.Size = new Size(85, 19);
            checkBoxMushroom.TabIndex = 1;
            checkBoxMushroom.Text = "Mushroom";
            checkBoxMushroom.UseVisualStyleBackColor = true;
            // 
            // checkBoxpeppers
            // 
            checkBoxpeppers.AutoSize = true;
            checkBoxpeppers.Location = new Point(6, 22);
            checkBoxpeppers.Name = "checkBoxpeppers";
            checkBoxpeppers.Size = new Size(68, 19);
            checkBoxpeppers.TabIndex = 0;
            checkBoxpeppers.Text = "Peppers";
            checkBoxpeppers.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(radioButton20percentcoupon);
            groupBox3.Controls.Add(radioButton10percentcoupon);
            groupBox3.Controls.Add(radioButton0percentcoupon);
            groupBox3.Location = new Point(32, 349);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(122, 101);
            groupBox3.TabIndex = 5;
            groupBox3.TabStop = false;
            groupBox3.Text = "Coupons";
            // 
            // radioButton20percentcoupon
            // 
            radioButton20percentcoupon.AutoSize = true;
            radioButton20percentcoupon.Location = new Point(6, 72);
            radioButton20percentcoupon.Name = "radioButton20percentcoupon";
            radioButton20percentcoupon.Size = new Size(47, 19);
            radioButton20percentcoupon.TabIndex = 2;
            radioButton20percentcoupon.Text = "20%";
            radioButton20percentcoupon.UseVisualStyleBackColor = true;
            // 
            // radioButton10percentcoupon
            // 
            radioButton10percentcoupon.AutoSize = true;
            radioButton10percentcoupon.Location = new Point(6, 47);
            radioButton10percentcoupon.Name = "radioButton10percentcoupon";
            radioButton10percentcoupon.Size = new Size(47, 19);
            radioButton10percentcoupon.TabIndex = 1;
            radioButton10percentcoupon.Text = "10%";
            radioButton10percentcoupon.UseVisualStyleBackColor = true;
            // 
            // radioButton0percentcoupon
            // 
            radioButton0percentcoupon.AutoSize = true;
            radioButton0percentcoupon.Checked = true;
            radioButton0percentcoupon.Location = new Point(6, 22);
            radioButton0percentcoupon.Name = "radioButton0percentcoupon";
            radioButton0percentcoupon.Size = new Size(41, 19);
            radioButton0percentcoupon.TabIndex = 0;
            radioButton0percentcoupon.TabStop = true;
            radioButton0percentcoupon.Text = "0%";
            radioButton0percentcoupon.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11F);
            label1.Location = new Point(192, 72);
            label1.Name = "label1";
            label1.Size = new Size(72, 20);
            label1.TabIndex = 6;
            label1.Text = "Sub total:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11F);
            label2.Location = new Point(192, 97);
            label2.Name = "label2";
            label2.Size = new Size(70, 20);
            label2.TabIndex = 7;
            label2.Text = "Sales tax:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11F);
            label3.Location = new Point(192, 122);
            label3.Name = "label3";
            label3.Size = new Size(74, 20);
            label3.TabIndex = 8;
            label3.Text = "Total due:";
            // 
            // subtotallabel
            // 
            subtotallabel.AutoSize = true;
            subtotallabel.Font = new Font("Segoe UI", 11F);
            subtotallabel.Location = new Point(291, 73);
            subtotallabel.Name = "subtotallabel";
            subtotallabel.Size = new Size(44, 20);
            subtotallabel.TabIndex = 9;
            subtotallabel.Text = "$0.00";
            // 
            // salestaxlabel
            // 
            salestaxlabel.AutoSize = true;
            salestaxlabel.Font = new Font("Segoe UI", 11F);
            salestaxlabel.Location = new Point(291, 97);
            salestaxlabel.Name = "salestaxlabel";
            salestaxlabel.Size = new Size(44, 20);
            salestaxlabel.TabIndex = 10;
            salestaxlabel.Text = "$0.00";
            // 
            // totalduesales
            // 
            totalduesales.AutoSize = true;
            totalduesales.Font = new Font("Segoe UI", 11F);
            totalduesales.Location = new Point(291, 123);
            totalduesales.Name = "totalduesales";
            totalduesales.Size = new Size(44, 20);
            totalduesales.TabIndex = 11;
            totalduesales.Text = "$0.00";
            // 
            // buttonAddtoorder
            // 
            buttonAddtoorder.Location = new Point(192, 163);
            buttonAddtoorder.Name = "buttonAddtoorder";
            buttonAddtoorder.Size = new Size(143, 66);
            buttonAddtoorder.TabIndex = 12;
            buttonAddtoorder.Text = "&Add to order";
            buttonAddtoorder.UseVisualStyleBackColor = true;
            buttonAddtoorder.Click += buttonAddtoorder_Click;
            // 
            // buttonOrdercomplete
            // 
            buttonOrdercomplete.Location = new Point(192, 235);
            buttonOrdercomplete.Name = "buttonOrdercomplete";
            buttonOrdercomplete.Size = new Size(143, 66);
            buttonOrdercomplete.TabIndex = 13;
            buttonOrdercomplete.Text = "Order &complete";
            buttonOrdercomplete.UseVisualStyleBackColor = true;
            buttonOrdercomplete.Click += buttonOrdercomplete_Click;
            // 
            // buttonDailysales
            // 
            buttonDailysales.Location = new Point(192, 307);
            buttonDailysales.Name = "buttonDailysales";
            buttonDailysales.Size = new Size(143, 66);
            buttonDailysales.TabIndex = 14;
            buttonDailysales.Text = "&Daily sales";
            buttonDailysales.UseVisualStyleBackColor = true;
            buttonDailysales.Click += buttonDailysales_Click;
            // 
            // buttonExzit
            // 
            buttonExzit.Location = new Point(192, 384);
            buttonExzit.Name = "buttonExzit";
            buttonExzit.Size = new Size(143, 66);
            buttonExzit.TabIndex = 15;
            buttonExzit.Text = "E&xit";
            buttonExzit.UseVisualStyleBackColor = true;
            buttonExzit.Click += buttonExzit_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11F);
            label4.Location = new Point(177, 37);
            label4.Name = "label4";
            label4.Size = new Size(158, 20);
            label4.TabIndex = 16;
            label4.Text = "Pizza Order - Derek E7";
            // 
            // Form1
            // 
            AcceptButton = buttonAddtoorder;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = buttonExzit;
            ClientSize = new Size(378, 478);
            Controls.Add(label4);
            Controls.Add(buttonExzit);
            Controls.Add(buttonDailysales);
            Controls.Add(buttonOrdercomplete);
            Controls.Add(buttonAddtoorder);
            Controls.Add(totalduesales);
            Controls.Add(salestaxlabel);
            Controls.Add(subtotallabel);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(radioButtonExtrtaLarge);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Pizza Order";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private RadioButton radioButtonLargesize;
        private RadioButton radioButtonMedsize;
        private RadioButton radioButtonSmallsize;
        private RadioButton radioButtonExtrtaLarge;
        private GroupBox groupBox2;
        private CheckBox checkBoxpeppers;
        private CheckBox checkBoxHawaiian;
        private CheckBox checkBoxSausage;
        private CheckBox checkBoxVeggie;
        private CheckBox checkBoxpepperoni;
        private CheckBox checkBoxMushroom;
        private GroupBox groupBox3;
        private RadioButton radioButton20percentcoupon;
        private RadioButton radioButton10percentcoupon;
        private RadioButton radioButton0percentcoupon;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label subtotallabel;
        private Label salestaxlabel;
        private Label totalduesales;
        private Button buttonAddtoorder;
        private Button buttonOrdercomplete;
        private Button buttonDailysales;
        private Button buttonExzit;
        private Label label4;
    }
}
