﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NET_BAGEL_Derek_E7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void addBagelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool inlist = false;

            string bagel = textBoxBagelEditor3000.Text;

            if (bagel == "") MessageBox.Show("Enter a bagle naem");
            else
            {
                // add lope to compare names to the student in the lsit 
                foreach (string inlistedbagel in listBoxBagels.Items)
                {
                    //check if names mathc
                    if (bagel.ToLower() == inlistedbagel.ToLower())
                    {
                        //if match: AYAY but DONT adsd to list !!    
                        inlist = true;
                        break; //break from loop euh duh 

                    }


                }
                textBoxBagelEditor3000.Clear();
                //fi student not in list: add them bruh
                if (!inlist)
                {
                    listBoxBagels.Items.Add(bagel);
                }

            }

        }

        private void removeBagelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listBoxBagels.SelectedIndex != -1)
            {
                //remove
                listBoxBagels.Items.RemoveAt(listBoxBagels.SelectedIndex);

                textBoxBagelEditor3000.Clear();
            }
            else
            {
                MessageBox.Show("Select a bagel first. You ain't removing something that don't exist. I know you tried before. Look how that turned out.");
            }
        }

        private void clearListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult yesno = MessageBox.Show("Are you sure you want to clear all?", "Alert!", MessageBoxButtons.YesNo);
            if (yesno == DialogResult.Yes)
            {
                listBoxBagels.Items.Clear();
            }
            
        }

        private void displayBagelCountToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            int a = 0;
            foreach (string numbagl in listBoxBagels.Items)
            {
                a += 1;
               
            }
            MessageBox.Show("Yoe havv like " + a.ToString() + " bagellies in yo list!!!!");
        }

        private void printPreviewDialogBagl_Load(object sender, EventArgs e)
        {

        }

        private void printDocumentlistobagL_PrintPage(object sender, PrintPageEventArgs e)
        {
            Font printFont = new Font("Arial", 12);
            Font headingFont = new Font("Arial", 24, FontStyle.Bold);
            float verticalPrintPositionFloat = e.MarginBounds.Top;
            float horizontalPrintPositionFloat = e.MarginBounds.Left;
            float lineHeightFloat = printFont.GetHeight();

            // Print heading.
            e.Graphics.DrawString("Yo list o' baygulls: ",
            headingFont,
            Brushes.SaddleBrown, horizontalPrintPositionFloat,
            verticalPrintPositionFloat);

            verticalPrintPositionFloat += 2 * lineHeightFloat;

            foreach (String student in listBoxBagels.Items)
            {
                e.Graphics.DrawString(student, printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);

                verticalPrintPositionFloat += 2 * lineHeightFloat;


            }
        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void printListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printPreviewDialogBagl.Document = printDocumentlistobagL;
            printPreviewDialogBagl.ShowDialog();
        }
    }
}
