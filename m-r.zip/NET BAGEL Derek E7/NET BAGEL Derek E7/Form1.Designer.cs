﻿namespace NET_BAGEL_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.addBagelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.removeBagelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.displayBagelCountToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.listBoxBagels = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxBagelEditor3000 = new System.Windows.Forms.TextBox();
            this.printPreviewDialogBagl = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocumentlistobagL = new System.Drawing.Printing.PrintDocument();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addBagelToolStripMenuItem,
            this.removeBagelToolStripMenuItem,
            this.clearListToolStripMenuItem,
            this.printListToolStripMenuItem,
            this.displayBagelCountToolStripMenuItem1,
            this.exitToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // addBagelToolStripMenuItem
            // 
            this.addBagelToolStripMenuItem.Name = "addBagelToolStripMenuItem";
            this.addBagelToolStripMenuItem.Size = new System.Drawing.Size(73, 20);
            this.addBagelToolStripMenuItem.Text = "Add bagel";
            this.addBagelToolStripMenuItem.Click += new System.EventHandler(this.addBagelToolStripMenuItem_Click);
            // 
            // removeBagelToolStripMenuItem
            // 
            this.removeBagelToolStripMenuItem.Name = "removeBagelToolStripMenuItem";
            this.removeBagelToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
            this.removeBagelToolStripMenuItem.Text = "Remove bagel";
            this.removeBagelToolStripMenuItem.Click += new System.EventHandler(this.removeBagelToolStripMenuItem_Click);
            // 
            // clearListToolStripMenuItem
            // 
            this.clearListToolStripMenuItem.Name = "clearListToolStripMenuItem";
            this.clearListToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.clearListToolStripMenuItem.Text = "Clear list";
            this.clearListToolStripMenuItem.Click += new System.EventHandler(this.clearListToolStripMenuItem_Click);
            // 
            // printListToolStripMenuItem
            // 
            this.printListToolStripMenuItem.Name = "printListToolStripMenuItem";
            this.printListToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.printListToolStripMenuItem.Text = "Print list";
            this.printListToolStripMenuItem.Click += new System.EventHandler(this.printListToolStripMenuItem_Click);
            // 
            // displayBagelCountToolStripMenuItem1
            // 
            this.displayBagelCountToolStripMenuItem1.Name = "displayBagelCountToolStripMenuItem1";
            this.displayBagelCountToolStripMenuItem1.Size = new System.Drawing.Size(123, 20);
            this.displayBagelCountToolStripMenuItem1.Text = "Display bagel count";
            this.displayBagelCountToolStripMenuItem1.Click += new System.EventHandler(this.displayBagelCountToolStripMenuItem1_Click);
            // 
            // exitToolStripMenuItem1
            // 
            this.exitToolStripMenuItem1.Name = "exitToolStripMenuItem1";
            this.exitToolStripMenuItem1.Size = new System.Drawing.Size(38, 20);
            this.exitToolStripMenuItem1.Text = "Exit";
            this.exitToolStripMenuItem1.Click += new System.EventHandler(this.exitToolStripMenuItem1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.label1.Location = new System.Drawing.Point(39, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Bagel list";
            // 
            // listBoxBagels
            // 
            this.listBoxBagels.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxBagels.FormattingEnabled = true;
            this.listBoxBagels.ItemHeight = 25;
            this.listBoxBagels.Items.AddRange(new object[] {
            "Bagel Bagel",
            "Cheese Bagel",
            "Everything Bagel",
            "French Bagel",
            "Household_pet Bagel",
            "Onion Bagel",
            "Plain Bagel",
            "Plane Bagel"});
            this.listBoxBagels.Location = new System.Drawing.Point(42, 107);
            this.listBoxBagels.Name = "listBoxBagels";
            this.listBoxBagels.Size = new System.Drawing.Size(310, 279);
            this.listBoxBagels.Sorted = true;
            this.listBoxBagels.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.label2.Location = new System.Drawing.Point(191, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Bagel editor";
            // 
            // textBoxBagelEditor3000
            // 
            this.textBoxBagelEditor3000.Location = new System.Drawing.Point(277, 66);
            this.textBoxBagelEditor3000.Name = "textBoxBagelEditor3000";
            this.textBoxBagelEditor3000.Size = new System.Drawing.Size(100, 20);
            this.textBoxBagelEditor3000.TabIndex = 4;
            // 
            // printPreviewDialogBagl
            // 
            this.printPreviewDialogBagl.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialogBagl.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialogBagl.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialogBagl.Enabled = true;
            this.printPreviewDialogBagl.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialogBagl.Icon")));
            this.printPreviewDialogBagl.Name = "printPreviewDialogBagl";
            this.printPreviewDialogBagl.Visible = false;
            this.printPreviewDialogBagl.Load += new System.EventHandler(this.printPreviewDialogBagl_Load);
            // 
            // printDocumentlistobagL
            // 
            this.printDocumentlistobagL.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocumentlistobagL_PrintPage);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBoxBagelEditor3000);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.listBoxBagels);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Bouncy  Bagels";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem addBagelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem removeBagelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem displayBagelCountToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBoxBagels;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxBagelEditor3000;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialogBagl;
        private System.Drawing.Printing.PrintDocument printDocumentlistobagL;
    }
}

