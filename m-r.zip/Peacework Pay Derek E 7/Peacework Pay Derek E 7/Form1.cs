using System.CodeDom;

namespace Peacework_Pay_Derek_E_7
{
    public partial class Form1 : Form
    {
        const double ONE = 0.5;
        const double TWO = 0.55;
        const double THREE = 0.6;
        const double FOUR = 0.65;
        double totalPay = 0.0;
        int numberOfWorkers = 0;
        int piecesssa = 0;
        double averagepay = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {

        }

        private void buttonexit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {


            //

        }

        private void buttonUpdateSumInfo_Click(object sender, EventArgs e)
        {
            /*
            double averagepay = 69696969;
            textBoxAveragePay.Text = averagepay.ToString("C");
            textBoxTotalnumofPieces.Text = numberOfWorkers.ToString();
            textBoxTotalPay.Text = totalPay.ToString("C");


            */
        }

        private void buttonClearbutnotall_Click(object sender, EventArgs e)
        {


        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About aboutDlg = new About();
            aboutDlg.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private double payCalcs(double piecesmade)
        {
            if (piecesmade <= 199) return piecesmade * ONE;

            else if (piecesmade <= 399) return piecesmade * TWO;

            else if (piecesmade <= 599) return piecesmade * THREE;

            else if (piecesmade >= 600) return piecesmade * FOUR;

            else return piecesmade * 0;

        }

        private void calculatePayToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBoName.Text))
            {
                MessageBox.Show("Enter a name bozo");
                textBoName.Focus();
                return;
            }


            try
            {
                double payrate, pay;
                int piecesmade = int.Parse(textBoxPiecesMade.Text);

                pay = payCalcs(piecesmade);

                totalPay += pay;
                numberOfWorkers += piecesmade;
                piecesssa++;

                textBoxPay.Text = pay.ToString("C");
                /*
                textBoName.Clear();
                textBoxPiecesMade.Clear();
                textBoName.Focus();
                */
            }

            catch
            {
                MessageBox.Show("Enter a valid thingygabygiaiegfiagfiogfaisygfiasuf");

            }
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBoName.Clear();
            textBoxPiecesMade.Clear();
            textBoxPay.Clear();
            textBoName.Focus();
        }

        private void clearAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult yesno = MessageBox.Show("Are you sure you want to clear all data?", "Alert!", MessageBoxButtons.YesNo);
            if (yesno == DialogResult.Yes)
            {
                textBoName.Clear();
                textBoxPiecesMade.Clear();
                textBoxPay.Clear();
                averagepay = 0;
                numberOfWorkers = 0;
                totalPay = 0;
                textBoName.Focus();
            }
        }

        private void sloganToolStripMenuItem_Click(object sender, EventArgs e)
        {
            labelSlogan.Visible = !labelSlogan.Visible;
        }

        private void logoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBoxLogo.Visible = !pictureBoxLogo.Visible;
        }

        private void summaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // calc average pay here
            if (string.IsNullOrEmpty(textBoName.Text))
            {
                MessageBox.Show("Fill out info before calculating summary");
                textBoName.Focus();
                return;
            }

            if (string.IsNullOrEmpty(textBoxPiecesMade.Text))
            {
                MessageBox.Show("Fill out info before calculating summary");
                textBoxPiecesMade.Focus();
                return;
            }

            averagepay = totalPay / piecesssa;
            
            Summary summaryDlg = new Summary();
            
            summaryDlg.AveragePay = averagepay;
            summaryDlg.TotalPay = totalPay;
            summaryDlg.NumOWorkers = numberOfWorkers;

            summaryDlg.ShowDialog();
        }
    }
}
