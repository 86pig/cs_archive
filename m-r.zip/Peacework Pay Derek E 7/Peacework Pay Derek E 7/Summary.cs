﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Peacework_Pay_Derek_E_7
{
    public partial class Summary : Form
    {
        public double TotalPay { get; set; }
        public double AveragePay { get; set; }
        public int NumOWorkers { get; set; }





        public Summary()
        {
            InitializeComponent();
        }

        private void buttonClearALl_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void timerTickers_Tick(object sender, EventArgs e)
        {
            textBoxTotalnumofPieces.Text = NumOWorkers.ToString();
            textBoxAveragePay.Text = AveragePay.ToString("C");
            textBoxTotalPay.Text = TotalPay.ToString("C");
        }
    }
}
