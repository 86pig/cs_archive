﻿namespace Peacework_Pay_Derek_E_7
{
    partial class Summary
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            groupBox2 = new GroupBox();
            textBoxAveragePay = new TextBox();
            textBoxTotalPay = new TextBox();
            textBoxTotalnumofPieces = new TextBox();
            buttonClearALl = new Button();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            timerTickers = new System.Windows.Forms.Timer(components);
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(textBoxAveragePay);
            groupBox2.Controls.Add(textBoxTotalPay);
            groupBox2.Controls.Add(textBoxTotalnumofPieces);
            groupBox2.Controls.Add(buttonClearALl);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(label7);
            groupBox2.Location = new Point(125, 10);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(236, 298);
            groupBox2.TabIndex = 7;
            groupBox2.TabStop = false;
            groupBox2.Text = "Summary Information";
            // 
            // textBoxAveragePay
            // 
            textBoxAveragePay.Location = new Point(130, 149);
            textBoxAveragePay.Name = "textBoxAveragePay";
            textBoxAveragePay.ReadOnly = true;
            textBoxAveragePay.Size = new Size(100, 23);
            textBoxAveragePay.TabIndex = 5;
            // 
            // textBoxTotalPay
            // 
            textBoxTotalPay.Location = new Point(130, 89);
            textBoxTotalPay.Name = "textBoxTotalPay";
            textBoxTotalPay.ReadOnly = true;
            textBoxTotalPay.Size = new Size(100, 23);
            textBoxTotalPay.TabIndex = 4;
            // 
            // textBoxTotalnumofPieces
            // 
            textBoxTotalnumofPieces.Location = new Point(130, 29);
            textBoxTotalnumofPieces.Name = "textBoxTotalnumofPieces";
            textBoxTotalnumofPieces.ReadOnly = true;
            textBoxTotalnumofPieces.Size = new Size(100, 23);
            textBoxTotalnumofPieces.TabIndex = 3;
            // 
            // buttonClearALl
            // 
            buttonClearALl.Location = new Point(6, 261);
            buttonClearALl.Name = "buttonClearALl";
            buttonClearALl.Size = new Size(224, 23);
            buttonClearALl.TabIndex = 3;
            buttonClearALl.Text = "Exit";
            buttonClearALl.UseVisualStyleBackColor = true;
            buttonClearALl.Click += buttonClearALl_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10F);
            label5.Location = new Point(6, 150);
            label5.Name = "label5";
            label5.Size = new Size(85, 19);
            label5.TabIndex = 2;
            label5.Text = "Average pay";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 10F);
            label6.Location = new Point(6, 90);
            label6.Name = "label6";
            label6.Size = new Size(64, 19);
            label6.TabIndex = 1;
            label6.Text = "Total pay";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 10F);
            label7.Location = new Point(6, 30);
            label7.Name = "label7";
            label7.Size = new Size(46, 19);
            label7.TabIndex = 0;
            label7.Text = "Pieces";
            // 
            // timerTickers
            // 
            timerTickers.Enabled = true;
            timerTickers.Interval = 2;
            timerTickers.Tick += timerTickers_Tick;
            // 
            // Summary
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(486, 318);
            Controls.Add(groupBox2);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "Summary";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Summary";
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox2;
        private TextBox textBoxAveragePay;
        private TextBox textBoxTotalPay;
        private TextBox textBoxTotalnumofPieces;
        private Button buttonClearALl;
        private Label label5;
        private Label label6;
        private Label label7;
        private System.Windows.Forms.Timer timerTickers;
    }
}