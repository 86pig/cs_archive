﻿namespace Peacework_Pay_Derek_E_7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            textBoxPay = new TextBox();
            textBoxPiecesMade = new TextBox();
            textBoName = new TextBox();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            label4NAME = new Label();
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            calculatePayToolStripMenuItem = new ToolStripMenuItem();
            summaryToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem1 = new ToolStripSeparator();
            exitToolStripMenuItem = new ToolStripMenuItem();
            editToolStripMenuItem = new ToolStripMenuItem();
            clearToolStripMenuItem = new ToolStripMenuItem();
            clearAllToolStripMenuItem = new ToolStripMenuItem();
            sloganToolStripMenuItem = new ToolStripMenuItem();
            logoToolStripMenuItem = new ToolStripMenuItem();
            helpToolStripMenuItem = new ToolStripMenuItem();
            aboutToolStripMenuItem = new ToolStripMenuItem();
            pictureBoxLogo = new PictureBox();
            labelSlogan = new Label();
            groupBox1.SuspendLayout();
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxLogo).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBoxPay);
            groupBox1.Controls.Add(textBoxPiecesMade);
            groupBox1.Controls.Add(textBoName);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(25, 43);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(236, 298);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Calculate Pay";
            // 
            // textBoxPay
            // 
            textBoxPay.Location = new Point(130, 149);
            textBoxPay.Name = "textBoxPay";
            textBoxPay.ReadOnly = true;
            textBoxPay.Size = new Size(100, 23);
            textBoxPay.TabIndex = 5;
            // 
            // textBoxPiecesMade
            // 
            textBoxPiecesMade.Location = new Point(130, 89);
            textBoxPiecesMade.Name = "textBoxPiecesMade";
            textBoxPiecesMade.Size = new Size(100, 23);
            textBoxPiecesMade.TabIndex = 4;
            // 
            // textBoName
            // 
            textBoName.Location = new Point(130, 29);
            textBoName.Name = "textBoName";
            textBoName.Size = new Size(100, 23);
            textBoName.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10F);
            label3.Location = new Point(6, 150);
            label3.Name = "label3";
            label3.Size = new Size(31, 19);
            label3.TabIndex = 2;
            label3.Text = "Pay";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F);
            label2.Location = new Point(6, 90);
            label2.Name = "label2";
            label2.Size = new Size(84, 19);
            label2.TabIndex = 1;
            label2.Text = "Pieces made";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F);
            label1.Location = new Point(6, 30);
            label1.Name = "label1";
            label1.Size = new Size(45, 19);
            label1.TabIndex = 0;
            label1.Text = "Name";
            // 
            // label4NAME
            // 
            label4NAME.AutoSize = true;
            label4NAME.Font = new Font("Segoe UI", 10F);
            label4NAME.Location = new Point(650, 322);
            label4NAME.Name = "label4NAME";
            label4NAME.Size = new Size(56, 19);
            label4NAME.TabIndex = 2;
            label4NAME.Text = "Derek E";
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem, editToolStripMenuItem, helpToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(724, 24);
            menuStrip1.TabIndex = 8;
            menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { calculatePayToolStripMenuItem, summaryToolStripMenuItem, toolStripMenuItem1, exitToolStripMenuItem });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(37, 20);
            fileToolStripMenuItem.Text = "File";
            // 
            // calculatePayToolStripMenuItem
            // 
            calculatePayToolStripMenuItem.Name = "calculatePayToolStripMenuItem";
            calculatePayToolStripMenuItem.Size = new Size(145, 22);
            calculatePayToolStripMenuItem.Text = "Calculate Pay";
            calculatePayToolStripMenuItem.Click += calculatePayToolStripMenuItem_Click;
            // 
            // summaryToolStripMenuItem
            // 
            summaryToolStripMenuItem.Name = "summaryToolStripMenuItem";
            summaryToolStripMenuItem.Size = new Size(145, 22);
            summaryToolStripMenuItem.Text = "Summary";
            summaryToolStripMenuItem.Click += summaryToolStripMenuItem_Click;
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(142, 6);
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(145, 22);
            exitToolStripMenuItem.Text = "Exit";
            exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;
            // 
            // editToolStripMenuItem
            // 
            editToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { clearToolStripMenuItem, clearAllToolStripMenuItem, sloganToolStripMenuItem, logoToolStripMenuItem });
            editToolStripMenuItem.Name = "editToolStripMenuItem";
            editToolStripMenuItem.Size = new Size(39, 20);
            editToolStripMenuItem.Text = "Edit";
            // 
            // clearToolStripMenuItem
            // 
            clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            clearToolStripMenuItem.Size = new Size(116, 22);
            clearToolStripMenuItem.Text = "Clear";
            clearToolStripMenuItem.Click += clearToolStripMenuItem_Click;
            // 
            // clearAllToolStripMenuItem
            // 
            clearAllToolStripMenuItem.Name = "clearAllToolStripMenuItem";
            clearAllToolStripMenuItem.Size = new Size(116, 22);
            clearAllToolStripMenuItem.Text = "Clear all";
            clearAllToolStripMenuItem.Click += clearAllToolStripMenuItem_Click;
            // 
            // sloganToolStripMenuItem
            // 
            sloganToolStripMenuItem.CheckOnClick = true;
            sloganToolStripMenuItem.Name = "sloganToolStripMenuItem";
            sloganToolStripMenuItem.Size = new Size(116, 22);
            sloganToolStripMenuItem.Text = "Slogan";
            sloganToolStripMenuItem.Click += sloganToolStripMenuItem_Click;
            // 
            // logoToolStripMenuItem
            // 
            logoToolStripMenuItem.CheckOnClick = true;
            logoToolStripMenuItem.Name = "logoToolStripMenuItem";
            logoToolStripMenuItem.Size = new Size(116, 22);
            logoToolStripMenuItem.Text = "Logo";
            logoToolStripMenuItem.Click += logoToolStripMenuItem_Click;
            // 
            // helpToolStripMenuItem
            // 
            helpToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { aboutToolStripMenuItem });
            helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            helpToolStripMenuItem.Size = new Size(44, 20);
            helpToolStripMenuItem.Text = "Help";
            // 
            // aboutToolStripMenuItem
            // 
            aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            aboutToolStripMenuItem.Size = new Size(107, 22);
            aboutToolStripMenuItem.Text = "About";
            aboutToolStripMenuItem.Click += aboutToolStripMenuItem_Click;
            // 
            // pictureBoxLogo
            // 
            pictureBoxLogo.Image = Properties.Resources.peacelogo;
            pictureBoxLogo.Location = new Point(290, 57);
            pictureBoxLogo.Name = "pictureBoxLogo";
            pictureBoxLogo.Size = new Size(416, 108);
            pictureBoxLogo.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxLogo.TabIndex = 9;
            pictureBoxLogo.TabStop = false;
            pictureBoxLogo.Visible = false;
            // 
            // labelSlogan
            // 
            labelSlogan.AutoSize = true;
            labelSlogan.Font = new Font("Segoe UI", 15F);
            labelSlogan.Location = new Point(387, 184);
            labelSlogan.Name = "labelSlogan";
            labelSlogan.Size = new Size(239, 28);
            labelSlogan.TabIndex = 10;
            labelSlogan.Text = "(please) Get back to work!";
            labelSlogan.Visible = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(724, 356);
            Controls.Add(labelSlogan);
            Controls.Add(pictureBoxLogo);
            Controls.Add(label4NAME);
            Controls.Add(groupBox1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Peacemeal Pay";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxLogo).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textBoName;
        private Label label4NAME;
        private TextBox textBoxPay;
        private TextBox textBoxPiecesMade;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem editToolStripMenuItem;
        private ToolStripMenuItem helpToolStripMenuItem;
        private ToolStripMenuItem calculatePayToolStripMenuItem;
        private ToolStripMenuItem summaryToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem1;
        private ToolStripMenuItem exitToolStripMenuItem;
        private ToolStripMenuItem clearToolStripMenuItem;
        private ToolStripMenuItem clearAllToolStripMenuItem;
        private ToolStripMenuItem sloganToolStripMenuItem;
        private ToolStripMenuItem logoToolStripMenuItem;
        private ToolStripMenuItem aboutToolStripMenuItem;
        private PictureBox pictureBoxLogo;
        private Label labelSlogan;
    }
}
