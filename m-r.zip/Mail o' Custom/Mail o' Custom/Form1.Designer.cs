﻿namespace Mail_o__Custom
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Customer = new Button();
            Marketing = new Button();
            Order = new Button();
            Shipping = new Button();
            button5 = new Button();
            label1 = new Label();
            label3 = new Label();
            label2 = new Label();
            label4 = new Label();
            Telephone = new Label();
            Contact = new Label();
            ScemBox = new TextBox();
            Scem3 = new Label();
            HaxButton = new Button();
            SuspendLayout();
            // 
            // Customer
            // 
            Customer.Location = new Point(64, 126);
            Customer.Name = "Customer";
            Customer.Size = new Size(269, 81);
            Customer.TabIndex = 0;
            Customer.Text = "Customer Relations";
            Customer.UseVisualStyleBackColor = true;
            Customer.Click += Customer_Click;
            // 
            // Marketing
            // 
            Marketing.Location = new Point(64, 213);
            Marketing.Name = "Marketing";
            Marketing.Size = new Size(269, 81);
            Marketing.TabIndex = 1;
            Marketing.Text = "Marketing";
            Marketing.UseVisualStyleBackColor = true;
            Marketing.Click += Marketing_Click;
            // 
            // Order
            // 
            Order.Location = new Point(64, 300);
            Order.Name = "Order";
            Order.Size = new Size(269, 81);
            Order.TabIndex = 2;
            Order.Text = "Order Processing";
            Order.UseVisualStyleBackColor = true;
            Order.Click += Order_Click;
            // 
            // Shipping
            // 
            Shipping.Location = new Point(64, 387);
            Shipping.Name = "Shipping";
            Shipping.Size = new Size(269, 81);
            Shipping.TabIndex = 3;
            Shipping.Text = "Shipping";
            Shipping.UseVisualStyleBackColor = true;
            Shipping.Click += Shipping_Click;
            // 
            // button5
            // 
            button5.BackColor = SystemColors.ControlDark;
            button5.Location = new Point(64, 495);
            button5.Name = "button5";
            button5.Size = new Size(269, 54);
            button5.TabIndex = 4;
            button5.Text = "Exit";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(1106, 602);
            label1.Name = "label1";
            label1.Size = new Size(105, 37);
            label1.TabIndex = 5;
            label1.Text = "Derek E";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(23, 9);
            label3.Name = "label3";
            label3.Size = new Size(1455, 40);
            label3.TabIndex = 7;
            label3.Text = "Welcome valued customer. Please select a box to find contact information for the tracking of your order.";
            label3.Click += label3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(461, 160);
            label2.Name = "label2";
            label2.Size = new Size(101, 32);
            label2.TabIndex = 8;
            label2.Text = "Contact:";
            label2.Click += label2_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(461, 241);
            label4.Name = "label4";
            label4.Size = new Size(131, 32);
            label4.TabIndex = 9;
            label4.Text = "Telephone:";
            // 
            // Telephone
            // 
            Telephone.AutoSize = true;
            Telephone.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Telephone.Location = new Point(827, 241);
            Telephone.Name = "Telephone";
            Telephone.Size = new Size(0, 32);
            Telephone.TabIndex = 10;
            // 
            // Contact
            // 
            Contact.AutoSize = true;
            Contact.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Contact.Location = new Point(827, 160);
            Contact.Name = "Contact";
            Contact.Size = new Size(0, 32);
            Contact.TabIndex = 11;
            // 
            // ScemBox
            // 
            ScemBox.Location = new Point(408, 721);
            ScemBox.Name = "ScemBox";
            ScemBox.Size = new Size(404, 23);
            ScemBox.TabIndex = 12;
            // 
            // Scem3
            // 
            Scem3.AutoSize = true;
            Scem3.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Scem3.Location = new Point(337, 671);
            Scem3.Name = "Scem3";
            Scem3.Size = new Size(596, 32);
            Scem3.TabIndex = 13;
            Scem3.Text = "Optional: Enter your address below for faster shipping!";
            // 
            // HaxButton
            // 
            HaxButton.Location = new Point(827, 721);
            HaxButton.Name = "HaxButton";
            HaxButton.Size = new Size(75, 23);
            HaxButton.TabIndex = 14;
            HaxButton.Text = "Send";
            HaxButton.UseVisualStyleBackColor = true;
            HaxButton.Click += HaxButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1854, 929);
            Controls.Add(HaxButton);
            Controls.Add(Scem3);
            Controls.Add(ScemBox);
            Controls.Add(Contact);
            Controls.Add(Telephone);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(button5);
            Controls.Add(Shipping);
            Controls.Add(Order);
            Controls.Add(Marketing);
            Controls.Add(Customer);
            Name = "Form1";
            Text = "CS Mail Order";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Customer;
        private Button Marketing;
        private Button Order;
        private Button Shipping;
        private Button button5;
        private Label label1;
        private Label label3;
        private Label label2;
        private Label label4;
        private Label Telephone;
        private Label Contact;
        private TextBox ScemBox;
        private Label Scem3;
        private Button HaxButton;
    }
}
