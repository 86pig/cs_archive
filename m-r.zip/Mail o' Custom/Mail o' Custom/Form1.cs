namespace Mail_o__Custom
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Customer_Click(object sender, EventArgs e)
        {
            Contact.Text = "George Egroeg";
            Telephone.Text = "000#1";
        }

        private void Marketing_Click(object sender, EventArgs e)
        {
            Contact.Text = "Kellen Nellek";
            Telephone.Text = "000#2";
        }

        private void Order_Click(object sender, EventArgs e)
        {
            Contact.Text = "Tyson Nosyt";
            Telephone.Text = "000#3";
        }

        private void Shipping_Click(object sender, EventArgs e)
        {
            Contact.Text = "Calvin Nivlac";
            Telephone.Text = "000#4";
        }

        private void HaxButton_Click(object sender, EventArgs e)
        {
            ScemBox.Text = "";
        }
    }
}
