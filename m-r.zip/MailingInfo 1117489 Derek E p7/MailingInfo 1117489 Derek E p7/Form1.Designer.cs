﻿namespace MailingInfo_1117489_Derek_E_p7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBoxNameeee = new TextBox();
            textBoxLast = new TextBox();
            textBoxAddress = new TextBox();
            textBoxCity = new TextBox();
            textBoxState = new TextBox();
            textmboxZip = new MaskedTextBox();
            buttonDisplay = new Button();
            buttonReset = new Button();
            Exit = new Button();
            bigboxmailinginfo = new RichTextBox();
            groupBox1 = new GroupBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // textBoxNameeee
            // 
            textBoxNameeee.Location = new Point(172, 57);
            textBoxNameeee.Name = "textBoxNameeee";
            textBoxNameeee.Size = new Size(156, 23);
            textBoxNameeee.TabIndex = 0;
            // 
            // textBoxLast
            // 
            textBoxLast.Location = new Point(172, 86);
            textBoxLast.Name = "textBoxLast";
            textBoxLast.Size = new Size(156, 23);
            textBoxLast.TabIndex = 1;
            // 
            // textBoxAddress
            // 
            textBoxAddress.Location = new Point(172, 115);
            textBoxAddress.Name = "textBoxAddress";
            textBoxAddress.Size = new Size(234, 23);
            textBoxAddress.TabIndex = 2;
            // 
            // textBoxCity
            // 
            textBoxCity.Location = new Point(172, 144);
            textBoxCity.Name = "textBoxCity";
            textBoxCity.Size = new Size(156, 23);
            textBoxCity.TabIndex = 3;
            // 
            // textBoxState
            // 
            textBoxState.Location = new Point(172, 173);
            textBoxState.Name = "textBoxState";
            textBoxState.Size = new Size(156, 23);
            textBoxState.TabIndex = 4;
            // 
            // textmboxZip
            // 
            textmboxZip.Location = new Point(172, 202);
            textmboxZip.Mask = "00000-9999";
            textmboxZip.Name = "textmboxZip";
            textmboxZip.Size = new Size(100, 23);
            textmboxZip.TabIndex = 5;
            // 
            // buttonDisplay
            // 
            buttonDisplay.Location = new Point(472, 275);
            buttonDisplay.Name = "buttonDisplay";
            buttonDisplay.Size = new Size(104, 30);
            buttonDisplay.TabIndex = 6;
            buttonDisplay.Text = "Display Info";
            buttonDisplay.UseVisualStyleBackColor = true;
            buttonDisplay.Click += buttonDisplay_Click;
            // 
            // buttonReset
            // 
            buttonReset.Location = new Point(472, 311);
            buttonReset.Name = "buttonReset";
            buttonReset.Size = new Size(104, 30);
            buttonReset.TabIndex = 7;
            buttonReset.Text = "Clear";
            buttonReset.UseVisualStyleBackColor = true;
            buttonReset.Click += buttonReset_Click;
            // 
            // Exit
            // 
            Exit.Location = new Point(472, 347);
            Exit.Name = "Exit";
            Exit.Size = new Size(104, 30);
            Exit.TabIndex = 8;
            Exit.Text = "Exit";
            Exit.UseVisualStyleBackColor = true;
            Exit.Click += Exit_Click;
            // 
            // bigboxmailinginfo
            // 
            bigboxmailinginfo.Location = new Point(16, 22);
            bigboxmailinginfo.Name = "bigboxmailinginfo";
            bigboxmailinginfo.ReadOnly = true;
            bigboxmailinginfo.Size = new Size(212, 96);
            bigboxmailinginfo.TabIndex = 9;
            bigboxmailinginfo.Text = "";
            bigboxmailinginfo.UseWaitCursor = true;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(bigboxmailinginfo);
            groupBox1.Location = new Point(172, 258);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(243, 136);
            groupBox1.TabIndex = 10;
            groupBox1.TabStop = false;
            groupBox1.Text = "Mailing Info";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(87, 58);
            label1.Name = "label1";
            label1.Size = new Size(74, 17);
            label1.TabIndex = 11;
            label1.Text = "First Name:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(87, 87);
            label2.Name = "label2";
            label2.Size = new Size(73, 17);
            label2.TabIndex = 12;
            label2.Text = "Last Name:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(87, 116);
            label3.Name = "label3";
            label3.Size = new Size(59, 17);
            label3.TabIndex = 13;
            label3.Text = "Address:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(87, 145);
            label4.Name = "label4";
            label4.Size = new Size(32, 17);
            label4.TabIndex = 14;
            label4.Text = "City:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(87, 174);
            label5.Name = "label5";
            label5.Size = new Size(40, 17);
            label5.TabIndex = 15;
            label5.Text = "State:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(87, 203);
            label6.Name = "label6";
            label6.Size = new Size(29, 17);
            label6.TabIndex = 16;
            label6.Text = "Zip:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(groupBox1);
            Controls.Add(Exit);
            Controls.Add(buttonReset);
            Controls.Add(buttonDisplay);
            Controls.Add(textmboxZip);
            Controls.Add(textBoxState);
            Controls.Add(textBoxCity);
            Controls.Add(textBoxAddress);
            Controls.Add(textBoxLast);
            Controls.Add(textBoxNameeee);
            Name = "Form1";
            Text = "Mailing Label Info";
            groupBox1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxNameeee;
        private TextBox textBoxLast;
        private TextBox textBoxAddress;
        private TextBox textBoxCity;
        private TextBox textBoxState;
        private MaskedTextBox textmboxZip;
        private Button buttonDisplay;
        private Button buttonReset;
        private Button Exit;
        private RichTextBox bigboxmailinginfo;
        private GroupBox groupBox1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
    }
}
