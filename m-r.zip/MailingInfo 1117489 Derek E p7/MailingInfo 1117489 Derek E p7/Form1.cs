namespace MailingInfo_1117489_Derek_E_p7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBoxNameeee.Focus();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonDisplay_Click(object sender, EventArgs e)
        {
            string firstname = textBoxNameeee.Text;
            string lastname = textBoxLast.Text;
            string address = textBoxAddress.Text;
            string city = textBoxCity.Text;
            string state = textBoxState.Text;
            string zip = textmboxZip.Text;
            bigboxmailinginfo.Text = "" + firstname + " " + lastname + "\n" + address + "\n" + city + ", " + state + " " + zip + "";
        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            textBoxNameeee.Clear();
            textBoxLast.Clear();
            textBoxAddress.Clear();
            textBoxCity.Clear();
            textBoxState.Clear();
            textmboxZip.Clear();
            bigboxmailinginfo.Clear();
            textBoxNameeee.Focus();
        }
    }
}
