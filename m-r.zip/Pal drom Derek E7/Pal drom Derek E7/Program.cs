﻿namespace Pal_drom_Derek_E7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter a string to check for a palindrome");

            string input = Console.ReadLine();

            while (input != string.Empty)
            {
                bool pal = true;
                for (int start = 0, end = input.Length -1; start < end && pal; start++, end--)
                {
                    while (!char.IsLetterOrDigit(input[start]))
                    {
                        start++;
                    }
                    while (!char.IsLetterOrDigit(input[end]))
                    {
                        end--;
                    }
                    if (start >= end) break;
                    pal = char.ToLower(input[start]) == (char.ToLower(input[end]));


                }

                if (pal)
                {
                    Console.WriteLine("YA");
                }
                if (!pal)
                {
                    Console.WriteLine("NO");
                }

                Console.WriteLine("enter a string to check for a palindrome");

                input = Console.ReadLine();
            }


        }
    }
}
