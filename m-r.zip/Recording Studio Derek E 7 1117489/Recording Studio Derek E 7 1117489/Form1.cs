using System.CodeDom;

namespace Recording_Studio_Derek_E_7_1117489
{
    public partial class Form1 : Form
    {
        const double RECTIMEAMIN = (100.0 / 30);
        double AVGCHARGE = 0.0;
        int numberOGROUPS = 0;
        double totalchargesforallgroups = 0.0;


        public Form1()
        {
            InitializeComponent();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            int recTime;
            double totalCharges;

            try
            {
                recTime = int.Parse(textBoxRecordingTime.Text);
                totalCharges = recTime * RECTIMEAMIN;


                numberOGROUPS++;
                totalchargesforallgroups += totalCharges;
                AVGCHARGE = totalchargesforallgroups / numberOGROUPS;

                textBoxTotalNumberOfGroups.Text = numberOGROUPS.ToString();

                textBoxTotalCharges.Text = totalCharges.ToString("C");
                textBoxAverageCharge.Text = AVGCHARGE.ToString("C");
                textBoxTotalCharge.Text = totalchargesforallgroups.ToString("C");


            }



            catch
            {
                MessageBox.Show("ENTER A NUMBER");
                textBoxRecordingTime.Clear();
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxGroupName.Clear();
            textBoxAverageCharge.Clear();
            textBoxGroupName.Clear();
            textBoxTotalCharge.Clear();
            textBoxTotalCharges.Clear();
            textBoxRecordingTime.Clear();
            textBoxTotalNumberOfGroups.Clear();

            textBoxGroupName.Focus();
            AVGCHARGE = 0.0;
            numberOGROUPS = 0;
            totalchargesforallgroups = 0;

        }
    }
}
