﻿namespace Recording_Studio_Derek_E_7_1117489
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            textBoxGroupName = new TextBox();
            groupBox1 = new GroupBox();
            textBoxTotalCharges = new TextBox();
            textBoxAverageCharge = new TextBox();
            textBoxTotalNumberOfGroups = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            textBoxRecordingTime = new TextBox();
            textBoxTotalCharge = new TextBox();
            buttonCalculate = new Button();
            buttonClear = new Button();
            buttonExit = new Button();
            label7 = new Label();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F);
            label1.Location = new Point(50, 50);
            label1.Name = "label1";
            label1.Size = new Size(100, 21);
            label1.TabIndex = 0;
            label1.Text = "Group name:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F);
            label2.Location = new Point(50, 100);
            label2.Name = "label2";
            label2.Size = new Size(192, 21);
            label2.TabIndex = 1;
            label2.Text = "Recording Time (minutes):";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F);
            label3.Location = new Point(50, 150);
            label3.Name = "label3";
            label3.Size = new Size(96, 21);
            label3.TabIndex = 2;
            label3.Text = "Total charge:";
            // 
            // textBoxGroupName
            // 
            textBoxGroupName.Location = new Point(259, 52);
            textBoxGroupName.Name = "textBoxGroupName";
            textBoxGroupName.Size = new Size(130, 23);
            textBoxGroupName.TabIndex = 3;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBoxTotalCharges);
            groupBox1.Controls.Add(textBoxAverageCharge);
            groupBox1.Controls.Add(textBoxTotalNumberOfGroups);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Location = new Point(50, 227);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(339, 154);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            groupBox1.Text = "Summary";
            // 
            // textBoxTotalCharges
            // 
            textBoxTotalCharges.Location = new Point(203, 112);
            textBoxTotalCharges.Name = "textBoxTotalCharges";
            textBoxTotalCharges.ReadOnly = true;
            textBoxTotalCharges.Size = new Size(130, 23);
            textBoxTotalCharges.TabIndex = 8;
            // 
            // textBoxAverageCharge
            // 
            textBoxAverageCharge.Location = new Point(203, 72);
            textBoxAverageCharge.Name = "textBoxAverageCharge";
            textBoxAverageCharge.ReadOnly = true;
            textBoxAverageCharge.Size = new Size(130, 23);
            textBoxAverageCharge.TabIndex = 10;
            // 
            // textBoxTotalNumberOfGroups
            // 
            textBoxTotalNumberOfGroups.Location = new Point(203, 32);
            textBoxTotalNumberOfGroups.Name = "textBoxTotalNumberOfGroups";
            textBoxTotalNumberOfGroups.ReadOnly = true;
            textBoxTotalNumberOfGroups.Size = new Size(130, 23);
            textBoxTotalNumberOfGroups.TabIndex = 7;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F);
            label6.Location = new Point(6, 110);
            label6.Name = "label6";
            label6.Size = new Size(103, 21);
            label6.TabIndex = 9;
            label6.Text = "Total charges:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F);
            label5.Location = new Point(6, 70);
            label5.Name = "label5";
            label5.Size = new Size(121, 21);
            label5.TabIndex = 8;
            label5.Text = "Average charge:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F);
            label4.Location = new Point(6, 30);
            label4.Name = "label4";
            label4.Size = new Size(129, 21);
            label4.TabIndex = 7;
            label4.Text = "Total # of groups:";
            // 
            // textBoxRecordingTime
            // 
            textBoxRecordingTime.Location = new Point(259, 102);
            textBoxRecordingTime.Name = "textBoxRecordingTime";
            textBoxRecordingTime.Size = new Size(130, 23);
            textBoxRecordingTime.TabIndex = 5;
            // 
            // textBoxTotalCharge
            // 
            textBoxTotalCharge.Location = new Point(259, 152);
            textBoxTotalCharge.Name = "textBoxTotalCharge";
            textBoxTotalCharge.ReadOnly = true;
            textBoxTotalCharge.Size = new Size(130, 23);
            textBoxTotalCharge.TabIndex = 6;
            // 
            // buttonCalculate
            // 
            buttonCalculate.Location = new Point(442, 50);
            buttonCalculate.Name = "buttonCalculate";
            buttonCalculate.Size = new Size(274, 62);
            buttonCalculate.TabIndex = 7;
            buttonCalculate.Text = "&Calculate";
            buttonCalculate.UseVisualStyleBackColor = true;
            buttonCalculate.Click += buttonCalculate_Click;
            // 
            // buttonClear
            // 
            buttonClear.Location = new Point(442, 131);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(274, 62);
            buttonClear.TabIndex = 8;
            buttonClear.Text = "Clea&r";
            buttonClear.UseVisualStyleBackColor = true;
            buttonClear.Click += buttonClear_Click;
            // 
            // buttonExit
            // 
            buttonExit.Location = new Point(442, 265);
            buttonExit.Name = "buttonExit";
            buttonExit.Size = new Size(274, 88);
            buttonExit.TabIndex = 9;
            buttonExit.Text = "E&xit";
            buttonExit.UseVisualStyleBackColor = true;
            buttonExit.Click += buttonExit_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F);
            label7.Location = new Point(653, 360);
            label7.Name = "label7";
            label7.Size = new Size(63, 21);
            label7.TabIndex = 11;
            label7.Text = "Derek E";
            // 
            // Form1
            // 
            AcceptButton = buttonCalculate;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = buttonExit;
            ClientSize = new Size(800, 450);
            Controls.Add(label7);
            Controls.Add(buttonExit);
            Controls.Add(buttonClear);
            Controls.Add(buttonCalculate);
            Controls.Add(textBoxTotalCharge);
            Controls.Add(textBoxRecordingTime);
            Controls.Add(groupBox1);
            Controls.Add(textBoxGroupName);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Music Studio";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox textBoxGroupName;
        private GroupBox groupBox1;
        private TextBox textBoxTotalCharges;
        private TextBox textBoxAverageCharge;
        private TextBox textBoxTotalNumberOfGroups;
        private Label label6;
        private Label label5;
        private Label label4;
        private TextBox textBoxRecordingTime;
        private TextBox textBoxTotalCharge;
        private Button buttonCalculate;
        private Button buttonClear;
        private Button buttonExit;
        private Label label7;
    }
}
