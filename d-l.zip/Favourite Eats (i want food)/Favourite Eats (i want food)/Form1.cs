namespace Favourite_Eats__i_want_food_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupboxfood_Enter(object sender, EventArgs e)
        {

        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void breakfast_CheckedChanged(object sender, EventArgs e)
        {
            ResturauntLabel.Text = "RHOP";
            AddressLable.Text = "21856 Mid Atlantic Ridge 446554";
            telephoneLable.Text = "949-947-6848";
            picturefoodpic.Image = Properties.Resources.pancake;
        }

        private void Salads_CheckedChanged(object sender, EventArgs e)
        {
            ResturauntLabel.Text = "Grape Garden";
            AddressLable.Text = "77 Mt. Vesuvius Hill 22254";
            telephoneLable.Text = "345-248-9961";
            picturefoodpic.Image = Properties.Resources.salad;
        }

        private void Burgers_CheckedChanged(object sender, EventArgs e)
        {
            ResturauntLabel.Text = "Blue Jay (hmmm)";
            AddressLable.Text = "2 Redwood Antarctica Drive 00809";
            telephoneLable.Text = "116-766-1235";
            picturefoodpic.Image = Properties.Resources.borgor;
        }

        private void Chicken_CheckedChanged(object sender, EventArgs e)
        {
            ResturauntLabel.Text = "Watamelins Southern Chorkin";
            AddressLable.Text = "666 Freedisahdehlaacered Rd 001002";
            telephoneLable.Text = "658-887-1100";
            picturefoodpic.Image = Properties.Resources.chicken;
        }

        private void Chinese_CheckedChanged(object sender, EventArgs e)
        {
            ResturauntLabel.Text = "Lazy Bear Highway Unoffbranded Chinese";
            AddressLable.Text = "some lot in the bamboo ice jungle at coords 0, 96, 5";
            telephoneLable.Text = "we cant afford one yet. use a paper airplane. our food is the best and that isnt fake news. yum yum";
            picturefoodpic.Image = Properties.Resources.rice;
        }

        private void Pizza_CheckedChanged(object sender, EventArgs e)
        {
            ResturauntLabel.Text = "Papa Dreez";
            AddressLable.Text = "6 Italy Ave 45678";
            telephoneLable.Text = "123-987-5820";
            picturefoodpic.Image = Properties.Resources.piza;
        }

        private void Deserts_CheckedChanged(object sender, EventArgs e)
        {
            ResturauntLabel.Text = "Basket Robbing 13";
            AddressLable.Text = "156 Hungryhelpackackackack Blvd 21348";
            telephoneLable.Text = "213-987-4444";
            picturefoodpic.Image = Properties.Resources.icecream;
        }
    }
}
