﻿namespace Favourite_Eats__i_want_food_
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupboxfood = new GroupBox();
            Deserts = new RadioButton();
            Pizza = new RadioButton();
            Chinese = new RadioButton();
            Burgers = new RadioButton();
            Chicken = new RadioButton();
            Salads = new RadioButton();
            breakfast = new RadioButton();
            buttonExit = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            picturefoodpic = new PictureBox();
            ResturauntLabel = new Label();
            AddressLable = new Label();
            telephoneLable = new Label();
            groupboxfood.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picturefoodpic).BeginInit();
            SuspendLayout();
            // 
            // groupboxfood
            // 
            groupboxfood.Controls.Add(Deserts);
            groupboxfood.Controls.Add(Pizza);
            groupboxfood.Controls.Add(Chinese);
            groupboxfood.Controls.Add(Burgers);
            groupboxfood.Controls.Add(Chicken);
            groupboxfood.Controls.Add(Salads);
            groupboxfood.Controls.Add(breakfast);
            groupboxfood.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupboxfood.Location = new Point(71, 148);
            groupboxfood.Name = "groupboxfood";
            groupboxfood.Size = new Size(266, 338);
            groupboxfood.TabIndex = 0;
            groupboxfood.TabStop = false;
            groupboxfood.Text = "Foods:";
            groupboxfood.Enter += groupboxfood_Enter;
            // 
            // Deserts
            // 
            Deserts.AutoSize = true;
            Deserts.Font = new Font("Segoe UI", 15.75F);
            Deserts.Location = new Point(26, 280);
            Deserts.Name = "Deserts";
            Deserts.Size = new Size(100, 34);
            Deserts.TabIndex = 6;
            Deserts.TabStop = true;
            Deserts.Text = "Deserts";
            Deserts.UseVisualStyleBackColor = true;
            Deserts.CheckedChanged += Deserts_CheckedChanged;
            // 
            // Pizza
            // 
            Pizza.AutoSize = true;
            Pizza.Font = new Font("Segoe UI", 15.75F);
            Pizza.Location = new Point(26, 240);
            Pizza.Name = "Pizza";
            Pizza.Size = new Size(79, 34);
            Pizza.TabIndex = 5;
            Pizza.TabStop = true;
            Pizza.Text = "Pizza";
            Pizza.UseVisualStyleBackColor = true;
            Pizza.CheckedChanged += Pizza_CheckedChanged;
            // 
            // Chinese
            // 
            Chinese.AutoSize = true;
            Chinese.Font = new Font("Segoe UI", 15.75F);
            Chinese.Location = new Point(26, 200);
            Chinese.Name = "Chinese";
            Chinese.Size = new Size(104, 34);
            Chinese.TabIndex = 4;
            Chinese.TabStop = true;
            Chinese.Text = "Chinese";
            Chinese.UseVisualStyleBackColor = true;
            Chinese.CheckedChanged += Chinese_CheckedChanged;
            // 
            // Burgers
            // 
            Burgers.AutoSize = true;
            Burgers.Font = new Font("Segoe UI", 15.75F);
            Burgers.Location = new Point(26, 120);
            Burgers.Name = "Burgers";
            Burgers.Size = new Size(101, 34);
            Burgers.TabIndex = 2;
            Burgers.TabStop = true;
            Burgers.Text = "Burgers";
            Burgers.UseVisualStyleBackColor = true;
            Burgers.CheckedChanged += Burgers_CheckedChanged;
            // 
            // Chicken
            // 
            Chicken.AutoSize = true;
            Chicken.Font = new Font("Segoe UI", 15.75F);
            Chicken.Location = new Point(26, 160);
            Chicken.Name = "Chicken";
            Chicken.Size = new Size(155, 34);
            Chicken.TabIndex = 3;
            Chicken.TabStop = true;
            Chicken.Text = "Fried Chicken";
            Chicken.UseVisualStyleBackColor = true;
            Chicken.CheckedChanged += Chicken_CheckedChanged;
            // 
            // Salads
            // 
            Salads.AutoSize = true;
            Salads.Font = new Font("Segoe UI", 15.75F);
            Salads.Location = new Point(26, 80);
            Salads.Name = "Salads";
            Salads.Size = new Size(90, 34);
            Salads.TabIndex = 1;
            Salads.TabStop = true;
            Salads.Text = "Salads";
            Salads.UseVisualStyleBackColor = true;
            Salads.CheckedChanged += Salads_CheckedChanged;
            // 
            // breakfast
            // 
            breakfast.AutoSize = true;
            breakfast.Font = new Font("Segoe UI", 15.75F);
            breakfast.Location = new Point(26, 40);
            breakfast.Name = "breakfast";
            breakfast.Size = new Size(184, 34);
            breakfast.TabIndex = 0;
            breakfast.TabStop = true;
            breakfast.Text = "Classic Breakfast";
            breakfast.UseVisualStyleBackColor = true;
            breakfast.CheckedChanged += breakfast_CheckedChanged;
            // 
            // buttonExit
            // 
            buttonExit.Location = new Point(71, 553);
            buttonExit.Name = "buttonExit";
            buttonExit.Size = new Size(266, 44);
            buttonExit.TabIndex = 1;
            buttonExit.Text = "Exit";
            buttonExit.UseVisualStyleBackColor = true;
            buttonExit.Click += buttonExit_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(532, 188);
            label1.Name = "label1";
            label1.Size = new Size(133, 32);
            label1.TabIndex = 2;
            label1.Text = "Resturaunt:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(532, 268);
            label2.Name = "label2";
            label2.Size = new Size(103, 32);
            label2.TabIndex = 3;
            label2.Text = "Address:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(532, 350);
            label3.Name = "label3";
            label3.Size = new Size(131, 32);
            label3.TabIndex = 4;
            label3.Text = "Telephone:";
            // 
            // picturefoodpic
            // 
            picturefoodpic.Image = Properties.Resources.pancake;
            picturefoodpic.Location = new Point(532, 449);
            picturefoodpic.Name = "picturefoodpic";
            picturefoodpic.Size = new Size(379, 232);
            picturefoodpic.SizeMode = PictureBoxSizeMode.StretchImage;
            picturefoodpic.TabIndex = 5;
            picturefoodpic.TabStop = false;
            // 
            // ResturauntLabel
            // 
            ResturauntLabel.AutoSize = true;
            ResturauntLabel.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ResturauntLabel.Location = new Point(789, 197);
            ResturauntLabel.Name = "ResturauntLabel";
            ResturauntLabel.Size = new Size(23, 25);
            ResturauntLabel.TabIndex = 6;
            ResturauntLabel.Text = "o";
            // 
            // AddressLable
            // 
            AddressLable.AutoSize = true;
            AddressLable.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            AddressLable.Location = new Point(789, 275);
            AddressLable.Name = "AddressLable";
            AddressLable.Size = new Size(22, 25);
            AddressLable.TabIndex = 7;
            AddressLable.Text = "6";
            // 
            // telephoneLable
            // 
            telephoneLable.AutoSize = true;
            telephoneLable.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            telephoneLable.Location = new Point(789, 357);
            telephoneLable.Name = "telephoneLable";
            telephoneLable.Size = new Size(22, 25);
            telephoneLable.TabIndex = 8;
            telephoneLable.Text = "7";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1232, 766);
            Controls.Add(telephoneLable);
            Controls.Add(AddressLable);
            Controls.Add(ResturauntLabel);
            Controls.Add(picturefoodpic);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(buttonExit);
            Controls.Add(groupboxfood);
            Name = "Form1";
            Text = "Favourite Eats - Highly Reccomended";
            groupboxfood.ResumeLayout(false);
            groupboxfood.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)picturefoodpic).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupboxfood;
        private RadioButton Chinese;
        private RadioButton Chicken;
        private RadioButton Burgers;
        private RadioButton Salads;
        private RadioButton breakfast;
        private RadioButton Deserts;
        private RadioButton Pizza;
        private Button buttonExit;
        private Label label1;
        private Label label2;
        private Label label3;
        private PictureBox picturefoodpic;
        private Label ResturauntLabel;
        private Label AddressLable;
        private Label telephoneLable;
    }
}
