﻿namespace hzdgh
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] oddnumbers = { 1, 3, 5, 7, 9, 11, 13 };
            for (int i = 0; i < oddnumbers.Length; i++)
            {
                Console.WriteLine(oddnumbers[i]);
            }
            Console.WriteLine("");

            double[] randomDoubles = new double[4];
            for (int i = 0; i < randomDoubles.Length; i++)
            {
                Random rnd = new Random();
                randomDoubles[i] = rnd.NextDouble();
                Console.WriteLine(randomDoubles[i]);
            }
            Console.WriteLine("");

            string[] westernstates =
            {
                "Washington",
                "Oregon",
                "California",
                "Idaho",
                "Nevada",
                "Arizona",
                "Utah",
                "New Mexico",
                "Colorado",
                "Wyoming",
                "Montana"
            };
            for (int i = 0; i < westernstates.Length; i++)
            {
                Console.WriteLine(westernstates[i]);
            }
            Console.WriteLine("");

            bool[] passingGrades = { true, true, false, true, false, true, false, false };
            for (int i = 0; i < passingGrades.Length; i++)
            {
                if (passingGrades[i])
                {
                    Console.WriteLine("passing the class");
                }
                else
                {
                    Console.WriteLine("failing the class");
                }

            }
            Console.WriteLine("");

        }
    }
}
