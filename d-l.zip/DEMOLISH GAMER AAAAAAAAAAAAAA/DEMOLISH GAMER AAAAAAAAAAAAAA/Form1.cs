namespace DEMOLISH_GAMER_AAAAAAAAAAAAAA
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void additionnnnnnnnnnnnn_Click(object sender, EventArgs e)
        {
            //will start declairing number data type variablwes: int, long, double, single, decimal, bool(t/f), currency, 
            int number1, number2;
            int total = 0;

            //try to obtain number from ui... convert string val into int/numericalValue; use datatype.Parse(STRINGVALUE);
            //try-catch statement
            try
            {
                //get info frum ui here
                number1 = int.Parse(num1.Text);
                number2 = int.Parse(num2.Text);

                //do the calculations here!
                total = number1 + number2;

                //display the ruslut to the ui in the reuslt box SBSISDIOJFOSJFFJ OAIHFOAHFOHUQWWUWU
                //use .ToString()
                resulttezxtboxx.Text = total.ToString();

            }

            catch
            {
                //add a mesg box to teel the user that they are dumb + also clear the textboxes and set focus to first box
                MessageBox.Show("You have entered an invalid number or letter value. Please try again and be smarter.");
                num1.Clear();
                num2.Clear();
                num1.Focus();

            }
        }

        private void suuuuuuuuuuuuuuubtract_Click(object sender, EventArgs e)
        {
            int number1, number2;
            int total = 0;
            try
            {
                //get info frum ui here
                number1 = int.Parse(num1.Text);
                number2 = int.Parse(num2.Text);

                //do the calculations here!
                total = number1 - number2;

                //display the ruslut to the ui in the reuslt box SBSISDIOJFOSJFFJ OAIHFOAHFOHUQWWUWU
                //use .ToString()
                resulttezxtboxx.Text = total.ToString();

            }

            catch
            {
                //add a mesg box to teel the user that they are dumb + also clear the textboxes and set focus to first box
                MessageBox.Show("You have entered an invalid number or letter value. Please try again and be smarter.");
                num1.Clear();
                num2.Clear();
                num1.Focus();

            }
        }

        private void multiplyyyyyyyyyy_Click(object sender, EventArgs e)
        {
            int number1, number2;
            int total = 0;
            try
            {
                //get info frum ui here
                number1 = int.Parse(num1.Text);
                number2 = int.Parse(num2.Text);

                //do the calculations here!
                total = number1 * number2;

                //display the ruslut to the ui in the reuslt box SBSISDIOJFOSJFFJ OAIHFOAHFOHUQWWUWU
                //use .ToString()
                resulttezxtboxx.Text = total.ToString();

            }

            catch
            {
                //add a mesg box to teel the user that they are dumb + also clear the textboxes and set focus to first box
                MessageBox.Show("You have entered an invalid number or letter value. Please try again and be smarter.");
                num1.Clear();
                num2.Clear();
                num1.Focus();

            }
        }

        private void divvvvvvvvvvvvvvvvvvvvvvvvvvvvvR_Click(object sender, EventArgs e)
        {
            int number1, number2;
            int total = 0;
            try
            {
                //get info frum ui here
                number1 = int.Parse(num1.Text);
                number2 = int.Parse(num2.Text);

                //do the calculations here!
                total = number1 / number2;

                //display the ruslut to the ui in the reuslt box SBSISDIOJFOSJFFJ OAIHFOAHFOHUQWWUWU
                //use .ToString()
                resulttezxtboxx.Text = total.ToString();

            }

            catch
            {
                //add a mesg box to teel the user that they are dumb + also clear the textboxes and set focus to first box
                MessageBox.Show("You have entered an invalid number or letter value. Please try again and be smarter.");
                num1.Clear();
                num2.Clear();
                num1.Focus();

            }
        }

        private void intdivvvvvvvvvvvv_Click(object sender, EventArgs e)
        //THIS IS ACTUALLY REAL DIV
        {
            int number1, number2;
            double total = 0;
            try
            {
                //get info frum ui here
                number1 = int.Parse(num1.Text);
                number2 = int.Parse(num2.Text);

                //do the calculations here!
                //CAST THE NUMBERAYOR YTO A DOUBLE VALKUE
                // use (double). can be real double, simgle, decimal

                total = (double)number1 / number2;

                //display the ruslut to the ui in the reuslt box SBSISDIOJFOSJFFJ OAIHFOAHFOHUQWWUWU
                //use .ToString()

                //formatg>: C = currency - rounds off to 2 dec and puts $ idk, N# = ?, P# = %
                resulttezxtboxx.Text = total.ToString("N5");

            }

            catch
            {
                //add a mesg box to teel the user that they are dumb + also clear the textboxes and set focus to first box
                MessageBox.Show("You have entered an invalid number or letter value. Please try again and be smarter.");
                num1.Clear();
                num2.Clear();
                num1.Focus();

            }
        }

        private void perectittttttttttttttttttttttttttttttttayo_Click(object sender, EventArgs e)
        {
            int number1, number2;
            int total = 0;
            try
            {
                //get info frum ui here
                number1 = int.Parse(num1.Text);
                number2 = int.Parse(num2.Text);

                //do the calculations here!
                total = number1 % number2;

                //display the ruslut to the ui in the reuslt box SBSISDIOJFOSJFFJ OAIHFOAHFOHUQWWUWU
                //use .ToString()
                resulttezxtboxx.Text = total.ToString();

            }

            catch
            {
                //add a mesg box to teel the user that they are dumb + also clear the textboxes and set focus to first box
                MessageBox.Show("You have entered an invalid number or letter value. Please try again and be smarter.");
                num1.Clear();
                num2.Clear();
                num1.Focus();

            }
        }

        private void ex8it_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
