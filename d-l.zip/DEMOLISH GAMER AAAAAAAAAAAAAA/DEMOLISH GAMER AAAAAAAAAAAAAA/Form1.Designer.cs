﻿namespace DEMOLISH_GAMER_AAAAAAAAAAAAAA
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            num1 = new TextBox();
            num2 = new TextBox();
            resulttezxtboxx = new TextBox();
            additionnnnnnnnnnnnn = new Button();
            suuuuuuuuuuuuuuubtract = new Button();
            multiplyyyyyyyyyy = new Button();
            intdivvvvvvvvvvvv = new Button();
            perectittttttttttttttttttttttttttttttttayo = new Button();
            divvvvvvvvvvvvvvvvvvvvvvvvvvvvvR = new Button();
            ex8it = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(135, 115);
            label1.Name = "label1";
            label1.Size = new Size(40, 15);
            label1.TabIndex = 0;
            label1.Text = "Num1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(135, 197);
            label2.Name = "label2";
            label2.Size = new Size(40, 15);
            label2.TabIndex = 1;
            label2.Text = "Num2";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(135, 276);
            label3.Name = "label3";
            label3.Size = new Size(39, 15);
            label3.TabIndex = 2;
            label3.Text = "Result";
            // 
            // num1
            // 
            num1.Location = new Point(195, 112);
            num1.Name = "num1";
            num1.Size = new Size(133, 23);
            num1.TabIndex = 3;
            // 
            // num2
            // 
            num2.Location = new Point(195, 194);
            num2.Name = "num2";
            num2.Size = new Size(133, 23);
            num2.TabIndex = 4;
            // 
            // resulttezxtboxx
            // 
            resulttezxtboxx.Location = new Point(195, 273);
            resulttezxtboxx.Name = "resulttezxtboxx";
            resulttezxtboxx.Size = new Size(133, 23);
            resulttezxtboxx.TabIndex = 5;
            // 
            // additionnnnnnnnnnnnn
            // 
            additionnnnnnnnnnnnn.Location = new Point(455, 85);
            additionnnnnnnnnnnnn.Name = "additionnnnnnnnnnnnn";
            additionnnnnnnnnnnnn.Size = new Size(74, 50);
            additionnnnnnnnnnnnn.TabIndex = 6;
            additionnnnnnnnnnnnn.Text = "+";
            additionnnnnnnnnnnnn.UseVisualStyleBackColor = true;
            additionnnnnnnnnnnnn.Click += additionnnnnnnnnnnnn_Click;
            // 
            // suuuuuuuuuuuuuuubtract
            // 
            suuuuuuuuuuuuuuubtract.Location = new Point(455, 141);
            suuuuuuuuuuuuuuubtract.Name = "suuuuuuuuuuuuuuubtract";
            suuuuuuuuuuuuuuubtract.Size = new Size(74, 50);
            suuuuuuuuuuuuuuubtract.TabIndex = 7;
            suuuuuuuuuuuuuuubtract.Text = "-";
            suuuuuuuuuuuuuuubtract.UseVisualStyleBackColor = true;
            suuuuuuuuuuuuuuubtract.Click += suuuuuuuuuuuuuuubtract_Click;
            // 
            // multiplyyyyyyyyyy
            // 
            multiplyyyyyyyyyy.Location = new Point(455, 197);
            multiplyyyyyyyyyy.Name = "multiplyyyyyyyyyy";
            multiplyyyyyyyyyy.Size = new Size(74, 50);
            multiplyyyyyyyyyy.TabIndex = 8;
            multiplyyyyyyyyyy.Text = "x";
            multiplyyyyyyyyyy.UseVisualStyleBackColor = true;
            multiplyyyyyyyyyy.Click += multiplyyyyyyyyyy_Click;
            // 
            // intdivvvvvvvvvvvv
            // 
            intdivvvvvvvvvvvv.Location = new Point(535, 85);
            intdivvvvvvvvvvvv.Name = "intdivvvvvvvvvvvv";
            intdivvvvvvvvvvvv.Size = new Size(74, 50);
            intdivvvvvvvvvvvv.TabIndex = 9;
            intdivvvvvvvvvvvv.Text = "/";
            intdivvvvvvvvvvvv.UseVisualStyleBackColor = true;
            intdivvvvvvvvvvvv.Click += intdivvvvvvvvvvvv_Click;
            // 
            // perectittttttttttttttttttttttttttttttttayo
            // 
            perectittttttttttttttttttttttttttttttttayo.Location = new Point(535, 141);
            perectittttttttttttttttttttttttttttttttayo.Name = "perectittttttttttttttttttttttttttttttttayo";
            perectittttttttttttttttttttttttttttttttayo.Size = new Size(74, 50);
            perectittttttttttttttttttttttttttttttttayo.TabIndex = 10;
            perectittttttttttttttttttttttttttttttttayo.Text = "%";
            perectittttttttttttttttttttttttttttttttayo.UseVisualStyleBackColor = true;
            perectittttttttttttttttttttttttttttttttayo.Click += perectittttttttttttttttttttttttttttttttayo_Click;
            // 
            // divvvvvvvvvvvvvvvvvvvvvvvvvvvvvR
            // 
            divvvvvvvvvvvvvvvvvvvvvvvvvvvvvR.Location = new Point(535, 194);
            divvvvvvvvvvvvvvvvvvvvvvvvvvvvvR.Name = "divvvvvvvvvvvvvvvvvvvvvvvvvvvvvR";
            divvvvvvvvvvvvvvvvvvvvvvvvvvvvvR.Size = new Size(74, 50);
            divvvvvvvvvvvvvvvvvvvvvvvvvvvvvR.TabIndex = 11;
            divvvvvvvvvvvvvvvvvvvvvvvvvvvvvR.Text = "i/";
            divvvvvvvvvvvvvvvvvvvvvvvvvvvvvR.UseVisualStyleBackColor = true;
            divvvvvvvvvvvvvvvvvvvvvvvvvvvvvR.Click += divvvvvvvvvvvvvvvvvvvvvvvvvvvvvR_Click;
            // 
            // ex8it
            // 
            ex8it.Location = new Point(479, 359);
            ex8it.Name = "ex8it";
            ex8it.Size = new Size(167, 43);
            ex8it.TabIndex = 12;
            ex8it.Text = "&xei";
            ex8it.UseVisualStyleBackColor = true;
            ex8it.Click += ex8it_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = ex8it;
            ClientSize = new Size(800, 450);
            Controls.Add(ex8it);
            Controls.Add(divvvvvvvvvvvvvvvvvvvvvvvvvvvvvR);
            Controls.Add(perectittttttttttttttttttttttttttttttttayo);
            Controls.Add(intdivvvvvvvvvvvv);
            Controls.Add(multiplyyyyyyyyyy);
            Controls.Add(suuuuuuuuuuuuuuubtract);
            Controls.Add(additionnnnnnnnnnnnn);
            Controls.Add(resulttezxtboxx);
            Controls.Add(num2);
            Controls.Add(num1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Unit 3 Demo";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox num1;
        private TextBox num2;
        private TextBox resulttezxtboxx;
        private Button additionnnnnnnnnnnnn;
        private Button suuuuuuuuuuuuuuubtract;
        private Button multiplyyyyyyyyyy;
        private Button intdivvvvvvvvvvvv;
        private Button perectittttttttttttttttttttttttttttttttayo;
        private Button divvvvvvvvvvvvvvvvvvvvvvvvvvvvvR;
        private Button ex8it;
    }
}
