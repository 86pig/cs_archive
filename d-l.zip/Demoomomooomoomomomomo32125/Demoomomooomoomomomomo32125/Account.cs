﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demoomomooomoomomomomo32125
{
    internal class Account
    {
        public int AccNum { get; set; }
        public string First {  get; set; }
        public string Last { get; set; }
        public decimal Balance { get; set; }
        public DateTime AccDateTimeOpened { get; set; }
        
        public Account() { }
        public Account(int n, string f, string l, decimal b, DateTime dt)
        {
            AccNum = n;
            First = f;
            Last = l;
            Balance = b;
            AccDateTimeOpened = dt;
        }
        public Account(int n, string f, string l, decimal b) : this (n, f, l, b, DateTime.Today)
        {

        }
    }
}
