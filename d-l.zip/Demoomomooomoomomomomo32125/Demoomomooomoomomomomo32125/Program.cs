﻿using System.Text.Json;

namespace Demoomomooomoomomomomo32125
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string output = "output.txt";
            StreamWriter writer = new StreamWriter("output.txt", false);
            for (int i = 0; i < 10; i++)
            {
                writer.Write(i + "\r\n");
            }
            writer.Flush(); 
            writer.Close();
            StreamReader reader = new StreamReader(output);
            string line = reader.ReadLine();
            while (line != null)
            {
                Console.WriteLine(line);
                line = reader.ReadLine();
            }
            List<Account> accounts = new List<Account>();
            accounts.Add(new Account(440405, "Person1F", "Person1L", 2043.22m));
            accounts.Add(new Account(544458, "Person2F", "Person2L", 1000m));
            accounts.Add(new Account(928379, "Person3F", "Person3L", 6979.88m));
            string json = JsonSerializer.Serialize(accounts);
            string acjson = "accounts.json";
            writer = new StreamWriter(acjson, false);
            writer.Write(json);
            writer.Close();
            writer.Flush();
            reader = new StreamReader(acjson);
            string accstring = reader.ReadToEnd();
            var acclist = JsonSerializer.Deserialize<List<Account>>(accstring);

        }
    }
}
