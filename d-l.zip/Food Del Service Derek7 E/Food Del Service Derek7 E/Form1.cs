namespace Food_Del_Service_Derek7_E
{
    public partial class Form1 : Form
    {
        const double TAXRATE = 0.082;
        double TIPTHINGY = 0.1;
        int CUSTOMER = 0;
        double TOTALSALES = 0.0;
        double TOTALTAXES = 0.0;
        double TOTALTIPS = 0.0;
        


        public Form1()
        {
            InitializeComponent();
            textBoxFoodTotal.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            double taxamount, subtotal, extendedamount, tipamount, totaldue, totaltotal, foodtotal, bevtotal;



            try
            {
                foodtotal = double.Parse(textBoxFoodTotal.Text);
                bevtotal = double.Parse(textBoxBeverageTotal.Text);


                subtotal = foodtotal + bevtotal;
                taxamount = subtotal * TAXRATE;
                extendedamount = subtotal + taxamount;
                tipamount = extendedamount * TIPTHINGY;
                totaldue = extendedamount + tipamount;

                textBoxSubtotal.Text = subtotal.ToString("C");
                textBoxTax.Text = taxamount.ToString("C");
                textBoxExtendedAmount.Text = extendedamount.ToString("C");
                textBoxTip.Text = tipamount.ToString("C");
                textBoxTotal.Text = totaldue.ToString("C");




                CUSTOMER++;
                textBoxNumberofCustomers.Text = CUSTOMER.ToString();

                TOTALSALES = TOTALSALES + subtotal;
                textBoxTotalSales.Text = TOTALSALES.ToString("C");

                TOTALTAXES = TOTALTAXES + taxamount;
                TOTALTIPS = TOTALTIPS + tipamount;

                textBoxTotalTaxes.Text = TOTALTAXES.ToString("C");
                textBoxTotalTips.Text = TOTALTAXES.ToString("C");


                labelName.Focus();
            }




            catch
            {
                MessageBox.Show("enter a number dimwitty");
                textBoxFoodTotal.Clear();
                textBoxBeverageTotal.Clear();
                textBoxSubtotal.Clear();
                textBoxTax.Clear();
                textBoxExtendedAmount.Clear();
                textBoxTotalSales.Clear();
                textBoxTip.Clear();
                textBoxTotal.Clear();
                radioButton10Percent.Checked = true;
                textBoxNumberofCustomers.Clear();
                textBoxTotalTaxes.Clear();
                textBoxTotalTips.Clear();
                textBoxFoodTotal.Focus();

            }
        }

        private void radioButton10Percent_CheckedChanged(object sender, EventArgs e)
        {
            TIPTHINGY = 0.1;
        }

        private void radioButton15Percent_CheckedChanged(object sender, EventArgs e)
        {
            TIPTHINGY = 0.15;
        }

        private void radioButton20Percent_CheckedChanged(object sender, EventArgs e)
        {
            TIPTHINGY = 0.2;
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxFoodTotal.Clear();
            textBoxBeverageTotal.Clear();
            textBoxSubtotal.Clear();
            textBoxTax.Clear();
            textBoxExtendedAmount.Clear();
            textBoxTotalSales.Clear();
            textBoxTip.Clear();
            textBoxTotal.Clear();
            radioButton10Percent.Checked = true;
            textBoxNumberofCustomers.Clear();
            textBoxTotalTaxes.Clear();
            textBoxTotalTips.Clear();
            textBoxFoodTotal.Focus();







        }
    }
}
