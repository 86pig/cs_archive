﻿namespace Food_Del_Service_Derek7_E
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            label13 = new Label();
            buttonClear = new Button();
            buttonCalculate = new Button();
            radioButton15Percent = new RadioButton();
            radioButton20Percent = new RadioButton();
            radioButton10Percent = new RadioButton();
            textBoxTotal = new TextBox();
            textBoxTip = new TextBox();
            textBoxExtendedAmount = new TextBox();
            textBoxTax = new TextBox();
            textBoxSubtotal = new TextBox();
            textBox3 = new TextBox();
            textBoxBeverageTotal = new TextBox();
            textBoxFoodTotal = new TextBox();
            label8 = new Label();
            label6 = new Label();
            label7 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            groupBox2 = new GroupBox();
            textBoxTotalTips = new TextBox();
            textBoxTotalTaxes = new TextBox();
            textBoxTotalSales = new TextBox();
            textBoxNumberofCustomers = new TextBox();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            buttonExit = new Button();
            labelName = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(buttonClear);
            groupBox1.Controls.Add(buttonCalculate);
            groupBox1.Controls.Add(radioButton15Percent);
            groupBox1.Controls.Add(radioButton20Percent);
            groupBox1.Controls.Add(radioButton10Percent);
            groupBox1.Controls.Add(textBoxTotal);
            groupBox1.Controls.Add(textBoxTip);
            groupBox1.Controls.Add(textBoxExtendedAmount);
            groupBox1.Controls.Add(textBoxTax);
            groupBox1.Controls.Add(textBoxSubtotal);
            groupBox1.Controls.Add(textBox3);
            groupBox1.Controls.Add(textBoxBeverageTotal);
            groupBox1.Controls.Add(textBoxFoodTotal);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(12, 24);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(250, 352);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Order";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(4, 195);
            label13.Name = "label13";
            label13.Size = new Size(26, 15);
            label13.TabIndex = 15;
            label13.Text = "Tip:";
            // 
            // buttonClear
            // 
            buttonClear.Location = new Point(127, 323);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(117, 23);
            buttonClear.TabIndex = 14;
            buttonClear.Text = "Clear";
            buttonClear.UseVisualStyleBackColor = true;
            buttonClear.Click += buttonClear_Click;
            // 
            // buttonCalculate
            // 
            buttonCalculate.Location = new Point(6, 323);
            buttonCalculate.Name = "buttonCalculate";
            buttonCalculate.Size = new Size(115, 23);
            buttonCalculate.TabIndex = 2;
            buttonCalculate.Text = "Calculate";
            buttonCalculate.UseVisualStyleBackColor = true;
            buttonCalculate.Click += buttonCalculate_Click;
            // 
            // radioButton15Percent
            // 
            radioButton15Percent.AutoSize = true;
            radioButton15Percent.Location = new Point(91, 195);
            radioButton15Percent.Name = "radioButton15Percent";
            radioButton15Percent.Size = new Size(47, 19);
            radioButton15Percent.TabIndex = 13;
            radioButton15Percent.Text = "15%";
            radioButton15Percent.UseVisualStyleBackColor = true;
            radioButton15Percent.CheckedChanged += radioButton15Percent_CheckedChanged;
            // 
            // radioButton20Percent
            // 
            radioButton20Percent.AutoSize = true;
            radioButton20Percent.Location = new Point(144, 195);
            radioButton20Percent.Name = "radioButton20Percent";
            radioButton20Percent.Size = new Size(47, 19);
            radioButton20Percent.TabIndex = 12;
            radioButton20Percent.Text = "20%";
            radioButton20Percent.UseVisualStyleBackColor = true;
            radioButton20Percent.CheckedChanged += radioButton20Percent_CheckedChanged;
            // 
            // radioButton10Percent
            // 
            radioButton10Percent.AutoSize = true;
            radioButton10Percent.Checked = true;
            radioButton10Percent.Location = new Point(38, 195);
            radioButton10Percent.Name = "radioButton10Percent";
            radioButton10Percent.Size = new Size(47, 19);
            radioButton10Percent.TabIndex = 11;
            radioButton10Percent.TabStop = true;
            radioButton10Percent.Text = "10%";
            radioButton10Percent.UseVisualStyleBackColor = true;
            radioButton10Percent.CheckedChanged += radioButton10Percent_CheckedChanged;
            // 
            // textBoxTotal
            // 
            textBoxTotal.Location = new Point(144, 266);
            textBoxTotal.Name = "textBoxTotal";
            textBoxTotal.ReadOnly = true;
            textBoxTotal.Size = new Size(100, 23);
            textBoxTotal.TabIndex = 10;
            // 
            // textBoxTip
            // 
            textBoxTip.Location = new Point(144, 236);
            textBoxTip.Name = "textBoxTip";
            textBoxTip.ReadOnly = true;
            textBoxTip.Size = new Size(100, 23);
            textBoxTip.TabIndex = 9;
            // 
            // textBoxExtendedAmount
            // 
            textBoxExtendedAmount.Location = new Point(144, 148);
            textBoxExtendedAmount.Name = "textBoxExtendedAmount";
            textBoxExtendedAmount.ReadOnly = true;
            textBoxExtendedAmount.Size = new Size(100, 23);
            textBoxExtendedAmount.TabIndex = 8;
            // 
            // textBoxTax
            // 
            textBoxTax.Location = new Point(144, 119);
            textBoxTax.Name = "textBoxTax";
            textBoxTax.ReadOnly = true;
            textBoxTax.Size = new Size(100, 23);
            textBoxTax.TabIndex = 7;
            // 
            // textBoxSubtotal
            // 
            textBoxSubtotal.Location = new Point(144, 85);
            textBoxSubtotal.Name = "textBoxSubtotal";
            textBoxSubtotal.ReadOnly = true;
            textBoxSubtotal.Size = new Size(100, 23);
            textBoxSubtotal.TabIndex = 6;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(144, 88);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(100, 23);
            textBox3.TabIndex = 6;
            // 
            // textBoxBeverageTotal
            // 
            textBoxBeverageTotal.Location = new Point(144, 59);
            textBoxBeverageTotal.Name = "textBoxBeverageTotal";
            textBoxBeverageTotal.Size = new Size(100, 23);
            textBoxBeverageTotal.TabIndex = 5;
            // 
            // textBoxFoodTotal
            // 
            textBoxFoodTotal.Location = new Point(144, 29);
            textBoxFoodTotal.Name = "textBoxFoodTotal";
            textBoxFoodTotal.Size = new Size(100, 23);
            textBoxFoodTotal.TabIndex = 4;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(6, 266);
            label8.Name = "label8";
            label8.Size = new Size(32, 15);
            label8.TabIndex = 2;
            label8.Text = "Total";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(6, 269);
            label6.Name = "label6";
            label6.Size = new Size(32, 15);
            label6.TabIndex = 2;
            label6.Text = "Total";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(6, 239);
            label7.Name = "label7";
            label7.Size = new Size(23, 15);
            label7.TabIndex = 3;
            label7.Text = "Tip";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(6, 152);
            label5.Name = "label5";
            label5.Size = new Size(103, 15);
            label5.TabIndex = 1;
            label5.Text = "Extended Amount";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 122);
            label4.Name = "label4";
            label4.Size = new Size(24, 15);
            label4.TabIndex = 1;
            label4.Text = "Tax";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 92);
            label3.Name = "label3";
            label3.Size = new Size(51, 15);
            label3.TabIndex = 1;
            label3.Text = "Subtotal";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 62);
            label2.Name = "label2";
            label2.Size = new Size(83, 15);
            label2.TabIndex = 1;
            label2.Text = "Beverage Total";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 32);
            label1.Name = "label1";
            label1.Size = new Size(62, 15);
            label1.TabIndex = 0;
            label1.Text = "Food Total";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(textBoxTotalTips);
            groupBox2.Controls.Add(textBoxTotalTaxes);
            groupBox2.Controls.Add(textBoxTotalSales);
            groupBox2.Controls.Add(textBoxNumberofCustomers);
            groupBox2.Controls.Add(label12);
            groupBox2.Controls.Add(label11);
            groupBox2.Controls.Add(label10);
            groupBox2.Controls.Add(label9);
            groupBox2.Location = new Point(302, 24);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(272, 167);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Overall Sales";
            // 
            // textBoxTotalTips
            // 
            textBoxTotalTips.Location = new Point(166, 119);
            textBoxTotalTips.Name = "textBoxTotalTips";
            textBoxTotalTips.ReadOnly = true;
            textBoxTotalTips.Size = new Size(100, 23);
            textBoxTotalTips.TabIndex = 20;
            // 
            // textBoxTotalTaxes
            // 
            textBoxTotalTaxes.Location = new Point(166, 89);
            textBoxTotalTaxes.Name = "textBoxTotalTaxes";
            textBoxTotalTaxes.ReadOnly = true;
            textBoxTotalTaxes.Size = new Size(100, 23);
            textBoxTotalTaxes.TabIndex = 19;
            // 
            // textBoxTotalSales
            // 
            textBoxTotalSales.Location = new Point(166, 59);
            textBoxTotalSales.Name = "textBoxTotalSales";
            textBoxTotalSales.ReadOnly = true;
            textBoxTotalSales.Size = new Size(100, 23);
            textBoxTotalSales.TabIndex = 18;
            // 
            // textBoxNumberofCustomers
            // 
            textBoxNumberofCustomers.Location = new Point(166, 29);
            textBoxNumberofCustomers.Name = "textBoxNumberofCustomers";
            textBoxNumberofCustomers.ReadOnly = true;
            textBoxNumberofCustomers.Size = new Size(100, 23);
            textBoxNumberofCustomers.TabIndex = 14;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(6, 122);
            label12.Name = "label12";
            label12.Size = new Size(69, 15);
            label12.TabIndex = 17;
            label12.Text = "Total in Tips";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(6, 92);
            label11.Name = "label11";
            label11.Size = new Size(63, 15);
            label11.TabIndex = 16;
            label11.Text = "Total Taxes";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(6, 62);
            label10.Name = "label10";
            label10.Size = new Size(61, 15);
            label10.TabIndex = 15;
            label10.Text = "Total Sales";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(6, 32);
            label9.Name = "label9";
            label9.Size = new Size(125, 15);
            label9.TabIndex = 14;
            label9.Text = "Number of Customers";
            // 
            // buttonExit
            // 
            buttonExit.Location = new Point(302, 219);
            buttonExit.Name = "buttonExit";
            buttonExit.Size = new Size(160, 151);
            buttonExit.TabIndex = 15;
            buttonExit.Text = "Exit";
            buttonExit.UseVisualStyleBackColor = true;
            buttonExit.Click += buttonExit_Click;
            // 
            // labelName
            // 
            labelName.AutoSize = true;
            labelName.Location = new Point(530, 361);
            labelName.Name = "labelName";
            labelName.Size = new Size(46, 15);
            labelName.TabIndex = 16;
            labelName.Text = "Derek E";
            // 
            // Form1
            // 
            AcceptButton = buttonCalculate;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = buttonExit;
            ClientSize = new Size(800, 450);
            Controls.Add(labelName);
            Controls.Add(buttonExit);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Food Delivery App";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox textBoxFoodTotal;
        private Label label6;
        private Label label7;
        private Label label5;
        private Label label3;
        private Label label2;
        private Label label1;
        private RadioButton radioButton15Percent;
        private RadioButton radioButton20Percent;
        private RadioButton radioButton10Percent;
        private TextBox textBoxTotal;
        private TextBox textBoxTip;
        private TextBox textBoxExtendedAmount;
        private TextBox textBoxTax;
        private TextBox textBoxSubtotal;
        private TextBox textBox3;
        private TextBox textBoxBeverageTotal;
        private Label label8;
        private Button buttonClear;
        private Button buttonCalculate;
        private GroupBox groupBox2;
        private TextBox textBoxTotalTips;
        private TextBox textBoxTotalTaxes;
        private TextBox textBoxTotalSales;
        private TextBox textBoxNumberofCustomers;
        private Label label12;
        private Label label11;
        private Label label10;
        private Label label9;
        private Button buttonExit;
        private Label labelName;
        private Label label13;
        private Label label4;
    }
}
