namespace Future_Value_Proj_Derek_E7_was_this_optional_;

public partial class Form1 : Form
{
    public Form1()
    {
        InitializeComponent();
    }
}
