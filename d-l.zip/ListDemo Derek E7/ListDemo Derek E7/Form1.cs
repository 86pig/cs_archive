﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListDemo_Derek_E7
{
    public partial class Form1 : Form
    {
        // create a list and include a data type
        List<double> sectionprices = new List<double>();

        //regualr array
        double[] totalsectionsales = new double[6];



        public Form1()
        {
            InitializeComponent();

            //use add mehtod
            sectionprices.Add(125);
            sectionprices.Add(85);
            sectionprices.Add(75);
            sectionprices.Add(65);
            sectionprices.Add(40);
            sectionprices.Add(15);
            //this adds new entries



        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttoncalc_Click(object sender, EventArgs e)
        {
            //check to see if something is selected in the comobooxooxowowowowowowowowoowuwuwuwuuwuwuwwuwuwuwumewo
            if (comboBoxSectoins.SelectedIndex != -1)
            {
                int index = comboBoxSectoins.SelectedIndex;
                double price = sectionprices[index];
                int quantity = (int)updownticketS.Value;
                double totalcost = price * quantity;

                //ip[date secopitms sales
                totalsectionsales[index] += totalcost;

                textBoxtotalcost.Text = totalcost.ToString("C");
            }
        }

        private void buttonshowttotalcost_Click(object sender, EventArgs e)
        {
            //loop thru the total section sales and dispaly back to the rick text box kisl

            string outpuit = "";

            for (int i = 0; i < totalsectionsales.Length; i++)
            {
                outpuit += comboBoxSectoins.Items[i] + ": " +
                    totalsectionsales[i].ToString("C") + "\n";
            }
            richTextBoxSecSales.Text = outpuit;


        }
    }
}
