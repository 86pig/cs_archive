﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.DirectoryServices.ActiveDirectory;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Juice_Survey_Derek_E7
{
    public partial class Summary : Form
    {
        public double WaterAverage { get; set; }
        public double IceAverage { get; set; }
        public double Testerss { get; set; }




        public Summary()
        {
            InitializeComponent();

        }

        private void Summary_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tiomerDisplays_Tick(object sender, EventArgs e)
        {
            labelWater.Text = (WaterAverage / Testerss).ToString();
            labelIcewater.Text = (IceAverage / Testerss).ToString();
            labelTesters.Text = Testerss.ToString();



            double realwaverage = WaterAverage / Testerss;
            double realiaverage = IceAverage / Testerss;

            if (double.Parse(labelWater.Text) == double.Parse(labelIcewater.Text))
            {
                labelWinner.Text = "It's a tie";

            }
            else if (double.Parse(labelWater.Text) > double.Parse(labelIcewater.Text))
            {
                labelWinner.Text = "Water wins";

            }
            else if (double.Parse(labelWater.Text) < double.Parse(labelIcewater.Text))
            {
                labelWinner.Text = "Ice water wins";
            }

            /*
            labelWater.Text = WaterAverage.ToString();
            labelIcewater.Text = IceAverage.ToString();
            labelTesters.Text = Testerss.ToString();

            if (double.Parse(labelWater.Text) == double.Parse(labelIcewater.Text))
            {
                labelWinner.Text = "its a tie!";
                labelWater.Text = WaterAverage.ToString();
                labelIcewater.Text = IceAverage.ToString();
                labelTesters.Text = Testerss.ToString();
            }
            else if (double.Parse(labelWater.Text) > double.Parse(labelIcewater.Text))
            {
                labelWinner.Text = "Water wins!";
                labelWater.Text = WaterAverage.ToString();
                labelIcewater.Text = IceAverage.ToString();
                labelTesters.Text = Testerss.ToString();
            }
            else if (double.Parse(labelWater.Text) < double.Parse(labelIcewater.Text))
            {
                labelWinner.Text = "Ice water wins!";
                labelWater.Text = WaterAverage.ToString();
                labelIcewater.Text = IceAverage.ToString();
                labelTesters.Text = Testerss.ToString();
            }
            */
            }
    }
}
