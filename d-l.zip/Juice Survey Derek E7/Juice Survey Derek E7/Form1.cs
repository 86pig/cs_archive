namespace Juice_Survey_Derek_E7
{
    public partial class Form1 : Form
    {
        double waterTotal = 0;
        double iceWaterTotal = 0;

        double testers = 0;

        //double wateraverage;
        //double iceaverage;

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addYourScoresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            { 
                double water = 0;
                double ice = 0; 

                if (numericUpDownWater.Value == 0 || numericUpDownIcewater.Value == 0)
                {
                    MessageBox.Show("Please enter a number above zero.");
                    return;
                }
                else
                {
                    water = (double)numericUpDownWater.Value;
                    ice = (double)numericUpDownIcewater.Value;
                }

                waterTotal += water;
                iceWaterTotal += ice;

                testers++;

                numericUpDownWater.Value = 0;
                numericUpDownIcewater.Value = 0;
                numericUpDownWater.Focus();
                

            }

            catch
            {
                MessageBox.Show("Invalid value. Please enter a valid value.");
            }

        }

        private void summaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //wateraverage = waterTotal / testers;
            //iceaverage = iceWaterTotal / testers;

            Summary summaryDlg = new Summary();

            summaryDlg.WaterAverage = waterTotal;
            summaryDlg.IceAverage = iceWaterTotal;
            summaryDlg.Testerss = testers;

            summaryDlg.ShowDialog();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About aboutDlg = new About();
            aboutDlg.ShowDialog();
        }
    }
}
// transfer info to other forms