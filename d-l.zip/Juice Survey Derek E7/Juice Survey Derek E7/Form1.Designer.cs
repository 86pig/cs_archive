﻿namespace Juice_Survey_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            exitToolStripMenuItem = new ToolStripMenuItem();
            ratingsToolStripMenuItem = new ToolStripMenuItem();
            addYourScoresToolStripMenuItem = new ToolStripMenuItem();
            summaryToolStripMenuItem = new ToolStripMenuItem();
            helpToolStripMenuItem = new ToolStripMenuItem();
            aboutToolStripMenuItem = new ToolStripMenuItem();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            numericUpDownWater = new NumericUpDown();
            numericUpDownIcewater = new NumericUpDown();
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownWater).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownIcewater).BeginInit();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem, ratingsToolStripMenuItem, helpToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(546, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { exitToolStripMenuItem });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(37, 20);
            fileToolStripMenuItem.Text = "File";
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(93, 22);
            exitToolStripMenuItem.Text = "Exit";
            exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;
            // 
            // ratingsToolStripMenuItem
            // 
            ratingsToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { addYourScoresToolStripMenuItem, summaryToolStripMenuItem });
            ratingsToolStripMenuItem.Name = "ratingsToolStripMenuItem";
            ratingsToolStripMenuItem.Size = new Size(58, 20);
            ratingsToolStripMenuItem.Text = "Ratings";
            // 
            // addYourScoresToolStripMenuItem
            // 
            addYourScoresToolStripMenuItem.Name = "addYourScoresToolStripMenuItem";
            addYourScoresToolStripMenuItem.Size = new Size(180, 22);
            addYourScoresToolStripMenuItem.Text = "Add your scores";
            addYourScoresToolStripMenuItem.Click += addYourScoresToolStripMenuItem_Click;
            // 
            // summaryToolStripMenuItem
            // 
            summaryToolStripMenuItem.Name = "summaryToolStripMenuItem";
            summaryToolStripMenuItem.Size = new Size(180, 22);
            summaryToolStripMenuItem.Text = "Summary";
            summaryToolStripMenuItem.Click += summaryToolStripMenuItem_Click;
            // 
            // helpToolStripMenuItem
            // 
            helpToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { aboutToolStripMenuItem });
            helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            helpToolStripMenuItem.Size = new Size(44, 20);
            helpToolStripMenuItem.Text = "Help";
            // 
            // aboutToolStripMenuItem
            // 
            aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            aboutToolStripMenuItem.Size = new Size(180, 22);
            aboutToolStripMenuItem.Text = "About";
            aboutToolStripMenuItem.Click += aboutToolStripMenuItem_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.waterJPG;
            pictureBox1.Location = new Point(12, 38);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(246, 154);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.icewaterJPG;
            pictureBox2.Location = new Point(273, 38);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(246, 154);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F);
            label1.Location = new Point(12, 212);
            label1.Name = "label1";
            label1.Size = new Size(43, 19);
            label1.TabIndex = 3;
            label1.Text = "Wa'er";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F);
            label2.Location = new Point(273, 212);
            label2.Name = "label2";
            label2.Size = new Size(70, 19);
            label2.TabIndex = 4;
            label2.Text = "Aice wa'er";
            // 
            // numericUpDownWater
            // 
            numericUpDownWater.Location = new Point(138, 208);
            numericUpDownWater.Maximum = new decimal(new int[] { 10, 0, 0, 0 });
            numericUpDownWater.Name = "numericUpDownWater";
            numericUpDownWater.ReadOnly = true;
            numericUpDownWater.Size = new Size(120, 23);
            numericUpDownWater.TabIndex = 5;
            // 
            // numericUpDownIcewater
            // 
            numericUpDownIcewater.Location = new Point(399, 208);
            numericUpDownIcewater.Maximum = new decimal(new int[] { 10, 0, 0, 0 });
            numericUpDownIcewater.Name = "numericUpDownIcewater";
            numericUpDownIcewater.ReadOnly = true;
            numericUpDownIcewater.Size = new Size(120, 23);
            numericUpDownIcewater.TabIndex = 6;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(546, 262);
            Controls.Add(numericUpDownIcewater);
            Controls.Add(numericUpDownWater);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Juice survey taste test";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownWater).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownIcewater).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private ToolStripMenuItem ratingsToolStripMenuItem;
        private ToolStripMenuItem addYourScoresToolStripMenuItem;
        private ToolStripMenuItem summaryToolStripMenuItem;
        private ToolStripMenuItem helpToolStripMenuItem;
        private ToolStripMenuItem aboutToolStripMenuItem;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private Label label1;
        private Label label2;
        private NumericUpDown numericUpDownWater;
        private NumericUpDown numericUpDownIcewater;
    }
}
