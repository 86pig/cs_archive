﻿namespace Juice_Survey_Derek_E7
{
    partial class Summary
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            labelWater = new Label();
            labelTesters = new Label();
            labelIcewater = new Label();
            label7 = new Label();
            button1 = new Button();
            labelWinner = new Label();
            tiomerDisplays = new System.Windows.Forms.Timer(components);
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(56, 54);
            label1.Name = "label1";
            label1.Size = new Size(38, 15);
            label1.TabIndex = 0;
            label1.Text = "Water";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(157, 54);
            label2.Name = "label2";
            label2.Size = new Size(42, 15);
            label2.TabIndex = 1;
            label2.Text = "Testers";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(261, 54);
            label3.Name = "label3";
            label3.Size = new Size(54, 15);
            label3.TabIndex = 2;
            label3.Text = "Ice water";
            // 
            // labelWater
            // 
            labelWater.AutoSize = true;
            labelWater.Location = new Point(56, 118);
            labelWater.Name = "labelWater";
            labelWater.Size = new Size(15, 15);
            labelWater.TabIndex = 3;
            labelWater.Text = "A";
            // 
            // labelTesters
            // 
            labelTesters.AutoSize = true;
            labelTesters.Location = new Point(157, 118);
            labelTesters.Name = "labelTesters";
            labelTesters.Size = new Size(15, 15);
            labelTesters.TabIndex = 4;
            labelTesters.Text = "A";
            // 
            // labelIcewater
            // 
            labelIcewater.AutoSize = true;
            labelIcewater.Location = new Point(277, 118);
            labelIcewater.Name = "labelIcewater";
            labelIcewater.Size = new Size(15, 15);
            labelIcewater.TabIndex = 5;
            labelIcewater.Text = "A";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(56, 194);
            label7.Name = "label7";
            label7.Size = new Size(48, 15);
            label7.TabIndex = 6;
            label7.Text = "Winner:";
            // 
            // button1
            // 
            button1.Location = new Point(248, 174);
            button1.Name = "button1";
            button1.Size = new Size(67, 35);
            button1.TabIndex = 7;
            button1.Text = "k";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // labelWinner
            // 
            labelWinner.AutoSize = true;
            labelWinner.Location = new Point(119, 194);
            labelWinner.Name = "labelWinner";
            labelWinner.Size = new Size(15, 15);
            labelWinner.TabIndex = 8;
            labelWinner.Text = "A";
            // 
            // tiomerDisplays
            // 
            tiomerDisplays.Enabled = true;
            tiomerDisplays.Interval = 2;
            tiomerDisplays.Tick += tiomerDisplays_Tick;
            // 
            // Summary
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(376, 260);
            Controls.Add(labelWinner);
            Controls.Add(button1);
            Controls.Add(label7);
            Controls.Add(labelIcewater);
            Controls.Add(labelTesters);
            Controls.Add(labelWater);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "Summary";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Summary";
            Load += Summary_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label labelWater;
        private Label labelTesters;
        private Label labelIcewater;
        private Label label7;
        private Button button1;
        private Label labelWinner;
        private System.Windows.Forms.Timer tiomerDisplays;
    }
}