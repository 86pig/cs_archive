namespace Flags_1117489_Derek_E_p7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Canada_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxflag.Image = Properties.Resources.canada;
            Namelabel.Text = "Canada";
        }

        private void UnitedK_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxflag.Image = Properties.Resources.uk;
            Namelabel.Text = "United Kingdom";
        }

        private void China_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxflag.Image = Properties.Resources.china;
            Namelabel.Text = "China";
        }

        private void France_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxflag.Image = Properties.Resources.france;
            Namelabel.Text = "France";
        }

        private void checkBoxTitle_CheckedChanged(object sender, EventArgs e)
        {
            TitleLabel.Visible = checkBoxTitle.Checked;
        }

        private void checkBoxFlag_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxflag.Visible = checkBoxFlag.Checked;
        }

        private void checkBoxCountry_CheckedChanged(object sender, EventArgs e)
        {
            Namelabel.Visible = checkBoxCountry.Checked;
        }

        private void checkBoxbox_CheckedChanged(object sender, EventArgs e)
        {
            boxCountries.Enabled = checkBoxbox.Checked;
        }
    }
}
