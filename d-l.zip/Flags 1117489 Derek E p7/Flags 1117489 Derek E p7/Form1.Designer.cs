﻿namespace Flags_1117489_Derek_E_p7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            boxCountries = new GroupBox();
            France = new RadioButton();
            China = new RadioButton();
            UnitedK = new RadioButton();
            Canada = new RadioButton();
            checkBoxTitle = new CheckBox();
            checkBoxCountry = new CheckBox();
            checkBoxFlag = new CheckBox();
            Exit = new Button();
            TitleLabel = new Label();
            Namelabel = new Label();
            label2 = new Label();
            pictureBoxflag = new PictureBox();
            checkBoxbox = new CheckBox();
            boxCountries.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxflag).BeginInit();
            SuspendLayout();
            // 
            // boxCountries
            // 
            boxCountries.Controls.Add(France);
            boxCountries.Controls.Add(China);
            boxCountries.Controls.Add(UnitedK);
            boxCountries.Controls.Add(Canada);
            boxCountries.Font = new Font("Segoe UI Semibold", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            boxCountries.Location = new Point(57, 72);
            boxCountries.Name = "boxCountries";
            boxCountries.Size = new Size(237, 266);
            boxCountries.TabIndex = 0;
            boxCountries.TabStop = false;
            boxCountries.Text = "Countries";
            // 
            // France
            // 
            France.AutoSize = true;
            France.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            France.Location = new Point(25, 155);
            France.Name = "France";
            France.Size = new Size(86, 29);
            France.TabIndex = 3;
            France.TabStop = true;
            France.Text = "France";
            France.UseVisualStyleBackColor = true;
            France.CheckedChanged += France_CheckedChanged;
            // 
            // China
            // 
            China.AutoSize = true;
            China.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            China.Location = new Point(25, 120);
            China.Name = "China";
            China.Size = new Size(79, 29);
            China.TabIndex = 2;
            China.TabStop = true;
            China.Text = "China";
            China.UseVisualStyleBackColor = true;
            China.CheckedChanged += China_CheckedChanged;
            // 
            // UnitedK
            // 
            UnitedK.AutoSize = true;
            UnitedK.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            UnitedK.Location = new Point(25, 85);
            UnitedK.Name = "UnitedK";
            UnitedK.Size = new Size(167, 29);
            UnitedK.TabIndex = 1;
            UnitedK.TabStop = true;
            UnitedK.Text = "United Kingdom";
            UnitedK.UseVisualStyleBackColor = true;
            UnitedK.CheckedChanged += UnitedK_CheckedChanged;
            // 
            // Canada
            // 
            Canada.AutoSize = true;
            Canada.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Canada.Location = new Point(25, 50);
            Canada.Name = "Canada";
            Canada.Size = new Size(94, 29);
            Canada.TabIndex = 0;
            Canada.TabStop = true;
            Canada.Text = "Canada";
            Canada.UseVisualStyleBackColor = true;
            Canada.CheckedChanged += Canada_CheckedChanged;
            // 
            // checkBoxTitle
            // 
            checkBoxTitle.AutoSize = true;
            checkBoxTitle.Checked = true;
            checkBoxTitle.CheckState = CheckState.Checked;
            checkBoxTitle.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBoxTitle.Location = new Point(82, 393);
            checkBoxTitle.Name = "checkBoxTitle";
            checkBoxTitle.Size = new Size(101, 25);
            checkBoxTitle.TabIndex = 1;
            checkBoxTitle.Text = "Show Title";
            checkBoxTitle.UseVisualStyleBackColor = true;
            checkBoxTitle.CheckedChanged += checkBoxTitle_CheckedChanged;
            // 
            // checkBoxCountry
            // 
            checkBoxCountry.AutoSize = true;
            checkBoxCountry.Checked = true;
            checkBoxCountry.CheckState = CheckState.Checked;
            checkBoxCountry.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBoxCountry.Location = new Point(82, 424);
            checkBoxCountry.Name = "checkBoxCountry";
            checkBoxCountry.Size = new Size(174, 25);
            checkBoxCountry.TabIndex = 2;
            checkBoxCountry.Text = "Show Country Name";
            checkBoxCountry.UseVisualStyleBackColor = true;
            checkBoxCountry.CheckedChanged += checkBoxCountry_CheckedChanged;
            // 
            // checkBoxFlag
            // 
            checkBoxFlag.AutoSize = true;
            checkBoxFlag.Checked = true;
            checkBoxFlag.CheckState = CheckState.Checked;
            checkBoxFlag.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBoxFlag.Location = new Point(82, 455);
            checkBoxFlag.Name = "checkBoxFlag";
            checkBoxFlag.Size = new Size(101, 25);
            checkBoxFlag.TabIndex = 3;
            checkBoxFlag.Text = "Show Flag";
            checkBoxFlag.UseVisualStyleBackColor = true;
            checkBoxFlag.CheckedChanged += checkBoxFlag_CheckedChanged;
            // 
            // Exit
            // 
            Exit.Location = new Point(82, 598);
            Exit.Name = "Exit";
            Exit.Size = new Size(130, 41);
            Exit.TabIndex = 4;
            Exit.Text = "Exit";
            Exit.UseVisualStyleBackColor = true;
            Exit.Click += Exit_Click;
            // 
            // TitleLabel
            // 
            TitleLabel.AutoSize = true;
            TitleLabel.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            TitleLabel.Location = new Point(553, 90);
            TitleLabel.Name = "TitleLabel";
            TitleLabel.Size = new Size(72, 32);
            TitleLabel.TabIndex = 5;
            TitleLabel.Text = "Flags";
            // 
            // Namelabel
            // 
            Namelabel.AutoSize = true;
            Namelabel.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Namelabel.Location = new Point(553, 524);
            Namelabel.Name = "Namelabel";
            Namelabel.Size = new Size(81, 32);
            Namelabel.TabIndex = 6;
            Namelabel.Text = "Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(739, 607);
            label2.Name = "label2";
            label2.Size = new Size(108, 32);
            label2.TabIndex = 7;
            label2.Text = "Derek E.";
            // 
            // pictureBoxflag
            // 
            pictureBoxflag.Image = Properties.Resources.china;
            pictureBoxflag.Location = new Point(338, 157);
            pictureBoxflag.Name = "pictureBoxflag";
            pictureBoxflag.Size = new Size(509, 323);
            pictureBoxflag.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxflag.TabIndex = 8;
            pictureBoxflag.TabStop = false;
            // 
            // checkBoxbox
            // 
            checkBoxbox.AutoSize = true;
            checkBoxbox.Checked = true;
            checkBoxbox.CheckState = CheckState.Checked;
            checkBoxbox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBoxbox.Location = new Point(82, 486);
            checkBoxbox.Name = "checkBoxbox";
            checkBoxbox.Size = new Size(187, 25);
            checkBoxbox.TabIndex = 9;
            checkBoxbox.Text = "Show Country Options";
            checkBoxbox.UseVisualStyleBackColor = true;
            checkBoxbox.CheckedChanged += checkBoxbox_CheckedChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1622, 930);
            Controls.Add(checkBoxbox);
            Controls.Add(pictureBoxflag);
            Controls.Add(label2);
            Controls.Add(Namelabel);
            Controls.Add(TitleLabel);
            Controls.Add(Exit);
            Controls.Add(checkBoxFlag);
            Controls.Add(checkBoxCountry);
            Controls.Add(checkBoxTitle);
            Controls.Add(boxCountries);
            Name = "Form1";
            Text = "Country Flags";
            boxCountries.ResumeLayout(false);
            boxCountries.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxflag).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox boxCountries;
        private RadioButton France;
        private RadioButton China;
        private RadioButton UnitedK;
        private RadioButton Canada;
        private CheckBox checkBoxTitle;
        private CheckBox checkBoxCountry;
        private CheckBox checkBoxFlag;
        private Button Exit;
        private Label TitleLabel;
        private Label Namelabel;
        private Label label2;
        private PictureBox pictureBoxflag;
        private CheckBox checkBoxbox;
    }
}
