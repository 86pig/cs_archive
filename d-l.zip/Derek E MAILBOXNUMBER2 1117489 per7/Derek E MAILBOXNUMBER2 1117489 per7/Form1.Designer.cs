﻿namespace Derek_E_MAILBOXNUMBER2_1117489_per7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            CatalogCode = new TextBox();
            PageNumber = new TextBox();
            PartNumber = new TextBox();
            groupBox1 = new GroupBox();
            Priority = new RadioButton();
            Express = new RadioButton();
            Ground = new RadioButton();
            groupBox2 = new GroupBox();
            MoneyOrder = new RadioButton();
            Charge = new RadioButton();
            Cod = new RadioButton();
            checkBoxNEW = new CheckBox();
            groupBox3 = new GroupBox();
            Payment = new Label();
            Shipping = new Label();
            label3 = new Label();
            label2 = new Label();
            Newcustomerlabel = new Label();
            bigboxotextomasser = new RichTextBox();
            buttonDisplay = new Button();
            buttonClear = new Button();
            Exit = new Button();
            label4 = new Label();
            sdfsdfsdfd = new Label();
            sdfsdfsdfsdfsfsdf = new Label();
            sfsfsafasfsadfsdaff = new Label();
            radioButton1 = new RadioButton();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.MAILBVOXXXXXXXXXXXXXX;
            pictureBox1.Location = new Point(12, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(259, 162);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // CatalogCode
            // 
            CatalogCode.Location = new Point(93, 191);
            CatalogCode.Name = "CatalogCode";
            CatalogCode.Size = new Size(178, 23);
            CatalogCode.TabIndex = 1;
            // 
            // PageNumber
            // 
            PageNumber.Location = new Point(93, 220);
            PageNumber.Name = "PageNumber";
            PageNumber.Size = new Size(178, 23);
            PageNumber.TabIndex = 2;
            // 
            // PartNumber
            // 
            PartNumber.Location = new Point(93, 249);
            PartNumber.Name = "PartNumber";
            PartNumber.Size = new Size(178, 23);
            PartNumber.TabIndex = 3;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(Priority);
            groupBox1.Controls.Add(Express);
            groupBox1.Controls.Add(Ground);
            groupBox1.Location = new Point(12, 300);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(122, 95);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            groupBox1.Text = "Shipping";
            // 
            // Priority
            // 
            Priority.AutoSize = true;
            Priority.Location = new Point(6, 70);
            Priority.Name = "Priority";
            Priority.Size = new Size(63, 19);
            Priority.TabIndex = 8;
            Priority.TabStop = true;
            Priority.Text = "Priority";
            Priority.UseVisualStyleBackColor = true;
            Priority.CheckedChanged += Priority_CheckedChanged;
            // 
            // Express
            // 
            Express.AutoSize = true;
            Express.Location = new Point(6, 20);
            Express.Name = "Express";
            Express.Size = new Size(64, 19);
            Express.TabIndex = 6;
            Express.TabStop = true;
            Express.Text = "Express";
            Express.UseVisualStyleBackColor = true;
            Express.CheckedChanged += Express_CheckedChanged;
            // 
            // Ground
            // 
            Ground.AutoSize = true;
            Ground.Location = new Point(6, 45);
            Ground.Name = "Ground";
            Ground.Size = new Size(65, 19);
            Ground.TabIndex = 7;
            Ground.TabStop = true;
            Ground.Text = "Ground";
            Ground.UseVisualStyleBackColor = true;
            Ground.CheckedChanged += Ground_CheckedChanged;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(MoneyOrder);
            groupBox2.Controls.Add(Charge);
            groupBox2.Controls.Add(Cod);
            groupBox2.Location = new Point(140, 300);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(131, 95);
            groupBox2.TabIndex = 5;
            groupBox2.TabStop = false;
            groupBox2.Text = "Payment";
            // 
            // MoneyOrder
            // 
            MoneyOrder.AutoSize = true;
            MoneyOrder.Location = new Point(6, 70);
            MoneyOrder.Name = "MoneyOrder";
            MoneyOrder.Size = new Size(95, 19);
            MoneyOrder.TabIndex = 10;
            MoneyOrder.TabStop = true;
            MoneyOrder.Text = "Money Order";
            MoneyOrder.UseVisualStyleBackColor = true;
            MoneyOrder.CheckedChanged += MoneyOrder_CheckedChanged;
            // 
            // Charge
            // 
            Charge.AutoSize = true;
            Charge.Location = new Point(6, 20);
            Charge.Name = "Charge";
            Charge.Size = new Size(63, 19);
            Charge.TabIndex = 8;
            Charge.TabStop = true;
            Charge.Text = "Charge";
            Charge.UseVisualStyleBackColor = true;
            Charge.CheckedChanged += Charge_CheckedChanged;
            // 
            // Cod
            // 
            Cod.AutoSize = true;
            Cod.Location = new Point(6, 45);
            Cod.Name = "Cod";
            Cod.Size = new Size(50, 19);
            Cod.TabIndex = 9;
            Cod.TabStop = true;
            Cod.Text = "COD";
            Cod.UseVisualStyleBackColor = true;
            Cod.CheckedChanged += Cod_CheckedChanged;
            // 
            // checkBoxNEW
            // 
            checkBoxNEW.AutoSize = true;
            checkBoxNEW.Location = new Point(12, 412);
            checkBoxNEW.Name = "checkBoxNEW";
            checkBoxNEW.Size = new Size(510, 19);
            checkBoxNEW.TabIndex = 6;
            checkBoxNEW.Text = "New Customer??? Check this box!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!";
            checkBoxNEW.UseVisualStyleBackColor = true;
            checkBoxNEW.CheckedChanged += checkBoxNEW_CheckedChanged;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(Payment);
            groupBox3.Controls.Add(Shipping);
            groupBox3.Controls.Add(label3);
            groupBox3.Controls.Add(label2);
            groupBox3.Controls.Add(Newcustomerlabel);
            groupBox3.Controls.Add(bigboxotextomasser);
            groupBox3.Location = new Point(302, 12);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(303, 235);
            groupBox3.TabIndex = 8;
            groupBox3.TabStop = false;
            groupBox3.Text = "Order Summary";
            // 
            // Payment
            // 
            Payment.AutoSize = true;
            Payment.Location = new Point(106, 201);
            Payment.Name = "Payment";
            Payment.Size = new Size(22, 15);
            Payment.TabIndex = 5;
            Payment.Text = "---";
            // 
            // Shipping
            // 
            Shipping.AutoSize = true;
            Shipping.Location = new Point(106, 183);
            Shipping.Name = "Shipping";
            Shipping.Size = new Size(22, 15);
            Shipping.TabIndex = 4;
            Shipping.Text = "---";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 201);
            label3.Name = "label3";
            label3.Size = new Size(57, 15);
            label3.TabIndex = 3;
            label3.Text = "Payment:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 183);
            label2.Name = "label2";
            label2.Size = new Size(57, 15);
            label2.TabIndex = 2;
            label2.Text = "Shipping:";
            label2.Click += label2_Click;
            // 
            // Newcustomerlabel
            // 
            Newcustomerlabel.AutoSize = true;
            Newcustomerlabel.Location = new Point(6, 142);
            Newcustomerlabel.Name = "Newcustomerlabel";
            Newcustomerlabel.Size = new Size(0, 15);
            Newcustomerlabel.TabIndex = 1;
            Newcustomerlabel.Click += label1_Click;
            // 
            // bigboxotextomasser
            // 
            bigboxotextomasser.Location = new Point(6, 22);
            bigboxotextomasser.Name = "bigboxotextomasser";
            bigboxotextomasser.ReadOnly = true;
            bigboxotextomasser.Size = new Size(291, 107);
            bigboxotextomasser.TabIndex = 0;
            bigboxotextomasser.Text = "";
            // 
            // buttonDisplay
            // 
            buttonDisplay.Location = new Point(302, 263);
            buttonDisplay.Name = "buttonDisplay";
            buttonDisplay.Size = new Size(303, 34);
            buttonDisplay.TabIndex = 11;
            buttonDisplay.Text = "Display Info";
            buttonDisplay.UseVisualStyleBackColor = true;
            buttonDisplay.Click += buttonDisplay_Click;
            // 
            // buttonClear
            // 
            buttonClear.Location = new Point(302, 303);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(303, 34);
            buttonClear.TabIndex = 12;
            buttonClear.Text = "Clear";
            buttonClear.UseVisualStyleBackColor = true;
            buttonClear.Click += buttonClear_Click;
            // 
            // Exit
            // 
            Exit.Location = new Point(302, 361);
            Exit.Name = "Exit";
            Exit.Size = new Size(303, 34);
            Exit.TabIndex = 13;
            Exit.Text = "Exit";
            Exit.UseVisualStyleBackColor = true;
            Exit.Click += Exit_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(520, 409);
            label4.Name = "label4";
            label4.Size = new Size(85, 21);
            label4.TabIndex = 4;
            label4.Text = "Derek E p7";
            // 
            // sdfsdfsdfd
            // 
            sdfsdfsdfd.AutoSize = true;
            sdfsdfsdfd.Location = new Point(12, 194);
            sdfsdfsdfd.Name = "sdfsdfsdfd";
            sdfsdfsdfd.Size = new Size(79, 15);
            sdfsdfsdfd.TabIndex = 14;
            sdfsdfsdfd.Text = "Catalog Code";
            // 
            // sdfsdfsdfsdfsfsdf
            // 
            sdfsdfsdfsdfsfsdf.AutoSize = true;
            sdfsdfsdfsdfsfsdf.Location = new Point(12, 223);
            sdfsdfsdfsdfsfsdf.Name = "sdfsdfsdfsdfsfsdf";
            sdfsdfsdfsdfsfsdf.Size = new Size(80, 15);
            sdfsdfsdfsdfsfsdf.TabIndex = 15;
            sdfsdfsdfsdfsfsdf.Text = "Page Number";
            // 
            // sfsfsafasfsadfsdaff
            // 
            sfsfsafasfsadfsdaff.AutoSize = true;
            sfsfsafasfsadfsdaff.Location = new Point(12, 252);
            sfsfsafasfsadfsdaff.Name = "sfsfsafasfsadfsdaff";
            sfsfsafasfsadfsdaff.Size = new Size(75, 15);
            sfsfsafasfsadfsdaff.TabIndex = 16;
            sfsfsafasfsadfsdaff.Text = "Part Number";
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Checked = true;
            radioButton1.Location = new Point(648, 192);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(94, 19);
            radioButton1.TabIndex = 17;
            radioButton1.TabStop = true;
            radioButton1.Text = "radioButton1";
            radioButton1.UseVisualStyleBackColor = true;
            radioButton1.Visible = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(radioButton1);
            Controls.Add(sfsfsafasfsadfsdaff);
            Controls.Add(sdfsdfsdfsdfsfsdf);
            Controls.Add(sdfsdfsdfd);
            Controls.Add(label4);
            Controls.Add(Exit);
            Controls.Add(buttonClear);
            Controls.Add(buttonDisplay);
            Controls.Add(groupBox3);
            Controls.Add(checkBoxNEW);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(PartNumber);
            Controls.Add(PageNumber);
            Controls.Add(CatalogCode);
            Controls.Add(pictureBox1);
            Name = "Form1";
            Text = "Custom Mail Order #2";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private TextBox CatalogCode;
        private TextBox PageNumber;
        private TextBox PartNumber;
        private GroupBox groupBox1;
        private RadioButton Express;
        private RadioButton Ground;
        private GroupBox groupBox2;
        private RadioButton MoneyOrder;
        private RadioButton Charge;
        private RadioButton Cod;
        private CheckBox checkBoxNEW;
        private GroupBox groupBox3;
        private Label Newcustomerlabel;
        private RichTextBox bigboxotextomasser;
        private Label label3;
        private Label label2;
        private Button buttonDisplay;
        private Button buttonClear;
        private Button Exit;
        private Label label4;
        private Label sdfsdfsdfd;
        private Label sdfsdfsdfsdfsfsdf;
        private Label sfsfsafasfsadfsdaff;
        private RadioButton Priority;
        private Label Payment;
        private Label Shipping;
        private RadioButton radioButton1;
    }
}
