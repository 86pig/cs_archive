namespace Derek_E_MAILBOXNUMBER2_1117489_per7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            CatalogCode.Focus();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Express_CheckedChanged(object sender, EventArgs e)
        {
            Shipping.Text = "Express";
        }

        private void Ground_CheckedChanged(object sender, EventArgs e)
        {
            Shipping.Text = "Ground";
        }

        private void Priority_CheckedChanged(object sender, EventArgs e)
        {
            Shipping.Text = "Priority";
        }

        private void Charge_CheckedChanged(object sender, EventArgs e)
        {
            Payment.Text = "Charge";
        }

        private void Cod_CheckedChanged(object sender, EventArgs e)
        {
            Payment.Text = "COD";
        }

        private void MoneyOrder_CheckedChanged(object sender, EventArgs e)
        {
            Payment.Text = "Money Order";
        }

        private void checkBoxNEW_CheckedChanged(object sender, EventArgs e)
        {
            Newcustomerlabel.Text = "New Customer";
            if (checkBoxNEW.Checked == false)
                Newcustomerlabel.Text = null;
        }

        private void buttonDisplay_Click(object sender, EventArgs e)
        {
            string catalog = CatalogCode.Text;
            string page = PageNumber.Text;
            string part = PartNumber.Text;
            bigboxotextomasser.Text = "Catalog Code: " + catalog + "\n" + "Page Number: " + page + "\n" + "Part Number: " + part + "";
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            CatalogCode.Text = null;
            PageNumber.Text = null;
            PartNumber.Text = null;
            bigboxotextomasser.Clear();
            CatalogCode.Focus();
        }
    }
}
