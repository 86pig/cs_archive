﻿namespace Departures_and_Dest._Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            label1 = new Label();
            label2 = new Label();
            comboBoxDepartures = new ComboBox();
            comboBoxDestinations = new ComboBox();
            label3 = new Label();
            labelMiles = new Label();
            buttonlookup = new Button();
            buttonprinttable = new Button();
            buttonex = new Button();
            printPreviewDialogDest = new PrintPreviewDialog();
            printDocumentDest = new System.Drawing.Printing.PrintDocument();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(36, 34);
            label1.Name = "label1";
            label1.Size = new Size(64, 15);
            label1.TabIndex = 0;
            label1.Text = "Departures";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(211, 34);
            label2.Name = "label2";
            label2.Size = new Size(72, 15);
            label2.TabIndex = 1;
            label2.Text = "Destinatoins";
            // 
            // comboBoxDepartures
            // 
            comboBoxDepartures.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxDepartures.FormattingEnabled = true;
            comboBoxDepartures.Items.AddRange(new object[] { "Bos", "Chi", "Dal", "LV", "LA", "Mia", "NO", "Tor", "Van", "DC" });
            comboBoxDepartures.Location = new Point(36, 64);
            comboBoxDepartures.Name = "comboBoxDepartures";
            comboBoxDepartures.Size = new Size(121, 23);
            comboBoxDepartures.TabIndex = 2;
            // 
            // comboBoxDestinations
            // 
            comboBoxDestinations.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxDestinations.FormattingEnabled = true;
            comboBoxDestinations.Items.AddRange(new object[] { "Bos", "Chi", "Dal", "LV", "LA", "Mia", "NO", "Tor", "Van", "DC" });
            comboBoxDestinations.Location = new Point(211, 64);
            comboBoxDestinations.Name = "comboBoxDestinations";
            comboBoxDestinations.Size = new Size(121, 23);
            comboBoxDestinations.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(36, 170);
            label3.Name = "label3";
            label3.Size = new Size(85, 15);
            label3.TabIndex = 4;
            label3.Text = "Miles distance:";
            // 
            // labelMiles
            // 
            labelMiles.AutoSize = true;
            labelMiles.Location = new Point(245, 170);
            labelMiles.Name = "labelMiles";
            labelMiles.Size = new Size(17, 15);
            labelMiles.TabIndex = 5;
            labelMiles.Text = "--";
            // 
            // buttonlookup
            // 
            buttonlookup.Location = new Point(52, 234);
            buttonlookup.Name = "buttonlookup";
            buttonlookup.Size = new Size(75, 23);
            buttonlookup.TabIndex = 6;
            buttonlookup.Text = "Look up";
            buttonlookup.UseVisualStyleBackColor = true;
            buttonlookup.Click += buttonlookup_Click;
            // 
            // buttonprinttable
            // 
            buttonprinttable.Location = new Point(223, 234);
            buttonprinttable.Name = "buttonprinttable";
            buttonprinttable.Size = new Size(75, 23);
            buttonprinttable.TabIndex = 7;
            buttonprinttable.Text = "Print table";
            buttonprinttable.UseVisualStyleBackColor = true;
            buttonprinttable.Click += buttonprinttable_Click;
            // 
            // buttonex
            // 
            buttonex.Location = new Point(150, 295);
            buttonex.Name = "buttonex";
            buttonex.Size = new Size(75, 23);
            buttonex.TabIndex = 8;
            buttonex.Text = "Close";
            buttonex.UseVisualStyleBackColor = true;
            buttonex.Click += buttonex_Click;
            // 
            // printPreviewDialogDest
            // 
            printPreviewDialogDest.AutoScrollMargin = new Size(0, 0);
            printPreviewDialogDest.AutoScrollMinSize = new Size(0, 0);
            printPreviewDialogDest.ClientSize = new Size(400, 300);
            printPreviewDialogDest.Enabled = true;
            printPreviewDialogDest.Icon = (Icon)resources.GetObject("printPreviewDialogDest.Icon");
            printPreviewDialogDest.Name = "printPreviewDialogDest";
            printPreviewDialogDest.Visible = false;
            // 
            // printDocumentDest
            // 
            printDocumentDest.PrintPage += printDocumentDest_PrintPage;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(356, 294);
            Controls.Add(buttonex);
            Controls.Add(buttonprinttable);
            Controls.Add(buttonlookup);
            Controls.Add(labelMiles);
            Controls.Add(label3);
            Controls.Add(comboBoxDestinations);
            Controls.Add(comboBoxDepartures);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Departures and Destinations";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private ComboBox comboBoxDepartures;
        private ComboBox comboBoxDestinations;
        private Label label3;
        private Label labelMiles;
        private Button buttonlookup;
        private Button buttonprinttable;
        private Button buttonex;
        private PrintPreviewDialog printPreviewDialogDest;
        private System.Drawing.Printing.PrintDocument printDocumentDest;
    }
}
