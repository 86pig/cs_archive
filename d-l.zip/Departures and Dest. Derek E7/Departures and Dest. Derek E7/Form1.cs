using System.Windows.Forms;

namespace Departures_and_Dest._Derek_E7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int[,] a =
     {
            {0,1004,1753,2752,3017,1520,1507,609,3155, 488,},
            {1004,0,921,1780,2048,1397,919,515,2176,709 },
            {1753,921,0,1230,1399,1343,517,1435,2234,1307 },
            {2752,1780,1230,0,272,2570,1732,2251,1322,2420 },
            {3017,2048,1399,272,0,2716,1858,2523,1278,2646 },
            {1520,1397,1343,2570,2716,0,860,1494,3447,1057 },
            {1507,919,517,1732,1858,860,0,1307,2734,1099 },
            {609,515,1435,2251,2523,1494,1307,0,2820,571 },
            {3155,2176,2234,1322,1278,3447,2734,2820,0,2887 },
            {448,709,1307,2420,2646,1057,1099,571,2887,0 }
        };

        private void buttonlookup_Click(object sender, EventArgs e)
        {
            try
            {
                labelMiles.Text = a[comboBoxDepartures.SelectedIndex, comboBoxDestinations.SelectedIndex].ToString();
            }
            catch
            {
                MessageBox.Show("Please select two cities!", "Error!");
            }
        }

        private void buttonprinttable_Click(object sender, EventArgs e)
        {
            printPreviewDialogDest.Document = printDocumentDest;
            printPreviewDialogDest.ShowDialog();
        }

        private void buttonex_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void printDocumentDest_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Font printFont = new Font("Arial", 10);
            Font headingFont = new Font("Arial", 14, FontStyle.Bold);

            //get the margin boundaries for the default page
            float verticalPrintPositionFloat = e.MarginBounds.Top;
            float horizontalPrintPositionFloat = e.MarginBounds.Left;

            //figure out what the line height the print font is
            float lineHeightFloat = printFont.GetHeight();

            float[] cols = new float[12];
            for (int i = 0; i < cols.Length; i++)
            {
                cols[i] = horizontalPrintPositionFloat + (i * 50);
            }



            // Print heading.
            e.Graphics.DrawString("Distances",
                                    headingFont,
                                    Brushes.Black,
                                    horizontalPrintPositionFloat,
                                    verticalPrintPositionFloat);
            verticalPrintPositionFloat += 2 * lineHeightFloat;

            for (int i = 0; i <= a.GetUpperBound(0); i++)
            {
                e.Graphics.DrawString(comboBoxDepartures.Items[i].ToString(),
                                   printFont,
                                   Brushes.Black,
                                   cols[i],
                                   verticalPrintPositionFloat);
            }
            verticalPrintPositionFloat += 2 * lineHeightFloat;


            for (int row = 0; row <= a.GetUpperBound(0); row++)
            {
                e.Graphics.DrawString(comboBoxDepartures.Items[row].ToString(),
                                  printFont,
                                  Brushes.Black,
                                  horizontalPrintPositionFloat,
                                  verticalPrintPositionFloat);
                for (int col = 0; col <= a.GetUpperBound(1); col++)
                {
                    e.Graphics.DrawString(a[row, col].ToString(),
                            printFont,
                            Brushes.Black,
                            cols[col + 1],
                            verticalPrintPositionFloat);
                }
                verticalPrintPositionFloat += 2 * lineHeightFloat;
            }
        }
    }
}
