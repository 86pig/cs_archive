﻿namespace Listbox_car_care_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            menuStrip1 = new MenuStrip();
            fILEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEToolStripMenuItem = new ToolStripMenuItem();
            printOrderToolStripMenuItem = new ToolStripMenuItem();
            clearToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem1 = new ToolStripSeparator();
            exitToolStripMenuItem = new ToolStripMenuItem();
            label1 = new Label();
            label2 = new Label();
            comboBoxPackage = new ComboBox();
            comboBoxSniffy = new ComboBox();
            listBoxInterior = new ListBox();
            listBoxExterior = new ListBox();
            label3 = new Label();
            label4 = new Label();
            timerThing = new System.Windows.Forms.Timer(components);
            printPreviewDialogCar = new PrintPreviewDialog();
            printDocumentCar = new System.Drawing.Printing.PrintDocument();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Font = new Font("Segoe UI", 13F);
            menuStrip1.Items.AddRange(new ToolStripItem[] { fILEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(738, 33);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // fILEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEToolStripMenuItem
            // 
            fILEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { printOrderToolStripMenuItem, clearToolStripMenuItem, toolStripMenuItem1, exitToolStripMenuItem });
            fILEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEToolStripMenuItem.Name = "fILEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEToolStripMenuItem";
            fILEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEToolStripMenuItem.Size = new Size(730, 29);
            fILEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEToolStripMenuItem.Text = "FILEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE";
            // 
            // printOrderToolStripMenuItem
            // 
            printOrderToolStripMenuItem.Name = "printOrderToolStripMenuItem";
            printOrderToolStripMenuItem.Size = new Size(180, 30);
            printOrderToolStripMenuItem.Text = "&Print order";
            printOrderToolStripMenuItem.Click += printOrderToolStripMenuItem_Click;
            // 
            // clearToolStripMenuItem
            // 
            clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            clearToolStripMenuItem.Size = new Size(180, 30);
            clearToolStripMenuItem.Text = "&Clear";
            clearToolStripMenuItem.Click += clearToolStripMenuItem_Click;
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(177, 6);
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(180, 30);
            exitToolStripMenuItem.Text = "E&xit";
            exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(32, 73);
            label1.Name = "label1";
            label1.Size = new Size(51, 15);
            label1.TabIndex = 1;
            label1.Text = "Package";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(268, 73);
            label2.Name = "label2";
            label2.Size = new Size(37, 15);
            label2.TabIndex = 3;
            label2.Text = "Sniffy";
            // 
            // comboBoxPackage
            // 
            comboBoxPackage.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxPackage.FormattingEnabled = true;
            comboBoxPackage.Items.AddRange(new object[] { "Standard", "Deluxe", "Executive", "Luxury" });
            comboBoxPackage.Location = new Point(32, 100);
            comboBoxPackage.Name = "comboBoxPackage";
            comboBoxPackage.Size = new Size(121, 23);
            comboBoxPackage.TabIndex = 4;
            comboBoxPackage.SelectedIndexChanged += comboBoxPackage_SelectedIndexChanged;
            // 
            // comboBoxSniffy
            // 
            comboBoxSniffy.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxSniffy.FormattingEnabled = true;
            comboBoxSniffy.Items.AddRange(new object[] { "Hawaiian Mist", "Baby Powder", "Pine", "Country Floral", "Pina Colada", "Vanilla" });
            comboBoxSniffy.Location = new Point(184, 100);
            comboBoxSniffy.Name = "comboBoxSniffy";
            comboBoxSniffy.Size = new Size(121, 23);
            comboBoxSniffy.TabIndex = 5;
            // 
            // listBoxInterior
            // 
            listBoxInterior.FormattingEnabled = true;
            listBoxInterior.ItemHeight = 15;
            listBoxInterior.Location = new Point(32, 176);
            listBoxInterior.Name = "listBoxInterior";
            listBoxInterior.SelectionMode = SelectionMode.None;
            listBoxInterior.Size = new Size(121, 124);
            listBoxInterior.TabIndex = 6;
            // 
            // listBoxExterior
            // 
            listBoxExterior.FormattingEnabled = true;
            listBoxExterior.ItemHeight = 15;
            listBoxExterior.Location = new Point(184, 176);
            listBoxExterior.Name = "listBoxExterior";
            listBoxExterior.SelectionMode = SelectionMode.None;
            listBoxExterior.Size = new Size(121, 124);
            listBoxExterior.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(32, 150);
            label3.Name = "label3";
            label3.Size = new Size(45, 15);
            label3.TabIndex = 8;
            label3.Text = "Interior";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(258, 150);
            label4.Name = "label4";
            label4.Size = new Size(47, 15);
            label4.TabIndex = 9;
            label4.Text = "Exterior";
            // 
            // timerThing
            // 
            timerThing.Interval = 2;
            timerThing.Tick += timerThing_Tick;
            // 
            // printPreviewDialogCar
            // 
            printPreviewDialogCar.AutoScrollMargin = new Size(0, 0);
            printPreviewDialogCar.AutoScrollMinSize = new Size(0, 0);
            printPreviewDialogCar.ClientSize = new Size(400, 300);
            printPreviewDialogCar.Enabled = true;
            printPreviewDialogCar.Icon = (Icon)resources.GetObject("printPreviewDialogCar.Icon");
            printPreviewDialogCar.Name = "printPreviewDialogCar";
            printPreviewDialogCar.Visible = false;
            printPreviewDialogCar.Load += printPreviewDialogCar_Load;
            // 
            // printDocumentCar
            // 
            printDocumentCar.PrintPage += printDocumentCar_PrintPage;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(738, 318);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(listBoxExterior);
            Controls.Add(listBoxInterior);
            Controls.Add(comboBoxSniffy);
            Controls.Add(comboBoxPackage);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Modern car care for interesting people of this Earth";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem fILEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEToolStripMenuItem;
        private ToolStripMenuItem printOrderToolStripMenuItem;
        private ToolStripMenuItem clearToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem1;
        private ToolStripMenuItem exitToolStripMenuItem;
        private Label label1;
        private Label label2;
        private ComboBox comboBoxPackage;
        private ComboBox comboBoxSniffy;
        private ListBox listBoxInterior;
        private ListBox listBoxExterior;
        private Label label3;
        private Label label4;
        private System.Windows.Forms.Timer timerThing;
        private PrintPreviewDialog printPreviewDialogCar;
        private System.Drawing.Printing.PrintDocument printDocumentCar;
    }
}
