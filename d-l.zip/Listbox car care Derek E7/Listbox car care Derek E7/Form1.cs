using System.Windows.Forms;

namespace Listbox_car_care_Derek_E7
{
    public partial class Form1 : Form
    {
        //EXTERIOR
        const string exterior_hand_wash = "Exterior hand wash";
        const string hand_wax = "Hand wax";
        const string fluid_check = "Engine fluid check";
        const string detail_engine = "Detail engine fluids";
        const string detail_carriage = "Detail under carriage";

        //INTERIOR
        const string interior_fragrance = "Interior fragrance";
        const string shampoo_carpets = "Shampoo carpets";
        const string shampoo_upholstery = "Shampoo upholstery";
        const string interior_protection_coat = "Interior protection coating";
        const string scotchgard_tm = "Scotchgard�";

        const int achoo = 3;

        public Form1()
        {
            InitializeComponent();
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            comboBoxSniffy.Items.Clear();
            comboBoxPackage.Items.Clear();
            listBoxExterior.Items.Clear();
            listBoxInterior.Items.Clear();

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this
                .

                Close

                (
                )
                ;
        }

        private void timerThing_Tick(object sender, EventArgs e)
        {
            if (achoo == 3)
            {

            }
        }

        private void printOrderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printPreviewDialogCar.Document = printDocumentCar;
            printPreviewDialogCar.ShowDialog();
        }

        private void printPreviewDialogCar_Load(object sender, EventArgs e)
        {

        }

        private void printDocumentCar_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {








            Font printFont = new Font("Arial", 12);
            Font headingFont = new Font("Arial", 24, FontStyle.Bold);
            float verticalPrintPositionFloat = e.MarginBounds.Top;
            float horizontalPrintPositionFloat = e.MarginBounds.Left;
            float lineHeightFloat = printFont.GetHeight();

            // Print heading.
            e.Graphics.DrawString("Your car detail order ",
            headingFont,
            Brushes.SaddleBrown, horizontalPrintPositionFloat,
            verticalPrintPositionFloat);
            verticalPrintPositionFloat += 2 * lineHeightFloat;
            e.Graphics.DrawString("Derek E (per 7)", printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);
            verticalPrintPositionFloat += 2 * lineHeightFloat;


            verticalPrintPositionFloat += 3 * lineHeightFloat;



            e.Graphics.DrawString("Package: " + comboBoxPackage.Text, printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);
            verticalPrintPositionFloat += 2 * lineHeightFloat;
            e.Graphics.DrawString("Fragrance: " + comboBoxSniffy.Text, printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);
            verticalPrintPositionFloat += 2 * lineHeightFloat;

            e.Graphics.DrawString("", printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);
            verticalPrintPositionFloat += 3 * lineHeightFloat;

            e.Graphics.DrawString("Interior:", printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);
            verticalPrintPositionFloat += 2 * lineHeightFloat;
            e.Graphics.DrawString("---------------", printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);
            verticalPrintPositionFloat += 2 * lineHeightFloat;


            foreach (String student in listBoxInterior.Items)
            {
                e.Graphics.DrawString(student, printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);

                verticalPrintPositionFloat += 2 * lineHeightFloat;

            }
            e.Graphics.DrawString("", printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);
            verticalPrintPositionFloat += 3 * lineHeightFloat;

            e.Graphics.DrawString("Exterior:", printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);
            verticalPrintPositionFloat += 2 * lineHeightFloat;

            e.Graphics.DrawString("---------------", printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);
            verticalPrintPositionFloat += 2 * lineHeightFloat;

            foreach (String student in listBoxExterior.Items)
            {
                e.Graphics.DrawString(student, printFont, Brushes.IndianRed, horizontalPrintPositionFloat, verticalPrintPositionFloat);

                verticalPrintPositionFloat += 2 * lineHeightFloat;

            }


        }

        private void comboBoxPackage_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxPackage.SelectedIndex == 0)
            {
                listBoxExterior.Items.Clear();
                listBoxInterior.Items.Clear();

                listBoxInterior.Items.Add(interior_fragrance);

                listBoxExterior.Items.Add(exterior_hand_wash);
         
            }

            if (comboBoxPackage.SelectedIndex == 1)
            {
                listBoxExterior.Items.Clear();
                listBoxInterior.Items.Clear();

                listBoxInterior.Items.Add(interior_fragrance);
                listBoxInterior.Items.Add(shampoo_carpets);

                listBoxExterior.Items.Add(exterior_hand_wash);
                listBoxExterior.Items.Add(hand_wax);

            }

            if (comboBoxPackage.SelectedIndex == 2)
            {
                listBoxExterior.Items.Clear();
                listBoxInterior.Items.Clear();

                listBoxInterior.Items.Add(interior_fragrance);
                listBoxInterior.Items.Add(shampoo_carpets);
                listBoxInterior.Items.Add(interior_protection_coat);

                listBoxExterior.Items.Add(exterior_hand_wash);
                listBoxExterior.Items.Add(hand_wax);
                listBoxExterior.Items.Add(fluid_check);
                
            }

            if (comboBoxPackage.SelectedIndex == 3)
            {
                listBoxExterior.Items.Clear();
                listBoxInterior.Items.Clear();

                listBoxInterior.Items.Add(interior_fragrance);
                listBoxInterior.Items.Add(shampoo_carpets);
                listBoxInterior.Items.Add(shampoo_upholstery);
                listBoxInterior.Items.Add(scotchgard_tm);

                listBoxExterior.Items.Add(exterior_hand_wash);
                listBoxExterior.Items.Add(hand_wax);
                listBoxExterior.Items.Add(fluid_check);
                listBoxExterior.Items.Add(detail_carriage);
                listBoxExterior.Items.Add(detail_engine);
                
            }

        }
    }
}
