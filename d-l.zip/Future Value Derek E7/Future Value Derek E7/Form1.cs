namespace Future_Value_Derek_E7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonEXit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonCalcualte_Click(object sender, EventArgs e)
        {
            try
            {
                double investmentamount, interestrate, years, invest;

                investmentamount = double.Parse(textBoxinvestmentamount.Text);
                interestrate = double.Parse(textBoxintrestrate.Text);
                years = double.Parse(textBoxyears.Text);



                invest = investmentamount * Math.Pow(1 + interestrate, years);


                textBoxFuturevalue.Text = invest.ToString("C");
                label5NAM.Focus();
            }

            catch
            {
                MessageBox.Show("Enter a valid thingy ");
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxinvestmentamount.Clear();
            textBoxintrestrate.Clear();
            textBoxyears.Clear();
            textBoxFuturevalue.Clear();
            textBoxinvestmentamount.Focus();

        }
    }
}
