﻿namespace Future_Value_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBoxinvestmentamount = new TextBox();
            textBoxintrestrate = new TextBox();
            label2 = new Label();
            textBoxFuturevalue = new TextBox();
            label3 = new Label();
            label4 = new Label();
            textBoxyears = new TextBox();
            buttonCalcualte = new Button();
            buttonClear = new Button();
            buttonEXit = new Button();
            label5NAM = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11F);
            label1.Location = new Point(34, 42);
            label1.Name = "label1";
            label1.Size = new Size(144, 20);
            label1.TabIndex = 0;
            label1.Text = "Invenstment amount";
            // 
            // textBoxinvestmentamount
            // 
            textBoxinvestmentamount.Location = new Point(205, 43);
            textBoxinvestmentamount.Name = "textBoxinvestmentamount";
            textBoxinvestmentamount.Size = new Size(122, 23);
            textBoxinvestmentamount.TabIndex = 1;
            // 
            // textBoxintrestrate
            // 
            textBoxintrestrate.Location = new Point(205, 94);
            textBoxintrestrate.Name = "textBoxintrestrate";
            textBoxintrestrate.Size = new Size(122, 23);
            textBoxintrestrate.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11F);
            label2.Location = new Point(34, 93);
            label2.Name = "label2";
            label2.Size = new Size(88, 20);
            label2.TabIndex = 2;
            label2.Text = "Interest rate";
            // 
            // textBoxFuturevalue
            // 
            textBoxFuturevalue.Location = new Point(205, 240);
            textBoxFuturevalue.Name = "textBoxFuturevalue";
            textBoxFuturevalue.ReadOnly = true;
            textBoxFuturevalue.Size = new Size(122, 23);
            textBoxFuturevalue.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11F);
            label3.Location = new Point(34, 239);
            label3.Name = "label3";
            label3.Size = new Size(89, 20);
            label3.TabIndex = 4;
            label3.Text = "Future value";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11F);
            label4.Location = new Point(34, 151);
            label4.Name = "label4";
            label4.Size = new Size(43, 20);
            label4.TabIndex = 4;
            label4.Text = "Years";
            // 
            // textBoxyears
            // 
            textBoxyears.Location = new Point(205, 152);
            textBoxyears.Name = "textBoxyears";
            textBoxyears.Size = new Size(122, 23);
            textBoxyears.TabIndex = 5;
            // 
            // buttonCalcualte
            // 
            buttonCalcualte.Location = new Point(357, 43);
            buttonCalcualte.Name = "buttonCalcualte";
            buttonCalcualte.Size = new Size(115, 49);
            buttonCalcualte.TabIndex = 6;
            buttonCalcualte.Text = "Calc future value";
            buttonCalcualte.UseVisualStyleBackColor = true;
            buttonCalcualte.Click += buttonCalcualte_Click;
            // 
            // buttonClear
            // 
            buttonClear.Location = new Point(357, 98);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(115, 44);
            buttonClear.TabIndex = 7;
            buttonClear.Text = "&Clear";
            buttonClear.UseVisualStyleBackColor = true;
            buttonClear.Click += buttonClear_Click;
            // 
            // buttonEXit
            // 
            buttonEXit.Location = new Point(357, 148);
            buttonEXit.Name = "buttonEXit";
            buttonEXit.Size = new Size(115, 43);
            buttonEXit.TabIndex = 8;
            buttonEXit.Text = "E&xit";
            buttonEXit.UseVisualStyleBackColor = true;
            buttonEXit.Click += buttonEXit_Click;
            // 
            // label5NAM
            // 
            label5NAM.AutoSize = true;
            label5NAM.Font = new Font("Segoe UI", 11F);
            label5NAM.Location = new Point(412, 243);
            label5NAM.Name = "label5NAM";
            label5NAM.Size = new Size(60, 20);
            label5NAM.TabIndex = 9;
            label5NAM.Text = "Derek E";
            // 
            // Form1
            // 
            AcceptButton = buttonCalcualte;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = buttonEXit;
            ClientSize = new Size(520, 304);
            Controls.Add(label5NAM);
            Controls.Add(buttonEXit);
            Controls.Add(buttonClear);
            Controls.Add(buttonCalcualte);
            Controls.Add(textBoxyears);
            Controls.Add(label4);
            Controls.Add(textBoxFuturevalue);
            Controls.Add(label3);
            Controls.Add(textBoxintrestrate);
            Controls.Add(label2);
            Controls.Add(textBoxinvestmentamount);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Future value project";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBoxinvestmentamount;
        private TextBox textBoxintrestrate;
        private Label label2;
        private TextBox textBoxFuturevalue;
        private Label label3;
        private Label label4;
        private TextBox textBoxyears;
        private Button buttonCalcualte;
        private Button buttonClear;
        private Button buttonEXit;
        private Label label5NAM;
    }
}
