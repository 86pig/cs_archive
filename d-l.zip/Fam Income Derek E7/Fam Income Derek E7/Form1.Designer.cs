﻿namespace Fam_Income_Derek_E7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            enterDataToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem1 = new ToolStripSeparator();
            exitToolStripMenuItem = new ToolStripMenuItem();
            reportToolStripMenuItem = new ToolStripMenuItem();
            report1ToolStripMenuItem = new ToolStripMenuItem();
            report2ToolStripMenuItem = new ToolStripMenuItem();
            remote3ToolStripMenuItem = new ToolStripMenuItem();
            helpToolStripMenuItem = new ToolStripMenuItem();
            label1 = new Label();
            textBoxID = new TextBox();
            textBoxpeople = new TextBox();
            label2 = new Label();
            textBoxincome = new TextBox();
            label3 = new Label();
            listBoxFamilys = new ListBox();
            printPreviewDialog1 = new PrintPreviewDialog();
            printDocument1 = new System.Drawing.Printing.PrintDocument();
            printPreviewDialog2 = new PrintPreviewDialog();
            printDocument2 = new System.Drawing.Printing.PrintDocument();
            printPreviewDialog3 = new PrintPreviewDialog();
            printDocument3 = new System.Drawing.Printing.PrintDocument();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Font = new Font("Segoe UI", 19F);
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem, reportToolStripMenuItem, helpToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(748, 44);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { enterDataToolStripMenuItem, toolStripMenuItem1, exitToolStripMenuItem });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(66, 40);
            fileToolStripMenuItem.Text = "File";
            // 
            // enterDataToolStripMenuItem
            // 
            enterDataToolStripMenuItem.Name = "enterDataToolStripMenuItem";
            enterDataToolStripMenuItem.Size = new Size(207, 40);
            enterDataToolStripMenuItem.Text = "Enter data";
            enterDataToolStripMenuItem.Click += enterDataToolStripMenuItem_Click;
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(204, 6);
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(207, 40);
            exitToolStripMenuItem.Text = "Exit";
            exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;
            // 
            // reportToolStripMenuItem
            // 
            reportToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { report1ToolStripMenuItem, report2ToolStripMenuItem, remote3ToolStripMenuItem });
            reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            reportToolStripMenuItem.Size = new Size(104, 40);
            reportToolStripMenuItem.Text = "Report";
            reportToolStripMenuItem.Click += reportToolStripMenuItem_Click;
            // 
            // report1ToolStripMenuItem
            // 
            report1ToolStripMenuItem.Name = "report1ToolStripMenuItem";
            report1ToolStripMenuItem.Size = new Size(188, 40);
            report1ToolStripMenuItem.Text = "Report 1";
            report1ToolStripMenuItem.Click += report1ToolStripMenuItem_Click;
            // 
            // report2ToolStripMenuItem
            // 
            report2ToolStripMenuItem.Name = "report2ToolStripMenuItem";
            report2ToolStripMenuItem.Size = new Size(188, 40);
            report2ToolStripMenuItem.Text = "Report 2";
            report2ToolStripMenuItem.Click += report2ToolStripMenuItem_Click;
            // 
            // remote3ToolStripMenuItem
            // 
            remote3ToolStripMenuItem.Name = "remote3ToolStripMenuItem";
            remote3ToolStripMenuItem.Size = new Size(188, 40);
            remote3ToolStripMenuItem.Text = "Report 3";
            remote3ToolStripMenuItem.Click += remote3ToolStripMenuItem_Click;
            // 
            // helpToolStripMenuItem
            // 
            helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            helpToolStripMenuItem.Size = new Size(80, 40);
            helpToolStripMenuItem.Text = "Help";
            helpToolStripMenuItem.Click += helpToolStripMenuItem_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 19F);
            label1.Location = new Point(12, 111);
            label1.Name = "label1";
            label1.Size = new Size(40, 36);
            label1.TabIndex = 1;
            label1.Text = "ID";
            // 
            // textBoxID
            // 
            textBoxID.Font = new Font("Segoe UI", 19F);
            textBoxID.Location = new Point(178, 108);
            textBoxID.Name = "textBoxID";
            textBoxID.Size = new Size(180, 41);
            textBoxID.TabIndex = 2;
            // 
            // textBoxpeople
            // 
            textBoxpeople.Font = new Font("Segoe UI", 19F);
            textBoxpeople.Location = new Point(178, 155);
            textBoxpeople.Name = "textBoxpeople";
            textBoxpeople.Size = new Size(180, 41);
            textBoxpeople.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 19F);
            label2.Location = new Point(12, 158);
            label2.Name = "label2";
            label2.Size = new Size(101, 36);
            label2.TabIndex = 3;
            label2.Text = "# o' ppl";
            // 
            // textBoxincome
            // 
            textBoxincome.Font = new Font("Segoe UI", 19F);
            textBoxincome.Location = new Point(178, 202);
            textBoxincome.Name = "textBoxincome";
            textBoxincome.Size = new Size(180, 41);
            textBoxincome.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 19F);
            label3.Location = new Point(12, 205);
            label3.Name = "label3";
            label3.Size = new Size(100, 36);
            label3.TabIndex = 5;
            label3.Text = "Income";
            // 
            // listBoxFamilys
            // 
            listBoxFamilys.Font = new Font("Segoe UI", 19F);
            listBoxFamilys.FormattingEnabled = true;
            listBoxFamilys.ItemHeight = 35;
            listBoxFamilys.Location = new Point(383, 64);
            listBoxFamilys.Name = "listBoxFamilys";
            listBoxFamilys.Size = new Size(306, 179);
            listBoxFamilys.TabIndex = 7;
            listBoxFamilys.SelectedIndexChanged += listBoxFamilys_SelectedIndexChanged;
            // 
            // printPreviewDialog1
            // 
            printPreviewDialog1.AutoScrollMargin = new Size(0, 0);
            printPreviewDialog1.AutoScrollMinSize = new Size(0, 0);
            printPreviewDialog1.ClientSize = new Size(400, 300);
            printPreviewDialog1.Enabled = true;
            printPreviewDialog1.Icon = (Icon)resources.GetObject("printPreviewDialog1.Icon");
            printPreviewDialog1.Name = "printPreviewDialog1";
            printPreviewDialog1.Visible = false;
            // 
            // printDocument1
            // 
            printDocument1.PrintPage += printDocument1_PrintPage;
            // 
            // printPreviewDialog2
            // 
            printPreviewDialog2.AutoScrollMargin = new Size(0, 0);
            printPreviewDialog2.AutoScrollMinSize = new Size(0, 0);
            printPreviewDialog2.ClientSize = new Size(400, 300);
            printPreviewDialog2.Enabled = true;
            printPreviewDialog2.Icon = (Icon)resources.GetObject("printPreviewDialog2.Icon");
            printPreviewDialog2.Name = "printPreviewDialog2";
            printPreviewDialog2.Visible = false;
            // 
            // printDocument2
            // 
            printDocument2.PrintPage += printDocument2_PrintPage;
            // 
            // printPreviewDialog3
            // 
            printPreviewDialog3.AutoScrollMargin = new Size(0, 0);
            printPreviewDialog3.AutoScrollMinSize = new Size(0, 0);
            printPreviewDialog3.ClientSize = new Size(400, 300);
            printPreviewDialog3.Enabled = true;
            printPreviewDialog3.Icon = (Icon)resources.GetObject("printPreviewDialog3.Icon");
            printPreviewDialog3.Name = "printPreviewDialog3";
            printPreviewDialog3.Visible = false;
            // 
            // printDocument3
            // 
            printDocument3.PrintPage += printDocument3_PrintPage;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(748, 292);
            Controls.Add(listBoxFamilys);
            Controls.Add(textBoxincome);
            Controls.Add(label3);
            Controls.Add(textBoxpeople);
            Controls.Add(label2);
            Controls.Add(textBoxID);
            Controls.Add(label1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Family Income Project";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem enterDataToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem1;
        private ToolStripMenuItem exitToolStripMenuItem;
        private ToolStripMenuItem reportToolStripMenuItem;
        private ToolStripMenuItem helpToolStripMenuItem;
        private ToolStripMenuItem report1ToolStripMenuItem;
        private ToolStripMenuItem report2ToolStripMenuItem;
        private ToolStripMenuItem remote3ToolStripMenuItem;
        private Label label1;
        private TextBox textBoxID;
        private TextBox textBoxpeople;
        private Label label2;
        private TextBox textBoxincome;
        private Label label3;
        private ListBox listBoxFamilys;
        private PrintPreviewDialog printPreviewDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private PrintPreviewDialog printPreviewDialog2;
        private System.Drawing.Printing.PrintDocument printDocument2;
        private PrintPreviewDialog printPreviewDialog3;
        private System.Drawing.Printing.PrintDocument printDocument3;
    }
}
