using System.Drawing.Printing;
using System.Runtime.Intrinsics.X86;
using System.Windows.Forms;

namespace Fam_Income_Derek_E7
{
    public partial class Form1 : Form
    {
        Families[] families = new Families[10];
        int index = 0;
        double averageIncome = 0;
        double poverty = 0;
        int povcount = 0;

        int[] Poor =
        {0, 10210, 13690, 17170, 20650, 24130, 27610, 31090, 34570};




        public Form1()
        {
            InitializeComponent();
        }

        private void reportToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void enterDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                int id = int.Parse(textBoxID.Text);
                int people = int.Parse(textBoxpeople.Text);
                int income = int.Parse(textBoxincome.Text);

                Families pog = new Families(id, people, income);
                families[index] = pog;
                index++;
                if (index >= families.Length) index = 0;
                listBoxFamilys.Items.Add(id);

                textBoxID.Clear();
                textBoxpeople.Clear
                    ();
                textBoxincome.Clear();
            }
            catch
            {
                MessageBox.Show("Invalid input try again.", "ALERT !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            }
        }

        private void listBoxFamilys_SelectedIndexChanged(object sender, EventArgs e)
        {
            int listindex = listBoxFamilys.SelectedIndex;
            if (listindex != -1)
            {
                //retreive instance form array
                Families pog = families[listindex];

                // display info  back to ui
                textBoxID.Text = pog.ID.ToString();
                textBoxpeople.Text = pog.People.ToString();
                textBoxincome.Text = pog.People.ToString();


            }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Font printFont = new Font("Arial", 12);
            Font headingFont = new Font("Arial", 24, FontStyle.Bold);
            float verticalPrintPositionFloat = e.MarginBounds.Top;
            float horizontalPrintPositionFloat = e.MarginBounds.Left;
            float lineHeightFloat = printFont.GetHeight();

            float[] cols =
            {
                horizontalPrintPositionFloat,
                horizontalPrintPositionFloat + 200,
                horizontalPrintPositionFloat + 400,
            };
            // Print heading.
            e.Graphics.DrawString("ID: ",
            headingFont,
            Brushes.SaddleBrown, cols[0],
            verticalPrintPositionFloat);



            // Print heading.
            e.Graphics.DrawString("# o' ppl: ",
            headingFont,
            Brushes.SaddleBrown, cols[1],
            verticalPrintPositionFloat);


            // Print heading.
            e.Graphics.DrawString("Income: ",
            headingFont,
            Brushes.SaddleBrown, cols[2],
            verticalPrintPositionFloat);

            verticalPrintPositionFloat += 2 * lineHeightFloat;

            for (int i = 0; i < families.Length; i++)
            {
                if (families[i] == null)
                {
                    break;
                }
                else
                {
                    // Print heading.
                    e.Graphics.DrawString(families[i].ID.ToString(),
                    printFont,
                    Brushes.SaddleBrown, cols[0],
                    verticalPrintPositionFloat);


                    // Print heading.
                    e.Graphics.DrawString(families[i].People.ToString(),
                    printFont,
                    Brushes.SaddleBrown, cols[1],
                    verticalPrintPositionFloat);


                    // Print heading.
                    e.Graphics.DrawString(families[i].Income.ToString(),
                    printFont,
                    Brushes.SaddleBrown, cols[2],
                    verticalPrintPositionFloat);

                    verticalPrintPositionFloat += 2 * lineHeightFloat;
                }


            }
        }

        private void report1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void printDocument2_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Font printFont = new Font("Arial", 12);
            Font headingFont = new Font("Arial", 24, FontStyle.Bold);
            float verticalPrintPositionFloat = e.MarginBounds.Top;
            float horizontalPrintPositionFloat = e.MarginBounds.Left;
            float lineHeightFloat = printFont.GetHeight();

            // Print heading.
            e.Graphics.DrawString("Family incomes above average ",
            headingFont,
            Brushes.SaddleBrown, horizontalPrintPositionFloat,
            verticalPrintPositionFloat);

            verticalPrintPositionFloat += 2 * lineHeightFloat;

            // Print heading.
            e.Graphics.DrawString("Average income: $" + averageIncome.ToString(),
            headingFont,
            Brushes.SaddleBrown, horizontalPrintPositionFloat,
            verticalPrintPositionFloat);

            verticalPrintPositionFloat += 2 * lineHeightFloat;
            verticalPrintPositionFloat += 2 * lineHeightFloat;
            verticalPrintPositionFloat += 2 * lineHeightFloat;

            float[] cols =
            {
                horizontalPrintPositionFloat,
                horizontalPrintPositionFloat + 200,
            };
            // Print heading.
            e.Graphics.DrawString("ID: ",
            headingFont,
            Brushes.SaddleBrown, cols[0],
            verticalPrintPositionFloat);

            // Print heading.
            e.Graphics.DrawString("Income: ",
            headingFont,
            Brushes.SaddleBrown, cols[1],
            verticalPrintPositionFloat);

            verticalPrintPositionFloat += 2 * lineHeightFloat;

            for (int i = 0; i < families.Length; i++)
            {
                if (families[i] == null)
                {
                    break;
                }
                if (families[i].Income >= averageIncome)
                {

                    // Print heading.
                    e.Graphics.DrawString(families[i].ID.ToString(),
                    printFont,
                    Brushes.SaddleBrown, cols[0],
                    verticalPrintPositionFloat);


                    // Print heading.
                    e.Graphics.DrawString(families[i].Income.ToString("c"),
                    printFont,
                    Brushes.SaddleBrown, cols[1],
                    verticalPrintPositionFloat);

                    verticalPrintPositionFloat += 2 * lineHeightFloat;
                }
            }
        }

        private void report2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            averageIncome = 0;
            for (int i = 0; i <= families.Length; i++)
            {
                if (families[i] == null) break;


                averageIncome += families[i].Income;

            }
            averageIncome /= listBoxFamilys.Items.Count;

            printPreviewDialog2.Document = printDocument2;
            printPreviewDialog2.ShowDialog();
        }
        private void remote3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            poverty = 0;

            for (int i = 0; i <= families.Length; i++)
            {
                if (families[i] == null) break;
                if (families[i].Income <= Poor[families[i].People])
                {
                    poverty++;

                }
            }
            poverty /= listBoxFamilys.Items.Count;
            poverty *= 100;
            printPreviewDialog3.Document = printDocument3;
            printPreviewDialog3.ShowDialog();
        }
        private void printDocument3_PrintPage(object sender, PrintPageEventArgs e)
        {
            Font printFont = new Font("Arial", 12);
            Font headingFont = new Font("Arial", 24, FontStyle.Bold);
            float verticalPrintPositionFloat = e.MarginBounds.Top;
            float horizontalPrintPositionFloat = e.MarginBounds.Left;
            float lineHeightFloat = printFont.GetHeight();

            verticalPrintPositionFloat += 2 * lineHeightFloat;

            // Print heading.
            e.Graphics.DrawString("% of households below poverty: " + poverty.ToString() + "%", // calc %
            headingFont,
            Brushes.SaddleBrown, horizontalPrintPositionFloat,
            verticalPrintPositionFloat);

        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Made by Derek from the seventh period of Mr. Donnelly's computer science (C#)");
        }
    }
}