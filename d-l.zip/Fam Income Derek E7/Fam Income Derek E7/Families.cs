﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Fam_Income_Derek_E7
{
    public class Families
    {
        public int ID { get; set; }
        public int People { get; set; }
        public int Income { get; set; }

    

        public Families(int id, int p, int i)
            {
                ID = id;
                People = p;
                Income = i;
            }
    }
}