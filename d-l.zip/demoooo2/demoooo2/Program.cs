﻿namespace demoooo2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string colour = "red";
            int number = 12;
            bool result = false;
            string formattedString = string.Format("colour: {0} number; {1} result: {2}", colour, number, result);
            Console.WriteLine(formattedString);
            Console.WriteLine($" colour: {colour} number: {number.ToString("c2")} result: {result}"); //$ = token

            List<string[]> list = new List<string[]>();
            string input = "Data.csv";
            StreamReader sr = new StreamReader(input);
            string line = sr.ReadLine();
            while (line != null)
            {
                string[] arr = line.Split(",");
                list.Add(arr);
                line = sr.ReadLine();
            }
            sr.Close();

            StreamWriter sw = new StreamWriter(input);
            foreach (string[] arr in list)
            {
                string output = string.Join(",", arr);
                sw.WriteLine(output);
            }
            sw.Flush();
            sw.Close();
        }
    }
}
